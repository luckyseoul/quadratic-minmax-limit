#!/usr/bin/env python3
"""Exact independent-stage rescoring of heuristic campaign candidates, n <= 32."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import argparse, hashlib, importlib.util, json, time
from pathlib import Path
import numpy as np

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--core',required=True)
    ap.add_argument('--bank',required=True)
    ap.add_argument('--winner',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--limit',type=int,default=4)
    args=ap.parse_args()
    spec=importlib.util.spec_from_file_location('mo_frozen_core',args.core)
    core=importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
    old='all=(1u<<n)-1u;'
    assert core.KERNEL.count(old)==1
    core.KERNEL=core.KERNEL.replace(old,'all=(n==32?0xffffffffu:(1u<<n)-1u);')
    sc=core.Scorer(); core.selftest(sc)
    bank=np.load(args.bank)
    initial=json.loads(Path(args.winner).read_text())
    matrices=[np.asarray(initial['A'],dtype=np.int8)]
    estimates=[initial['Phi']]
    seen={core.digest(matrices[0])}
    for a,estimate in zip(bank['matrices'],bank['scores']):
        if core.digest(a) in seen: continue
        seen.add(core.digest(a)); matrices.append(a); estimates.append(int(estimate))
        if len(matrices)>=args.limit: break
    output=Path(args.out); output.mkdir(parents=True,exist_ok=True)
    manifest={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'frozen_core_sha256':hashlib.sha256(Path(args.core).read_bytes()).hexdigest(),
              'bank_sha256':hashlib.sha256(Path(args.bank).read_bytes()).hexdigest(),
              'device':sc.device,'kernel_change':'defined full uint32 vertex mask at n=32',
              'classification':'exhaustive_GPU_integer_score_not_global_matrix_optimizer_certificate'}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    rows=[]
    for index,(a,estimate) in enumerate(zip(matrices,estimates)):
        n=len(a); assert 2<=n<=32
        started=time.time(); score,peaks,witness=sc.score(a[None],True,0,0)[0]
        core.verify_witness(a,score,witness)
        row={'index':index,'n':n,'matrix_sha256':core.digest(a),'Phi':score,
             'normalized_Phi':score/n**1.5,'prior_heuristic_lower_bound':estimate,
             'peak_count_fixed_first_spin':peaks,'witness_masks':witness,
             'states':1<<(n-1),'elapsed_seconds':time.time()-started,
             'score_exact':True,'A':a.tolist()}
        assert score>=estimate
        rows.append(row)
        (output/f'verified_n{n}_{index}.json').write_text(json.dumps(row,indent=2)+'\n')
        (output/'summary.json').write_text(json.dumps({'manifest':manifest,'results':rows},indent=2)+'\n')
        print(json.dumps({k:v for k,v in row.items() if k!='A'}),flush=True)

if __name__=='__main__': main()
