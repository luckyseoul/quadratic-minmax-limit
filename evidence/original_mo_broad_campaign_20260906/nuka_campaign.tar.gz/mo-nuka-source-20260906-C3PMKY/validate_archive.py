#!/usr/bin/env python3
"""Check frozen source/input hashes and inventory all self-contained artifacts."""
import argparse, hashlib, json
from pathlib import Path

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--write-inventory',action='store_true')
    args=parser.parse_args(); root=Path(__file__).resolve().parent
    driver_by_stage={'first':'campaign.py','broad':'campaign.py','exact32':'verify32.py',
                     'seeded':'seeded_campaign.py','trades32':'score_trades.py',
                     'trades64':'score_trades.py','trades128':'score_trades.py',
                     'plain-walsh-fixed':'walsh_spin_campaign.py',
                     'seeded-v3':'seeded_campaign_v3.py','odd-principals':'principal_odd.py'}
    checked_sources=[]; checked_inputs=[]
    for stage,driver in driver_by_stage.items():
        folder=root/('mo-nuka-20260906-'+stage)
        manifest=json.loads((folder/'manifest.json').read_text())
        assert manifest['source_sha256']==sha(root/driver), ('source',stage,driver)
        checked_sources.append(stage)
        if 'frozen_core_sha256' in manifest:
            assert manifest['frozen_core_sha256']==sha(root/'campaign.py'), ('core',stage)
        for item in manifest.get('imported_sources',[]):
            original=Path(item['path']); parent=original.parent.name
            base=root/'inputs'/parent if 'cpu-seeds' in parent else root/parent
            candidate=base/original.name
            assert candidate.is_file() and sha(candidate)==item['file_sha256'], ('input',stage,str(candidate))
            checked_inputs.append(str(candidate.relative_to(root)))
        if stage.startswith('trades'):
            order=stage[6:]; bank=root/'inputs'/('symmetric_hadamard_trades_n'+order+'.npz')
            assert sha(bank)==manifest['bank_sha256'], ('trade_bank',stage)
        if stage=='exact32':
            assert sha(root/'mo-nuka-20260906-broad/bank_n32.npz')==manifest['bank_sha256']
        if stage=='odd-principals':
            source=root/'mo-nuka-20260906-exact32/verified_n32_0.json'
            assert sha(source)==manifest['source_input_file_sha256']
    rows=[]
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.name=='ARCHIVE_CHECKS.json': continue
        rows.append({'path':str(path.relative_to(root)),'bytes':path.stat().st_size,'sha256':sha(path)})
    result={'status':'PASS','source_manifests_checked':checked_sources,
            'imported_seed_files_checked':len(checked_inputs),'unique_imported_seed_files':len(set(checked_inputs)),
            'files':rows,'file_count':len(rows),'total_bytes':sum(row['bytes'] for row in rows)}
    inventory=root/'ARCHIVE_CHECKS.json'
    if args.write_inventory: inventory.write_text(json.dumps(result,indent=2)+'\n')
    else:
        expected=json.loads(inventory.read_text())
        assert expected['files']==rows, 'Archive contents differ from frozen inventory'
    print(json.dumps({k:v for k,v in result.items() if k!='files'}))

if __name__=='__main__': main()
