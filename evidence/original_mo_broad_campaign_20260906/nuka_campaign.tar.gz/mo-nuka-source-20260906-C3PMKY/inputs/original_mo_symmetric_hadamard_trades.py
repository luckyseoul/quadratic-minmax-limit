#!/usr/bin/env python3
"""Generate exact flat, symmetric signing families by four-coordinate trades.

For u in {+-1}^4 put Q=I-u*u.T/2 on four coordinates. Q is orthogonal.
Retain Q H Q only when every entry is still a sign. Thus symmetry, H^2=nI
and trace are preserved EXACTLY. A=H-diag(H) is the original zero-diagonal
signing. These are candidate constructions, not minimum certificates.
"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
import argparse
import hashlib
import json
import time
from pathlib import Path
import numpy as np


def sylvester(n):
    h = np.ones((1, 1), dtype=np.int32)
    while len(h) < n:
        h = np.block([[h, h], [h, -h]])
    assert len(h) == n
    return h


def gauge(h):
    signs = np.ones(len(h), dtype=np.int32)
    signs[1:] = h[0, 1:]
    return h * signs[:, None] * signs[None, :]


def validate(h):
    n = len(h)
    assert np.array_equal(h, h.T) and np.all(np.abs(h) == 1)
    assert np.array_equal(h @ h, n * np.eye(n, dtype=np.int32))
    assert int(np.trace(h)) == 0


def trade(h, rng):
    n = len(h)
    # A full closed quadruple suffices for all outside entries to stay signs.
    lookup = {}
    for i, row in enumerate(h):
        lookup[row.tobytes()] = (i, 1)
        lookup[(-row).tobytes()] = (i, -1)
    quadruples = []
    for _ in range(96):
        three = rng.choice(n, 3, replace=False)
        product = h[three[0]] * h[three[1]] * h[three[2]]
        match = lookup.get(product.tobytes())
        if match is not None and match[0] not in three:
            quadruples.append((np.append(three, match[0]), match[1]))
            if len(quadruples) >= 4:
                break
    if not quadruples:
        # Deterministic collision fallback also finds sparse closed quadruples.
        pairs = {}
        for i in range(n):
            for j in range(i + 1, n):
                row = h[i] * h[j]
                sign = int(row[0])
                key = (row * sign).tobytes()
                previous = pairs.get(key)
                if previous is not None:
                    k, l, old_sign = previous
                    if len({i, j, k, l}) == 4:
                        quadruples.append((np.array([i, j, k, l]), sign * old_sign))
                        break
                else:
                    pairs[key] = (i, j, sign)
            if quadruples:
                break
    for selected, parity in quadruples:
        outside = np.setdiff1d(np.arange(n), selected)
        choices = [(1, a, b, parity*a*b) for a in (-1, 1) for b in (-1, 1)]
        for ci in rng.permutation(len(choices)):
            u = np.array(choices[ci], dtype=np.int32)
            twice_q = 2*np.eye(4, dtype=np.int32) - np.outer(u, u)
            cross_num = twice_q @ h[np.ix_(selected, outside)]
            inner_num = twice_q @ h[np.ix_(selected, selected)] @ twice_q
            if np.any(cross_num % 2) or np.any(inner_num % 4):
                continue
            cross, inner = cross_num // 2, inner_num // 4
            if not np.all(np.abs(cross) == 1) or not np.all(np.abs(inner) == 1):
                continue
            result = h.copy()
            result[np.ix_(selected, outside)] = cross
            result[np.ix_(outside, selected)] = cross.T
            result[np.ix_(selected, selected)] = inner
            if not np.array_equal(result, h):
                return result, {"vertices": selected.tolist(), "u": u.tolist()}
    return None, None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("--orders", default="32,64,128")
    parser.add_argument("--count", type=int, default=2048)
    parser.add_argument("--seed", type=int, default=2026090661)
    args = parser.parse_args()
    output = Path(args.out)
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    source_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    for n in map(int, args.orders.split(",")):
        begun = time.time()
        h = sylvester(n)
        validate(h)
        stored, records, seen = [], [], set()
        attempts, accepted, restarts = 0, 0, 0
        pending = []
        while len(stored) < args.count and attempts < args.count*32:
            if attempts and attempts % 512 == 0:
                h = sylvester(n)
                p = rng.permutation(n)
                h = gauge(h[np.ix_(p, p)])
                restarts += 1
                pending = []
            attempts += 1
            changed, operation = trade(h, rng)
            if changed is None:
                continue
            h = changed
            accepted += 1
            pending.append(operation)
            canonical = gauge(h)
            a = canonical.copy()
            np.fill_diagonal(a, 0)
            digest = hashlib.sha256(a.astype(np.int8).tobytes()).hexdigest()
            if digest in seen:
                continue
            # Check the complete identity for EVERY emitted construction.
            validate(canonical)
            seen.add(digest)
            stored.append(canonical.astype(np.int8))
            records.append({"index": len(stored)-1, "sha": digest,
                            "attempt": attempts, "accepted": accepted,
                            "restart": restarts, "last_trade": operation})
            if len(stored) % 128 == 0:
                print(json.dumps({"n": n, "unique_candidates": len(stored),
                                  "attempts": attempts, "accepted": accepted,
                                  "seconds": time.time()-begun}), flush=True)
        archive = output / f"symmetric_hadamard_trades_n{n}.npz"
        full = np.asarray(stored, dtype=np.int8)
        aa = full.copy()
        aa[:, np.arange(n), np.arange(n)] = 0
        np.savez_compressed(archive, H=full, A=aa)
        metadata = {"n": n, "seed": args.seed, "source_sha256": source_sha,
                    "unique_candidates": len(stored), "attempts": attempts,
                    "accepted_trades": accepted, "restarts": restarts,
                    "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                    "seconds": time.time()-begun, "records": records,
                    "classification": "exact symmetric Hadamard constructions; Phi unscored"}
        (output / f"symmetric_hadamard_trades_n{n}.json").write_text(
            json.dumps(metadata, indent=2) + "\n")
        print(json.dumps({k: v for k, v in metadata.items() if k != "records"}), flush=True)


if __name__ == "__main__":
    main()
