#!/usr/bin/env python3
"""Fresh exact evolutionary stage importing CPU and GPU winner matrices."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse, hashlib, importlib.util, json, time
from pathlib import Path
import numpy as np

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--core',required=True)
    ap.add_argument('--seed-dir',action='append',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--orders',default='24,25,26,28,30,32')
    ap.add_argument('--rounds',type=int,default=256)
    ap.add_argument('--batch',type=int,default=32)
    ap.add_argument('--seconds-per-order',type=float,default=60)
    ap.add_argument('--seed',type=int,default=2026090641)
    args=ap.parse_args()
    spec=importlib.util.spec_from_file_location('mo_frozen_core',args.core)
    core=importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
    old='all=(1u<<n)-1u;'; assert core.KERNEL.count(old)==1
    core.KERNEL=core.KERNEL.replace(old,'all=(n==32?0xffffffffu:(1u<<n)-1u);')
    sc=core.Scorer(); core.selftest(sc)
    rng=np.random.default_rng(args.seed); seeds=[]; seen_seed=set(); sources=[]
    for dirname in args.seed_dir:
        for path in sorted(Path(dirname).glob('*.json')):
            if not any(path.name.startswith(p) for p in ['best_n','adaptive_best_n','principal_best_n','verified_n']): continue
            obj=json.loads(path.read_text())
            if 'A' not in obj: continue
            a=core.gauge(np.asarray(obj['A'],dtype=np.int8)); core.good(a)
            sha=core.digest(a)
            if sha in seen_seed: continue
            seen_seed.add(sha); seeds.append((a,path.name))
            sources.append({'path':str(path),'file_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'matrix_sha256':sha,'n':len(a)})
    assert seeds
    output=Path(args.out); output.mkdir(parents=True,exist_ok=True)
    manifest={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'frozen_core_sha256':hashlib.sha256(Path(args.core).read_bytes()).hexdigest(),
              'device':sc.device,'seed':args.seed,'orders':args.orders,'rounds':args.rounds,
              'batch':args.batch,'seconds_per_order':args.seconds_per_order,'imported_sources':sources,
              'classification':'exhaustive_GPU_integer_scores_for_every_candidate; not_global_optimizer_certificate'}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    records=[]; start=time.time()
    kinds=['edges','edges','rowpatch','clique','rectangle','spectral','covminus','covplus','restart']
    for n in map(int,args.orders.split(',')):
        assert 2<=n<=32
        bank=[]; seen=set(); hist={}; count=0; best=None; t0=time.time()
        matching=[(a,label) for a,label in seeds if len(a)==n]
        larger=[(a,label) for a,label in seeds if len(a)>n]
        for rd in range(args.rounds+1):
            matrices=[]; labels=[]
            for j in range(args.batch):
                if rd==0 and j<len(matching):
                    a,label=matching[j]; a=a.copy(); label='import:'+label
                elif (rd==0 or j==0) and larger:
                    parent,label=larger[int(rng.integers(len(larger)))]; ix=rng.choice(len(parent),n,replace=False)
                    a=core.gauge(parent[np.ix_(ix,ix)]); label='principal:'+label
                elif rd==0 and matching:
                    parent,_=matching[int(rng.integers(len(matching)))]; label=kinds[j%len(kinds)]
                    a=core.mutate(parent,label,rng,rd)
                elif rd==0 or not bank:
                    label=['hadamard','paley','reflection','random'][j%4]; a=core.seed_matrix(n,label,rng)
                else:
                    label=kinds[(j+rd)%len(kinds)]; parent=bank[int(rng.integers(len(bank)))]['A']
                    a=core.mutate(parent,label,rng,rd)
                sha=core.digest(a)
                for attempt in range(20):
                    if sha not in seen: break
                    a=core.mutate(a,'edges',rng,rd); sha=core.digest(a)
                seen.add(sha); matrices.append(a); labels.append(label)
            scores=sc.score(np.asarray(matrices),True,0,0); count+=len(matrices)
            fresh=[]
            for a,label,(value,peaks,witness) in zip(matrices,labels,scores):
                core.verify_witness(a,value,witness); hist[label]=hist.get(label,0)+1
                fresh.append({'A':a,'Phi':value,'peaks':peaks,'witness':witness,'label':label,'sha':core.digest(a),'round':rd})
            combined=bank+fresh; combined.sort(key=lambda z:(z['Phi'],z['peaks'],z['sha']))
            bank=[]; hashes=set()
            for item in combined:
                if item['sha'] not in hashes: bank.append(item); hashes.add(item['sha'])
                if len(bank)==24: break
            winner=combined[0]
            if best is None or (winner['Phi'],winner['peaks'])<(best['Phi'],best['peaks']):
                best=winner
                saved={k:v for k,v in best.items() if k!='A'}
                saved.update(n=n,A=best['A'].tolist(),normalized_Phi=best['Phi']/n**1.5,
                             score_exact=True,candidates_scored=count,elapsed_seconds=time.time()-t0)
                (output/f'best_n{n}.json').write_text(json.dumps(saved,indent=2)+'\n')
            if rd and rd%8==0: bank=bank[:20]+fresh[-4:]
            elapsed=time.time()-t0
            if rd%8==0 or rd==args.rounds or elapsed>=args.seconds_per_order:
                row={'n':n,'round':rd,'candidates':count,'unique_candidates':len(seen),
                     'best_Phi':best['Phi'],'best_alpha':best['Phi']/n**1.5,'exact':True,
                     'elapsed_seconds':elapsed,'mutations':hist.copy()}
                print(json.dumps(row),flush=True)
                with (output/'progress.jsonl').open('a') as log: log.write(json.dumps(row)+'\n')
            if elapsed>=args.seconds_per_order: break
        records.append(row)
        np.savez_compressed(output/f'bank_n{n}.npz',matrices=np.asarray([z['A'] for z in bank]),scores=np.asarray([z['Phi'] for z in bank]))
        (output/'summary.json').write_text(json.dumps({'manifest':manifest,'orders':records,'elapsed_seconds':time.time()-start},indent=2)+'\n')
    print(json.dumps({'status':'completed','elapsed_seconds':time.time()-start}),flush=True)

if __name__=='__main__': main()
