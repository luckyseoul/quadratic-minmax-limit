#!/usr/bin/env python3
"""Bounded odd-order exact principal-source coverage from a fixed n32 winner."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse, hashlib, importlib.util, itertools, json, time
from pathlib import Path
import numpy as np

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--core',required=True)
    ap.add_argument('--source',required=True); ap.add_argument('--out',required=True)
    ap.add_argument('--seed',type=int,default=2026090713); args=ap.parse_args()
    spec=importlib.util.spec_from_file_location('mo_frozen_core',args.core)
    core=importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
    old='all=(1u<<n)-1u;'; assert core.KERNEL.count(old)==1
    core.KERNEL=core.KERNEL.replace(old,'all=(n==32?0xffffffffu:(1u<<n)-1u);')
    sc=core.Scorer(); core.selftest(sc)
    obj=json.loads(Path(args.source).read_text()); source=np.asarray(obj['A'],dtype=np.int8)
    core.good(source); assert len(source)==32
    output=Path(args.out); output.mkdir(parents=True,exist_ok=True)
    manifest={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'frozen_core_sha256':hashlib.sha256(Path(args.core).read_bytes()).hexdigest(),
              'source_input_file_sha256':hashlib.sha256(Path(args.source).read_bytes()).hexdigest(),
              'source_matrix_sha256':core.digest(source),'seed':args.seed,'device':sc.device,
              'classification':'exact_Phi_for_selected_principal_sources; no_global_optimizer_claim'}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    rng=np.random.default_rng(args.seed); summaries=[]
    for n,target,batch in [(31,32,4),(29,256,16),(27,512,32)]:
        begun=time.time(); subsets=[]; matrices=[]; seen_subsets=set(); seen_matrices=set()
        while len(subsets)<target:
            removed=(len(subsets),) if n==31 else tuple(sorted(rng.choice(32,32-n,replace=False).tolist()))
            if removed in seen_subsets: continue
            kept=np.asarray([i for i in range(32) if i not in removed],dtype=int)
            a=core.gauge(source[np.ix_(kept,kept)]); sha=core.digest(a)
            if n!=31 and sha in seen_matrices: continue
            seen_subsets.add(removed); seen_matrices.add(sha); subsets.append(kept.tolist()); matrices.append(a)
        rows=[]; best=None
        for offset in range(0,target,batch):
            chunk=np.asarray(matrices[offset:offset+batch]); scores=sc.score(chunk,True,0,0)
            for j,(a,(value,peaks,witness)) in enumerate(zip(chunk,scores)):
                core.verify_witness(a,value,witness); assert value<=80
                row={'n':n,'index':offset+j,'kept_vertices':subsets[offset+j],'Phi':value,
                     'normalized_Phi':value/n**1.5,'peaks_fixed_first_spin':peaks,
                     'witness_masks':witness,'matrix_sha256':core.digest(a),'score_exact':True}
                rows.append(row)
                if best is None or (value,peaks)<(best['Phi'],best['peaks_fixed_first_spin']):
                    best=row
                    (output/f'best_n{n}.json').write_text(json.dumps(dict(row,A=a.tolist()),indent=2)+'\n')
        np.savez_compressed(output/f'principal_bank_n{n}.npz',matrices=np.asarray(matrices),kept_vertices=np.asarray(subsets),scores=np.asarray([r['Phi'] for r in rows]))
        (output/f'scores_n{n}.json').write_text(json.dumps(rows,indent=2)+'\n')
        summary={'n':n,'candidates':len(rows),'unique_subsets':len(seen_subsets),
                 'unique_matrices':len(seen_matrices),'best_Phi':best['Phi'],
                 'best_alpha':best['Phi']/n**1.5,'elapsed_seconds':time.time()-begun}
        summaries.append(summary); print(json.dumps(summary),flush=True)
        (output/'summary.json').write_text(json.dumps({'manifest':manifest,'orders':summaries},indent=2)+'\n')

if __name__=='__main__': main()
