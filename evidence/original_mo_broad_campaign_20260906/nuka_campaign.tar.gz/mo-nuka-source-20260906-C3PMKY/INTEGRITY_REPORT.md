# Nuka GPU campaign integrity checkpoint

Final checkpoint prepared 2026-09-06 for the05:08 UTC handoff.
All files are temporary campaign artifacts, not canonical repository changes.
Host: NUKA 192.168.1.192; OpenCL device gfx1201 / RX 9070 XT.
The CPU feeder uses OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1.

## Completed work before seeded-v3

| Local result directory | Matrix evaluations | Exhaustive integer Phi evaluations | Result |
| --- | ---: | ---: | --- |
| mo-nuka-20260906-first | 240 | 240 | n16/20/24: 32/48/58 |
| mo-nuka-20260906-broad | 196992 | 98496 | Exact n16/20/24: 32/46/58; larger orders only lower estimates |
| mo-nuka-20260906-exact32 | 4 | 4 | Four n32 matrices, Phi=80, 4480 fixed-first-spin peaks each |
| mo-nuka-20260906-seeded | 37600 | 37600 | n20/24/25/26/28/30/32: 42/56/60/65/70/75/80 |
| mo-nuka-20260906-trades32 | 2048 | 2048 | Exact histogram Phi82:5, Phi84:1129, Phi86:914 |
| mo-nuka-20260906-trades64 | 2048 | 0 | 1947 reach exact spectral upper256 by a checked witness; remaining scores initially lower bounds |
| mo-nuka-20260906-trades128 | 2048 | 0 | Lowest witnessed lower678, not an upper bound |
| Total | 240980 | 138388 | No global optimizer or asymptotic theorem claim |

Counts above are evaluation records. SHA deduplication was within each search
wave/order, not across waves; do not describe the total as globally unique
matrices or distinct equivalence classes. Exact rescoring deliberately repeats
some previously heuristic matrices. Small selftest calls are excluded.

The three traded banks also received 16384 starts per matrix: 100663296 starts.
The earlier broad large-order bank received 50429952 starts. These are executed
starts, not a claim that every sampled spin state was unique.

The fixed plain-Walsh campaign separately executed 6291456 starts and 50331648
local relaxations, split equally over n32, n128, n512. Canonical CPU-checked
lower bounds were 80, 676, 5418. A second CPU check using a direct butterfly
Walsh-Hadamard transform independently reproduced all three signed energies
and the transform squared norms n^2. Only n32=80 is independently exhaustive;
676 and 5418 are witnessed lower bounds, not upper bounds.

## Kernel validation and the isolated rejected bug

The frozen original core is campaign.py, SHA256
b3000d2b87dc5c6b8a8b407d75adab00c6b470002354f86a884ef51712068343.

Its integer cut kernel fixes the first spin and exhausts every remaining spin.
Each driver ran 16 exact CPU/GPU agreement selftests at orders4,6,8,10, checking
both the maximum and the number of maximizers. Every accepted matrix maximum
also had its returned witness evaluated with CPU int64 arithmetic.

The original small-order kernel has a guarded sid for inactive workgroup lanes.
The n32 extension was isolated in new drivers: replace the undefined 1u<<32
vertex-mask expression by 0xffffffffu when n==32. The original core source was
not overwritten. The n32 state count is uint 2^31; returned masks are widened
before multiplication by2. Parent independently enumerated the original n32
winner with a CPU field-update kernel: all2^31 states, extrema +/-80, 2240 peaks
per phase. CPU witnesses alone are lower certificates; the full enumeration
is what establishes the upper bound for these exact scores.

The FIRST version of the NEW walsh_spin_campaign.py kick kernel had
`if(abs(q)>best)` with best initialized to -1. OpenCL abs(int) returns uint,
so this comparison never updated best. Its first CPU witness check failed at
n32 and the run aborted; no score from either failed diagnostic run was
accepted. The repaired code uses `if((int)abs(q)>best)`. It passed the small
new-kernel smoke and every batch-maximum witness check in the completed strong
run, including signed-permutation remapping to canonical Sylvester matrices.

This bug did NOT occur in campaign.py or its exact/trade/seeded callers. In
that frozen core, abs(q) is assigned directly to a bounded nonnegative int;
there is no comparison of unsigned abs(q) with a negative best sentinel.
All earlier accepted witnesses were checked before this new kernel existed.

All2048 H matrices in each traded bank were independently rechecked using
integer arithmetic: symmetry, entries +/-1, trace0, H^2=nI, and A=H-diag(H).
Thus the displayed spectral bounds were genuine upper bounds even when the
spin maximum was only heuristic.

The CPU agent later found checked +8 eigensign witnesses for all16 shortlisted
n64 matrices, including the misleadingly low heuristic244 cases. Their actual
Phi is256. Evidence is in the separate CPU campaign eigen64_first directory;
this supersedes the corresponding heuristic-only score labels, not the raw
observations. The earlier1947 saturated cases were already exact from their
own GPU-generated, CPU-checked witnesses and the structural upper bound.

## Frozen source hashes

- campaign.py: b3000d2b87dc5c6b8a8b407d75adab00c6b470002354f86a884ef51712068343
- verify32.py: f02cece5b7984f86faf00585895317b84dcc26a60caedf1a186da5e623339251
- seeded_campaign.py: e46c3f5345251fe3e98fba5ebac392b3a909d56f3bd6043fc04e65318a95b62a
- score_trades.py: 5848a086eade9c2342ea845b5caeee35c068d4ece957befc9f16b969bb641e78
- walsh_spin_campaign.py, repaired accepted version: da913737c3ca2fc8a50ede13898a575e851953de89971890eaadbd1726e64030
- seeded_campaign_v3.py: a47caa9db84623c564e48c0de5d8c8e3d0bb65ff7fe91b7a48c4e58f42446f79
- principal_odd.py: 0f547c413025c5b34ed42fb923dd5e5e78661932098b75b44a96db366846c72b

## Completed summary hashes

- broad/summary.json: 2d6cfc016dfd66fbb4e9a87ca19992d576d5379407cf83972db0dd8fed571798
- seeded/summary.json: c3f1d949c93e6c04249dc313ebc37742ea034ddcdebd21dbdabab1cfc9b4f831
- trades32/summary.json: f327a5d2acf957700a2dac277be8f6c3c8e96bed983effb83b1eca24913249f4
- trades64/summary.json: a1e6ef98f6784a8ac6ffebed82743f23a240bece39b52f7da35b0b870329a834
- trades128/summary.json: f02dd12c616da9db1df5332bc5cc9d1dec0f29d6163aa1465464d89830dc27e5
- plain-walsh-fixed/summary.json: 8d837056470ef1ba8f622181544c5c5c91741637ca795059c281912d70c5d728

## Final wave and replay

seeded-v3 imports the latest CPU principal sources and V100 K26 Phi61 source,
then applies edge, row-patch, clique, rectangle, spectral, both covariance-sign,
and restart variations. All candidate matrices are scored exhaustively.
Its completed output is mo-nuka-20260906-seeded-v3 in this archive.

Replay from the transferred source paths on Nuka:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -u /tmp/mo_nuka_seeded_campaign_v3_20260906.py --core /tmp/mo_nuka_campaign_20260906.py --seed-dir /tmp/mo-nuka-20260906-cpu-seeds-v3 --seed-dir /tmp/mo-nuka-20260906-seeded --out /tmp/mo-nuka-20260906-seeded-v3-replay --orders 24,26,28,32 --rounds 100000 --batch 32 --seconds-per-order 180 --seed 2026090701
```

The time-limited number of rounds may differ on replay. Seed/input hashes,
actual rounds, evaluation counts, and winners are retained in the manifests
and progress/summary files. Replaying a fixed number of completed rounds uses
the same seeded candidate construction, subject to numerical eigensolver
behavior in the floating-point mutation proposals; every resulting score is
still an exact integer exhaustive score.

## Final completion and archive verification

All owned GPU jobs completed naturally before05:06:45 UTC; no process was
killed, and no new broad search was launched after this freeze.

| Final additional stage | Order | Matrix evaluations | Within-order distinct matrices | Exact best Phi |
| --- | ---: | ---: | ---: | ---: |
| seeded-v3 | 24 | 170432 | 170432 | 56 |
| seeded-v3 | 26 | 77760 | 77760 | 61 |
| seeded-v3 | 28 | 23456 | 23456 | 70 |
| seeded-v3 | 32 | 928 | 928 | 80 |
| odd-principals | 31 | 32 | 32 | 79 |
| odd-principals | 29 | 256 | 256 | 72 |
| odd-principals | 27 | 512 | 512 | 67 |

The final added stages contain273376 exhaustive matrix evaluations. Grand
totals are514356 matrix-evaluation records, of which411764 used exhaustive
integer spin enumeration. These remain evaluation counts, not a global
equivalence-class count. All accepted matrix maxima have CPU-checked witnesses.

The last broad wave retained its imported/baseline winners. The odd stage
filled previously missing orders using all32 principal n31 subsets and the
stated distinct sampled n29/n27 subsets of the independently certified H32
source. There is no optimizer theorem or asymptotic closure claim.

Final summary hashes:

- seeded-v3/summary.json: 2f3d761236b17273cbc35a49dd560c7922fd77216969b5eb4c7ac044b990517f
- odd-principals/summary.json: 1b46d680f9c0d6f0b39bf8e8584c9d4db3ac095a40d2c4d7c75773d92d6c8aa1

All immutable CPU seed snapshots and traded-Hadamard input arrays/metadata
are under inputs/. Environment versions are in ENVIRONMENT.json. The original
rejected kick-kernel source was retained byte-for-byte and matches its original
SHA b4fd3c2a047ffa04e4beea075ee9b6d564d8e27adebb4123556e69946da5da1e;
its diagnostics are explicitly excluded from accepted counts/evidence.

Persistent search progress logs and per-candidate score/witness JSONs are
included. Short verification drivers did not persist their transient stdout;
their complete result/summary JSONs are retained instead, without inventing
stdout transcripts.

The archive is self-contained for data and source code. A machine with NumPy,
PyOpenCL, and a compatible OpenCL GPU is required to replay GPU stages.

```sh
python3 validate_archive.py
python3 replay.py odd-principals --out /tmp/mo-nuka-odd-replay-fresh
```

validate_archive.py checks all accepted source hashes, imported seed-file
hashes, input bank hashes, and every frozen file against ARCHIVE_CHECKS.json.
Replay uses archive-relative paths, not the original external /tmp layout.
