#!/usr/bin/env python3
"""Replay one frozen Nuka campaign stage using only files in this archive."""
import argparse, os, subprocess, sys
from pathlib import Path

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['first','broad','exact32','seeded','trades32','trades64','trades128','plain-walsh','seeded-v3','odd-principals'])
    parser.add_argument('--out',required=True,help='New, nonexistent output directory')
    args=parser.parse_args(); root=Path(__file__).resolve().parent
    output=Path(args.out).resolve()
    if output.exists(): parser.error('Output already exists; choose a fresh directory')
    def local(name): return str(root/name)
    core=['--core',local('campaign.py')]
    name=args.stage
    if name=='first':
        script='campaign.py'; tail=['--orders','16,20,24','--rounds','4','--batch','16']
    elif name=='broad':
        script='campaign.py'; tail=['--orders','16,20,24,32,64,128','--rounds','512','--batch','64','--starts','512']
    elif name=='exact32':
        script='verify32.py'; tail=core+['--bank',local('mo-nuka-20260906-broad/bank_n32.npz'),'--winner',local('mo-nuka-20260906-broad/best_n32.json'),'--limit','4']
    elif name=='seeded':
        script='seeded_campaign.py'; tail=core+['--seed-dir',local('inputs/mo-nuka-20260906-cpu-seeds'),'--seed-dir',local('mo-nuka-20260906-broad'),'--orders','20,24,25,26,28,30,32','--rounds','256','--batch','32','--seconds-per-order','30']
    elif name.startswith('trades'):
        order=name[6:]; script='score_trades.py'; tail=core+['--bank',local('inputs/symmetric_hadamard_trades_n'+order+'.npz'),'--starts','16384','--batch','32','--exact-top','2048']
    elif name=='plain-walsh':
        script='walsh_spin_campaign.py'; tail=core+['--orders','32,128,512','--starts','65536','--batch','4','--rounds','8','--epochs','8']
    elif name=='seeded-v3':
        script='seeded_campaign_v3.py'; tail=core+['--seed-dir',local('inputs/mo-nuka-20260906-cpu-seeds-v3'),'--seed-dir',local('mo-nuka-20260906-seeded'),'--orders','24,26,28,32','--rounds','100000','--batch','32','--seconds-per-order','180','--seed','2026090701']
    else:
        script='principal_odd.py'; tail=core+['--source',local('mo-nuka-20260906-exact32/verified_n32_0.json')]
    environment=os.environ.copy(); environment['OPENBLAS_NUM_THREADS']='1'; environment['OMP_NUM_THREADS']='1'
    command=[sys.executable,local(script),'--out',str(output)]+tail
    print('Running:', ' '.join(command),flush=True)
    subprocess.run(command,check=True,env=environment)

if __name__=='__main__': main()
