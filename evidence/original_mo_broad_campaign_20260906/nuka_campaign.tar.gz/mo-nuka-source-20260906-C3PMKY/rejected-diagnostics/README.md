# Rejected diagnostic runs - excluded from accepted evidence

The two included directories contain manifests from failed first attempts at
the NEW strong Walsh kick kernel. Both runs aborted at the first CPU witness
check, before accepting any maximum or writing a best matrix/witness file.

The defect was OpenCL signed/unsigned comparison: abs(int) is unsigned, while
the new `best` sentinel was -1. The condition `abs(q)>best` therefore remained
false, leaving all returned best scores at -1 and witness buffers unwritten.
The fix was an explicit signed cast in the comparison. This code was separate
from the frozen core used by all earlier exact and heuristic matrix searches.

First rejected run: orders32,128,512; starts65536; batch4; rounds8; epochs8.
It aborted with AssertionError at the CPU witness equality check.

Second diagnostic run: n32; starts64; batch2; rounds1; epochs1.
It reported:

```
AssertionError: (32, 0, 0, 0, -1, 38, [90194313235])
```

The score -1 is the unchanged sentinel, not a mathematical observation. No
numeric claim or campaign count includes either failed diagnostic run.
The repaired accepted source and its complete successful artifacts are one
directory above. Its maxima were checked both by dense CPU integer products
and, for the final canonical witnesses, an independent butterfly transform.
