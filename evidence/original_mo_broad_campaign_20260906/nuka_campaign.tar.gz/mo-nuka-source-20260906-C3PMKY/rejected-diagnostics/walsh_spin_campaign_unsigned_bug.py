#!/usr/bin/env python3
"""Strong multistart/kick spin maximization on exact Sylvester sources.

Equivalent signed permutations are mapped back to the same canonical source.
Every reported score is a CPU-checked lower bound, never a heuristic upper.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse, hashlib, importlib.util, json, math, time
from pathlib import Path
import numpy as np
import pyopencl as cl

KERNEL=r'''
uint nextr(uint *s) { uint x=*s; x^=x<<13; x^=x>>17; x^=x<<5; *s=x; return x; }
__kernel void maximize(__global const char *a, int n, int starts, int epochs,
 uint seed, __global int *out, __global ulong *masks) {
 uint t=get_global_id(0), b=get_global_id(1), rnd=seed^(t*747796405u+b*2891336453u+1u);
 char x[512]; short h[512]; int phase=(t&1)?-1:1, words=(n+63)/64;
 for(int i=0;i<n;i++) x[i]=(nextr(&rnd)&1)?1:-1;
 if(t<2) for(int i=0;i<n;i++) x[i]=1;
 int q=0;
 for(int i=0;i<n;i++) { int field=0; for(int j=0;j<n;j++) field+=(int)a[b*n*n+i*n+j]*x[j]; h[i]=field; q+=x[i]*field; }
 q/=2; int best=-1;
 for(int epoch=0;epoch<epochs;epoch++) {
  for(int step=0;step<4*n;step++) {
   int at=-1,gain=0; uint offset=nextr(&rnd)%n;
   for(int j=0;j<n;j++) { int i=(j+offset)%n, g=-2*phase*x[i]*h[i]; if(g>gain) {gain=g;at=i;} }
   if(at<0) break;
   int old=x[at]; q-=2*old*h[at];
   for(int i=0;i<n;i++) h[i]-=2*old*(int)a[b*n*n+i*n+at];
   x[at]=-old;
  }
  if(abs(q)>best) {
   best=abs(q);
   for(int word=0;word<words;word++) {
    ulong mask=0;
    for(int j=0;j<64;j++) { int i=64*word+j; if(i<n && x[i]<0) mask|=((ulong)1)<<j; }
    masks[(b*starts+t)*words+word]=mask;
   }
  }
  // Short low-field or uniform kicks diversify the basin before re-relaxing.
  int kicks=1+(int)(nextr(&rnd)%4);
  for(int kick=0;kick<kicks;kick++) {
   int at=nextr(&rnd)%n;
   if(epoch&1) for(int trial=0;trial<8;trial++) {
    int test=nextr(&rnd)%n; if(abs((int)h[test])<abs((int)h[at])) at=test;
   }
   int old=x[at]; q-=2*old*h[at];
   for(int i=0;i<n;i++) h[i]-=2*old*(int)a[b*n*n+i*n+at];
   x[at]=-old;
  }
 }
 out[b*starts+t]=best;
}
'''

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--core',required=True); ap.add_argument('--out',required=True)
    ap.add_argument('--orders',default='32,128,512'); ap.add_argument('--starts',type=int,default=65536)
    ap.add_argument('--batch',type=int,default=4); ap.add_argument('--rounds',type=int,default=8)
    ap.add_argument('--epochs',type=int,default=8); ap.add_argument('--seed',type=int,default=2026090689)
    args=ap.parse_args()
    spec=importlib.util.spec_from_file_location('mo_frozen_core',args.core)
    core=importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
    sc=core.Scorer(); core.selftest(sc); program=cl.Program(sc.ctx,KERNEL).build(); kernel=program.maximize
    output=Path(args.out); output.mkdir(parents=True,exist_ok=True)
    manifest={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'frozen_core_sha256':hashlib.sha256(Path(args.core).read_bytes()).hexdigest(),
              'device':sc.device,'orders':args.orders,'starts':args.starts,'batch':args.batch,
              'rounds':args.rounds,'epochs':args.epochs,'seed':args.seed,
              'classification':'witnessed_lower_bounds_on_canonical_Sylvester_Phi; no_heuristic_upper_claim'}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    rng=np.random.default_rng(args.seed); records=[]
    for n in map(int,args.orders.split(',')):
        assert 2<=n<=512 and n&(n-1)==0
        h=core.sylvester(n).astype(np.int32); assert np.array_equal(h@h,n*np.eye(n,dtype=np.int32)) and np.trace(h)==0
        a=h.copy(); np.fill_diagonal(a,0); canonical=a.astype(np.int8)
        words=(n+63)//64; best=-1; t0=time.time(); histogram={}
        for rd in range(args.rounds):
            matrices=[]; permutations=[]; gauges=[]
            for j in range(args.batch):
                p=rng.permutation(n) if j else np.arange(n)
                signs=(2*rng.integers(0,2,n)-1).astype(np.int8) if j else np.ones(n,dtype=np.int8)
                matrices.append(canonical[np.ix_(p,p)]*signs[:,None]*signs[None,:]); permutations.append(p); gauges.append(signs)
            matrices=np.ascontiguousarray(matrices,dtype=np.int8); mf=cl.mem_flags
            ab=cl.Buffer(sc.ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=matrices)
            scores=np.empty((args.batch,args.starts),dtype=np.int32)
            masks=np.empty((args.batch,args.starts,words),dtype=np.uint64)
            ob=cl.Buffer(sc.ctx,mf.WRITE_ONLY,scores.nbytes); wb=cl.Buffer(sc.ctx,mf.WRITE_ONLY,masks.nbytes)
            kernel(sc.queue,(args.starts,args.batch),None,ab,np.int32(n),np.int32(args.starts),np.int32(args.epochs),np.uint32(args.seed+n+rd),ob,wb)
            cl.enqueue_copy(sc.queue,scores,ob); cl.enqueue_copy(sc.queue,masks,wb).wait()
            for j in range(args.batch):
                column=int(scores[j].argmax()); value=int(scores[j,column]); witness=masks[j,column]
                x=np.asarray([-1 if (int(witness[i//64])>>(i%64))&1 else 1 for i in range(n)],dtype=np.int64)
                assert abs(int(x@matrices[j].astype(np.int64)@x)//2)==value
                original=np.empty(n,dtype=np.int64); original[permutations[j]]=x*gauges[j]
                assert abs(int(original@a.astype(np.int64)@original)//2)==value
                histogram[value]=histogram.get(value,0)+1
                if n==32: assert value<=80
                if value>best:
                    best=value
                    saved={'n':n,'Phi_lower':best,'normalized_lower':best/n**1.5,
                           'matrix_sha256':core.digest(canonical),'canonical_witness':original.tolist(),
                           'Q_witness':int(original@a.astype(np.int64)@original)//2,
                           'round':rd,'equivalent_index':j,'starts_scored':(rd+1)*args.batch*args.starts,
                           'elapsed_seconds':time.time()-t0,'classification':'CPU_verified_lower_bound_only'}
                    (output/f'best_n{n}.json').write_text(json.dumps(saved,indent=2)+'\n')
            row={'n':n,'round':rd,'starts_scored':(rd+1)*args.batch*args.starts,
                 'local_relaxations':(rd+1)*args.batch*args.starts*args.epochs,
                 'best_lower':best,'normalized_lower':best/n**1.5,'elapsed_seconds':time.time()-t0}
            print(json.dumps(row),flush=True)
            with (output/'progress.jsonl').open('a') as log: log.write(json.dumps(row)+'\n')
        records.append(dict(row,batch_max_histogram=histogram))
        (output/'summary.json').write_text(json.dumps({'manifest':manifest,'orders':records},indent=2)+'\n')

if __name__=='__main__': main()
