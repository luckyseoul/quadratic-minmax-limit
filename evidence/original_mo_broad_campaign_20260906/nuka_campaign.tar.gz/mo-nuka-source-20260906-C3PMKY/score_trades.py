#!/usr/bin/env python3
"""Score a frozen exact Hadamard trade bank; keep upper/lower bounds separate."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse, hashlib, importlib.util, json, math, time
from pathlib import Path
import numpy as np

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--core',required=True)
    ap.add_argument('--bank',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--starts',type=int,default=8192)
    ap.add_argument('--batch',type=int,default=32)
    ap.add_argument('--exact-top',type=int,default=32)
    ap.add_argument('--seed',type=int,default=2026090673)
    args=ap.parse_args()
    spec=importlib.util.spec_from_file_location('mo_frozen_core',args.core)
    core=importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
    old='all=(1u<<n)-1u;'; assert core.KERNEL.count(old)==1
    core.KERNEL=core.KERNEL.replace(old,'all=(n==32?0xffffffffu:(1u<<n)-1u);')
    sc=core.Scorer(); core.selftest(sc)
    data=np.load(args.bank); aa=np.asarray(data['A'],dtype=np.int8); hh=np.asarray(data['H'],dtype=np.int8)
    assert aa.shape==hh.shape and len(aa)>0
    count,n,_=aa.shape; assert n<=128
    output=Path(args.out); output.mkdir(parents=True,exist_ok=True)
    manifest={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'frozen_core_sha256':hashlib.sha256(Path(args.core).read_bytes()).hexdigest(),
              'bank_sha256':hashlib.sha256(Path(args.bank).read_bytes()).hexdigest(),
              'device':sc.device,'n':n,'candidates':count,'starts_per_candidate':args.starts,
              'exact_top':args.exact_top,'seed':args.seed,
              'classification':'heuristic_lower_bounds_plus_exact_structural_spectral_upper; selected_n_le_32_exhaustive'}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    identity=n*np.eye(n,dtype=np.int32)
    for a,h in zip(aa,hh):
        core.good(a); hi=h.astype(np.int32)
        assert np.all(np.abs(h)==1) and np.array_equal(h,h.T)
        assert np.array_equal(hi@hi,identity) and int(np.trace(hi))==0
        expected=h.copy(); np.fill_diagonal(expected,0); assert np.array_equal(expected,a)
    # The exact rational inequality 4 Q^2 <= n^3 is rounded using Q's parity.
    upper=math.isqrt(n**3)//2
    while 4*(upper+1)**2<=n**3: upper+=1
    parity=(n*(n-1)//2)%2
    if upper%2!=parity: upper-=1
    rows=[]; begin=time.time()
    for begin_index in range(0,count,args.batch):
        chunk=aa[begin_index:begin_index+args.batch]
        scores=sc.score(chunk,False,args.starts,args.seed+begin_index)
        for offset,(a,(lower,peaks,witness)) in enumerate(zip(chunk,scores)):
            core.verify_witness(a,lower,witness); assert lower<=upper
            rows.append({'index':begin_index+offset,'n':n,'matrix_sha256':core.digest(a),
                         'Phi_lower':lower,'Phi_upper':upper,'normalized_lower':lower/n**1.5,
                         'normalized_upper':upper/n**1.5,'score_exact':lower==upper,
                         'peak_starts':peaks,'witness_masks':witness})
        if begin_index%(args.batch*4)==0 or len(rows)==count:
            print(json.dumps({'n':n,'scored':len(rows),'best_lower':min(r['Phi_lower'] for r in rows),
                              'universal_structural_upper':upper,'elapsed_seconds':time.time()-begin}),flush=True)
    ranked=sorted(range(count),key=lambda i:(rows[i]['Phi_lower'],rows[i]['peak_starts'],rows[i]['matrix_sha256']))
    exact_indices=[]
    if n<=32:
        # Any pre-screen candidate below incumbent 80 at n32 must be verified.
        qualifying=[i for i in ranked if n==32 and rows[i]['Phi_lower']<80]
        exact_indices=list(dict.fromkeys(qualifying+ranked[:args.exact_top]))
        for i in exact_indices:
            value,peaks,witness=sc.score(aa[i:i+1],True,0,0)[0]
            core.verify_witness(aa[i],value,witness)
            rows[i].update(Phi_lower=value,Phi_upper=value,normalized_lower=value/n**1.5,
                           normalized_upper=value/n**1.5,score_exact=True,
                           peak_count_fixed_first_spin=peaks,witness_masks=witness)
    ranking=sorted(range(count),key=lambda i:(rows[i]['Phi_upper'],rows[i]['Phi_lower'],rows[i]['matrix_sha256'])) if n<=32 else ranked
    for rank,i in enumerate(ranking[:16]):
        saved=dict(rows[i],rank=rank,A=aa[i].tolist(),H=hh[i].tolist())
        (output/f'candidate_n{n}_{rank}.json').write_text(json.dumps(saved,indent=2)+'\n')
    summary={'manifest':manifest,'structural_validation':'all_H_squared_nI_trace_zero_sign_symmetric_PASS',
             'heuristic_start_count':count*args.starts,'exhaustively_scored_candidates':len(exact_indices),
             'elapsed_seconds':time.time()-begin,'candidates':rows}
    (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ['manifest','candidates']}),flush=True)

if __name__=='__main__': main()
