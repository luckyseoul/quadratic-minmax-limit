#!/usr/bin/env python3
"""Broad actual complete-signing search. Exact small-order GPU scores;
large-order multistart lower estimates only. No optimizer claim.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import argparse, hashlib, json, math, socket, time
from pathlib import Path
import numpy as np
import pyopencl as cl

KERNEL = r'''
__kernel void exact_cut(__global const uint *neg, __global const int *total,
                        uint states, int n, __global int *out,
                        __global uint *witness, __global uint *counts) {
  uint sid=get_global_id(0), b=get_global_id(1), lane=get_local_id(0);
  uint s=(sid<states?sid:0u)<<1, todo=s, cnt=0, all=(1u<<n)-1u;
  while(todo) { uint bit=31u-clz(todo&(-todo)); todo&=todo-1;
    cnt+=popcount(neg[b*n+bit] & (all^s)); }
  int sz=popcount(s), q=total[b]-2*(sz*(n-sz)-2*(int)cnt);
  int val=sid<states?abs(q):-1;
  __local int vmax[256]; __local uint ids[256], nums[256];
  vmax[lane]=val; ids[lane]=sid; nums[lane]=sid<states?1u:0u;
  barrier(CLK_LOCAL_MEM_FENCE);
  for(uint d=128;d;d>>=1) { if(lane<d) {
    if(vmax[lane+d]>vmax[lane]) { vmax[lane]=vmax[lane+d]; ids[lane]=ids[lane+d]; nums[lane]=nums[lane+d]; }
    else if(vmax[lane+d]==vmax[lane]) nums[lane]+=nums[lane+d]; }
    barrier(CLK_LOCAL_MEM_FENCE); }
  if(!lane) { uint idx=b*get_num_groups(0)+get_group_id(0);
    out[idx]=vmax[0]; witness[idx]=ids[0]; counts[idx]=nums[0]; }
}
uint nextr(uint *s) { uint x=*s; x^=x<<13; x^=x>>17; x^=x<<5; *s=x; return x; }
__kernel void heuristic(__global const char *a, int n, int starts, int steps,
                        uint seed, __global int *out, __global ulong *wmasks) {
  uint t=get_global_id(0), b=get_global_id(1), rnd=seed^(t*747796405u+b*2891336453u+1u);
  int x[128], h[128], phase=(t&1)?-1:1;
  for(int i=0;i<n;i++) x[i]=(nextr(&rnd)&1)?1:-1;
  if(t<2) for(int i=0;i<n;i++) x[i]=1;
  int q=0;
  for(int i=0;i<n;i++) { int z=0; for(int j=0;j<n;j++) z+=(int)a[b*n*n+i*n+j]*x[j]; h[i]=z; q+=x[i]*z; }
  q/=2; int best=abs(q); ulong lo=0,hi=0;
  for(int st=0;st<steps;st++) {
    int at=-1,gain=0; uint offset=nextr(&rnd)%n;
    for(int jj=0;jj<n;jj++) { int i=(jj+offset)%n, g=-2*phase*x[i]*h[i]; if(g>gain) {gain=g;at=i;} }
    if(at<0) break;
    int old=x[at]; q-=2*old*h[at];
    for(int i=0;i<n;i++) h[i]-=2*old*(int)a[b*n*n+i*n+at];
    x[at]=-old;
  }
  best=abs(q);
  for(int i=0;i<n;i++) if(x[i]<0) { if(i<64) lo|=((ulong)1)<<i; else hi|=((ulong)1)<<(i-64); }
  out[b*starts+t]=best; wmasks[2*(b*starts+t)]=lo; wmasks[2*(b*starts+t)+1]=hi;
}
'''

def digest(a): return hashlib.sha256(np.asarray(a,dtype=np.int8).tobytes()).hexdigest()
def good(a):
    n=len(a)
    assert a.shape==(n,n) and np.array_equal(a,a.T) and np.all(np.diag(a)==0)
    assert np.all(np.abs(a[np.triu_indices(n,1)])==1)
def gauge(a):
    a=a.copy(); v=np.ones(len(a),dtype=np.int8); v[1:]=a[0,1:]
    return (a*v[:,None]*v[None,:]).astype(np.int8)
def prime(q): return q>=2 and all(q%d for d in range(2,math.isqrt(q)+1))
def sylvester(k):
    h=np.ones((1,1),dtype=np.int8)
    while len(h)<k: h=np.block([[h,h],[h,-h]])
    return h
def paley(n,rng):
    q=max(5,n-1)
    while q%4!=1 or not prime(q): q+=1
    c=np.ones((q+1,q+1),dtype=np.int8); np.fill_diagonal(c,0)
    residues={i*i%q for i in range(1,q)}
    for i in range(q):
        for j in range(i+1,q): c[i+1,j+1]=c[j+1,i+1]=1 if (i-j)%q in residues else -1
    ix=rng.choice(q+1,n,replace=False)
    return c[np.ix_(ix,ix)]
def seed_matrix(n,kind,rng):
    if kind=='paley': a=paley(n,rng)
    elif kind=='hadamard':
        h=sylvester(n); ix=rng.choice(len(h),n,replace=False); a=h[np.ix_(ix,ix)].copy(); np.fill_diagonal(a,0)
    elif kind=='reflection':
        u,_=np.linalg.qr(rng.normal(size=(n,n))); d=np.where(np.arange(n)<n//2,1.,-1.)
        a=np.where((u*d)@u.T>=0,1,-1).astype(np.int8); np.fill_diagonal(a,0)
    else:
        z=rng.integers(0,2,(n,n),dtype=np.int8)*2-1; a=np.triu(z,1); a=a+a.T
    return gauge(a)

def mutate(a,kind,rng,step):
    n=len(a); b=a.copy()
    if kind=='edges':
        for _ in range(int(rng.choice([1,1,1,2,2,4,8]))):
            i,j=rng.choice(n,2,replace=False); b[i,j]*=-1; b[j,i]=b[i,j]
    elif kind=='rowpatch':
        for i in rng.choice(n,int(rng.integers(1,min(4,n)+1)),replace=False):
            js=rng.choice(n,max(1,n//int(rng.choice([3,4,6,8]))),replace=False)
            for j in js:
                if i!=j: b[i,j]*=-1; b[j,i]=b[i,j]
    elif kind=='clique':
        ix=rng.choice(n,int(rng.integers(2,max(3,n//2))),replace=False)
        b[np.ix_(ix,ix)]*=-1
    elif kind=='rectangle':
        perm=rng.permutation(n); k=int(rng.integers(1,max(2,n//3))); l=int(rng.integers(1,max(2,n//3)))
        s,t=perm[:k],perm[k:k+l]; b[np.ix_(s,t)]*=-1; b[np.ix_(t,s)]*=-1
    elif kind=='spectral':
        af=a.astype(float); power=af@af@af/max(1,n)
        z=af-float(rng.choice([.05,.1,.2,.4,.8]))*power+rng.normal(size=(n,n))*.12
        z=(z+z.T)/2; b=np.where(z>=0,1,-1).astype(np.int8)
    elif kind.startswith('cov'):
        vals,u=np.linalg.eigh(a.astype(float)); rad=max(abs(vals)); z=rng.normal(size=(n,n)); z=(z+z.T)/math.sqrt(2)
        sign=-1 if kind=='covminus' else 1
        weights=np.sqrt(np.maximum(0,1+sign*np.outer(vals,vals)/(rad*rad)))
        noise=u@(weights*z)@u.T
        bias=float(rng.choice([0,.5,1,1.5,2,2.5])); b=np.where(noise+bias*a>=0,1,-1).astype(np.int8)
    else: return seed_matrix(n,str(rng.choice(['paley','hadamard','reflection','random'])),rng)
    np.fill_diagonal(b,0)
    return gauge(b)

class Scorer:
    def __init__(self):
        devices=[d for p in cl.get_platforms() for d in p.get_devices() if d.type&cl.device_type.GPU]
        self.ctx=cl.Context([devices[0]]); self.queue=cl.CommandQueue(self.ctx)
        self.program=cl.Program(self.ctx,KERNEL).build(); self.device=devices[0].name
        self.kexact=self.program.exact_cut; self.kheur=self.program.heuristic
    def score(self,aa,exact,starts,seed):
        aa=np.ascontiguousarray(aa,dtype=np.int8); b,n,_=aa.shape
        for a in aa: good(a)
        mf=cl.mem_flags
        if exact:
            states=1<<(n-1); groups=(states+255)//256
            neg=np.zeros((b,n),np.uint32)
            for j in range(n): neg|=((aa[:,:,j]<0).astype(np.uint32)<<j)
            totals=np.sum(np.triu(aa,1),axis=(1,2),dtype=np.int32)
            nb=cl.Buffer(self.ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=neg); tb=cl.Buffer(self.ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=totals)
            out=np.empty((b,groups),np.int32); ids=np.empty((b,groups),np.uint32); counts=np.empty((b,groups),np.uint32)
            ob=cl.Buffer(self.ctx,mf.WRITE_ONLY,out.nbytes); ib=cl.Buffer(self.ctx,mf.WRITE_ONLY,ids.nbytes); cb=cl.Buffer(self.ctx,mf.WRITE_ONLY,counts.nbytes)
            self.kexact(self.queue,(groups*256,b),(256,1),nb,tb,np.uint32(states),np.int32(n),ob,ib,cb)
            cl.enqueue_copy(self.queue,out,ob); cl.enqueue_copy(self.queue,ids,ib); cl.enqueue_copy(self.queue,counts,cb).wait()
            mx=out.max(axis=1); cols=out.argmax(axis=1); wit=ids[np.arange(b),cols].astype(np.uint64)*2
            peaks=np.sum(counts*(out==mx[:,None]),axis=1,dtype=np.uint64)
            return [(int(mx[i]),int(peaks[i]),[int(wit[i]),0]) for i in range(b)]
        ab=cl.Buffer(self.ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=aa)
        out=np.empty((b,starts),np.int32); ids=np.empty((b,starts,2),np.uint64)
        ob=cl.Buffer(self.ctx,mf.WRITE_ONLY,out.nbytes); ib=cl.Buffer(self.ctx,mf.WRITE_ONLY,ids.nbytes)
        self.kheur(self.queue,(starts,b),None,ab,np.int32(n),np.int32(starts),np.int32(4*n),np.uint32(seed),ob,ib)
        cl.enqueue_copy(self.queue,out,ob); cl.enqueue_copy(self.queue,ids,ib).wait()
        mx=out.max(axis=1); cols=out.argmax(axis=1)
        return [(int(mx[i]),int(np.sum(out[i]==mx[i])),[int(x) for x in ids[i,cols[i]]]) for i in range(b)]

def verify_witness(a,score,w):
    x=np.array([-1 if (w[i//64]>>(i%64))&1 else 1 for i in range(len(a))],dtype=np.int64)
    assert abs(int(x@a.astype(np.int64)@x)//2)==score
def selftest(sc):
    rng=np.random.default_rng(384719)
    for n in [4,6,8,10]:
        aa=np.array([seed_matrix(n,k,rng) for k in ['random','hadamard','paley','reflection']])
        got=sc.score(aa,True,0,0)
        states=np.arange(1<<(n-1),dtype=np.uint32)<<1
        x=(1-2*((states[:,None]>>np.arange(n))&1)).astype(np.int64)
        for a,(v,count,w) in zip(aa,got):
            q=np.einsum('bi,ij,bj->b',x,a.astype(np.int64),x)//2
            assert v==int(np.max(np.abs(q))) and count==int(np.sum(np.abs(q)==v))
            verify_witness(a,v,w)
    print(json.dumps({'selftest':'PASS','orders':[4,6,8,10],'matrices':16}),flush=True)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',required=True); ap.add_argument('--orders',default='16,20,24,32,64,128')
    ap.add_argument('--rounds',type=int,default=128); ap.add_argument('--batch',type=int,default=32); ap.add_argument('--starts',type=int,default=512)
    ap.add_argument('--seed',type=int,default=2026090623); args=ap.parse_args()
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True); sc=Scorer(); selftest(sc)
    started=time.time(); rng=np.random.default_rng(args.seed); records=[]; types=['edges','rowpatch','clique','rectangle','spectral','covminus','covplus','restart']
    manifest={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'host':socket.gethostname(),'device':sc.device,'seed':args.seed,'orders':args.orders,'rounds':args.rounds,'batch':args.batch,'starts':args.starts,'classification':'exact_GPU_Phi_for_n_le_24; heuristic_lower_estimate_for_larger_n; candidate_search_not_global_optimizer_certificate'}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    for n in map(int,args.orders.split(',')):
        exact=n<=24; bank=[]; seen=set(); count=0; histogram={}; t0=time.time(); best=None
        for rd in range(args.rounds+1):
            mats=[]; labels=[]
            for j in range(args.batch):
                if rd==0 or not bank:
                    label=['hadamard','paley','reflection','random'][j%4]; a=seed_matrix(n,label,rng)
                else:
                    label=types[(j+rd)%len(types)]
                    # Multiple parents and occasional accepted uphill branches preserve diversity.
                    parent=bank[int(rng.integers(0,len(bank)))]['A']; a=mutate(parent,label,rng,rd)
                sha=digest(a)
                for _ in range(6):
                    if sha not in seen: break
                    a=mutate(a,'edges',rng,rd); sha=digest(a)
                seen.add(sha); mats.append(a); labels.append(label)
            vals=sc.score(np.array(mats),exact,args.starts,args.seed+rd+n*1000); count+=len(mats)
            fresh=[]
            for a,label,(v,peaks,w) in zip(mats,labels,vals):
                verify_witness(a,v,w); histogram[label]=histogram.get(label,0)+1
                item={'A':a,'Phi':v,'peaks':peaks,'witness':w,'label':label,'sha':digest(a),'round':rd}
                fresh.append(item)
            combined=bank+fresh; combined.sort(key=lambda z:(z['Phi'],z['peaks'],z['sha']))
            distinct=[]; hashes=set()
            for item in combined:
                if item['sha'] not in hashes: distinct.append(item); hashes.add(item['sha'])
            bank=distinct[:16]
            if rd and rd%8==0: bank=bank[:12]+fresh[-4:]
            winner=min(combined,key=lambda z:(z['Phi'],z['peaks']))
            if best is None or (winner['Phi'],winner['peaks'])<(best['Phi'],best['peaks']):
                best=winner
                saved={k:v for k,v in best.items() if k!='A'}; saved.update(n=n,A=best['A'].tolist(),normalized_Phi=best['Phi']/n**1.5,score_exact=exact,candidates_scored=count,classification='exhaustive_GPU_integer_score_awaiting_independent_certificate' if exact else 'heuristic_lower_bound_on_Phi_not_an_upper_bound',elapsed_seconds=time.time()-t0)
                path=out/f'best_n{n}.json'; path.write_text(json.dumps(saved,indent=2)+'\n')
            if rd%4==0 or rd==args.rounds:
                row={'n':n,'round':rd,'candidates':count,'unique_candidates':len(seen),'best_Phi':best['Phi'],'best_alpha':best['Phi']/n**1.5,'exact':exact,'elapsed':time.time()-t0,'mutations':histogram.copy()}
                print(json.dumps(row),flush=True)
                with (out/'progress.jsonl').open('a') as f: f.write(json.dumps(row)+'\n')
        np.savez_compressed(out/f'bank_n{n}.npz',matrices=np.array([z['A'] for z in bank]),scores=np.array([z['Phi'] for z in bank]),peaks=np.array([z['peaks'] for z in bank]))
        records.append(row)
        (out/'summary.json').write_text(json.dumps({'manifest':manifest,'orders':records,'elapsed_seconds':time.time()-started},indent=2)+'\n')
    print(json.dumps({'status':'completed','elapsed_seconds':time.time()-started,'out':str(out)}),flush=True)
if __name__=='__main__': main()
