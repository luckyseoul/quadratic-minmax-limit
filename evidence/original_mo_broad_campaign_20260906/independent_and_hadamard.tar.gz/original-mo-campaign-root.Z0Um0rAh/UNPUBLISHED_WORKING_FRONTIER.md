# Unpublished analytic scratch frontier, 2026-09-06

This preserves calculations explored after the reviewed strict-1/pi milestone
and before the broad compute campaign. It is NOT a reviewed theorem artifact,
does not replace the canonical proof notes, and does not change global status.
Reconstruct full proofs and quantifiers before citing a claim from this file.
The original convergence problem and its possible value remain OPEN.

## Actual-source information worth retaining

For an actual complete signing K of order N with F=Phi(K)=O(N^(3/2)),
the cubic spectral bootstrap and clipped Gaussian rounding appeared to give
a positive ONE-SIDED lower for every macroscopic induced submatrix of order m:
max Q_(K[D]) >= (kappa^2/64+o(1))*m^3/F, kappa=2/pi.
Here m/N is bounded away from zero and the objective cap is fixed; no uniform
finite-size bound with a diverging cap or microscopic m was established.
One convenient bulk correlation is I+(M_bulk-diag(M_bulk))/(2*C_cut).
It has diagonal one and bounded operator norm without diagonal renormalization.

If two positive near-maximizers have Q_K(z)=F-Delta and
Q_K(z')=F-Delta', let D be their disagreement set. Conditioning on the
complement and averaging the choices +/-u on D gives the useful exact bound

    z^T K z' <= 2F - 4 max_u Q_(K[D])(u) + Delta + Delta'.

For actual same-phase maximizers, the cross sum across D vanishes and
z_D maximizes the positive induced quadratic. Apply the preceding argument
also to -z' to control the absolute pairing using projective Hamming distance.
This yields a macroscopic pairing gap. It does NOT assert positive local
field on every coordinate or control arbitrary subset normal mass.

For K=[[A,B],[B^T,-A]], a cell uses p=x^T A x, q=y^T A y,
c=x^T B y>=0, I=(p-q)/2, F=I+c, and a second same-cell state x',y'.
Write a=x^T A x', b=y^T A y', d=x^T B y', e=x'^T B y.
At the actual central face p=q=t and I=0, row stability led to

    a*b-d*e >= t^2-c^2+c*abs(d-e).

This controls the unnormalized intrinsic covariance increment on the central
face. The source-extremal endpoint p=2Phi(A), q=-2Phi(A) is also favorable.
There is no justified interpolation through the interior. The scalar profile
Phi(A)=1, F=3, p=1/2, q=-1/2, c=5/2, d=e=0,
a=3-epsilon, b=-3+epsilon passes the listed row/source interval bounds yet
has a harmful interior increment for small fixed positive epsilon. This is a
FORMAL relaxation profile, not an actual complete-signing counterexample.

## Routes that were not closed

- Intrinsic covariance clipping and diagonal normalization act on a general
  difference vector after reweighting. The original rank-one pairing bounds
  do not automatically survive that transformation. At d=e the favorable
  central margin can vanish, so a small relative repair is not enough.
- Same-order whole-edge Gaussian interpolation plus the macroscopic pairing
  gap gave a cubic posterior-overlap estimate. The end-to-end comparison
  needed a linear estimate; low-temperature concentration did not supply it.
- One-vertex extension can be written exactly as
  min_c max_x [abs(c dot x)-(Phi(A)-abs(Q_A(x)))]. Only deficits <=n matter.
  No weighted projective Hamming-ball noncoverage theorem was obtained.
- A regular-cloud construction exposes a bilinear or diagonally completed
  bilinear norm. It does not automatically recover the original quadratic
  norm. The exact diagonal-completion equality fails already for C6:
  Phi(C6)=5 but its bilinear norm is 12. No asymptotic repair was proved.
- All unequal static means in the tested two-block rounding relaxation have
  an explicit formal dual boundary below 0.4. This is a limitation of that
  relaxation, not a counterexample among actual near-minimizing signings.
- In the CURRENT smoothed Gaussian objective, a single cross-edge covariance
  change is supported on a row/column star. Conditioning on the other spins
  does not replace the full posterior fourth cumulant: total-cumulance terms
  from the rest of the posterior remain. Summed discrete-flip remainders
  were not proved negligible.

## Important sign correction in the diagonal optimization calculation

For the continuous, unconstrained-B calculation, let the two PSD constraints
be D+/-K>=0, with multipliers Lambda_+, Lambda_-. Set
U=Lambda_++Lambda_-, V=Lambda_--Lambda_+. Complementarity gives
E_D=tr(DU)=tr(KV)>=0. Both the internal and cross parts are separately
majorized by D (by averaging with block sign conjugation). Therefore if
a=tr(K_internal V), b=tr(K_cross V), then a,b>=0 and a+b=E_D.
An earlier informal claim that these terms have no sign was corrected.

This still does not establish the needed ACTUAL sign-matrix variation.
A box constraint introduces an uncontrolled nonnegative normal term;
sign-only B requires an exact finite-flip bound, not continuous stationarity.
Adding 2I to D gives a common PSD cushion for any single edge flip, but its
global error cannot be charged separately for all n^2 edges. A trace cap
also prevents treating an arbitrary increase of D as an interior variation.

These unresolved points are route-local. None is a necessary condition for
solving the original MO question by another argument. The ensuing multi-GPU
campaign is recorded separately and did not fill these analytic gaps.
