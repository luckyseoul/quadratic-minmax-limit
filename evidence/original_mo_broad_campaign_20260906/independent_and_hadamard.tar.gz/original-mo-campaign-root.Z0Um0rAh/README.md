# Independent verification and exact Hadamard constructions

Part of the 2026-09-06 broad CPU/GPU campaign. These are finite matrix
certificates and construction banks, not global minima or a convergence proof.
The original MO problem remains OPEN.

The two C++ verifiers use projective Gray enumeration, updating all integer
local fields. This is independent of the GPU cross-profile and CPU popcount
search implementations. They validate symmetry, signs, diagonal, full-cube
first and second moments, energy parity, returned extremal witnesses, and
final local fields. Through order 10 they also check every state directly.
The extended file changes only the accepted order limit from 30 to 32.

Build and replay one stored matrix on a compute host:

```sh
g++ -O3 -march=native -std=c++17 original_mo_broad_independent_verify32.cpp -o verify
./verify independent_winners/rx_n32_0.txt
./verify independent_winners/v100_n26_61.txt
```

The order-32 replay exhausted 2,147,483,648 projective states in 93.221410214
seconds on Jellyfin: extrema -80 and 80, 2,240 peaks at each extreme. The
order-26 replay exhausted 33,554,432 states in 1.227344402 seconds: extrema
-61 and 61, 338 peaks at each extreme. Timings are measurements, not promises.
The receipts also retain the initial 27 winner checks and five later GF25
principal-source checks, whose exact norms at orders 19 through 23 were
41, 42, 44, 49, 53. Old absolute source paths in the receipts record original
provenance; their input basenames are copied into independent_winners here.

The trade generator starts from a trace-zero symmetric Sylvester Hadamard
matrix H, conjugates on four coordinates by Q=I-u*u^T/2, and retains a result
only if all entries remain signs. Symmetry, trace zero, and H^2=nI are
checked with complete integer matrix multiplication for EVERY emitted H.
The archive includes 2,048 distinct stored zero-diagonal matrices at each
order 32, 64, and 128. Distinctness is bytewise after first-row switching;
no enumeration of permutation or switching equivalence classes is claimed.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python original_mo_symmetric_hadamard_trades.py --out replay --orders 32,64,128 --count 2048 --seed 2026090661
```

Generation used one CPU worker on Jellyfin. These original generator receipts
say Phi unscored; subsequent exact or heuristic scores and their qualifications
are in the Nuka campaign package. In particular, the 16 shortlisted order-64
matrices were later proved to have norm 256 by checked Boolean eigenvectors;
their earlier heuristic score 244 was not an upper bound. Order-128 heuristic
scores likewise must not be read as exact maxima.
