#define main initial_campaign_main
#include "search.cpp"
#undef main
Mat c25(){Mat a{};a.n=26;std::array<int,25> chi;chi.fill(-1);chi[0]=0;
  for(int z=1;z<25;z++){int x=z%5,y=z/5;chi[(x*x+2*y*y)%5+5*((2*x*y)%5)]=1;}
  for(int i=1;i<26;i++)edge(a,0,i,1);
  for(int i=1;i<26;i++)for(int j=i+1;j<26;j++){int x=((j-1)%5-(i-1)%5+5)%5,y=((j-1)/5-(i-1)/5+5)%5;edge(a,i,j,chi[x+5*y]);}return a;}
int main(){selftest();std::vector<Mat> sources{paley(13),paley(17),c25()};omp_set_num_threads(4);
  #pragma omp parallel for schedule(dynamic,1)
  for(int id=0;id<16*128;id++){
    int n=11+id/128;int trial=id%128;const Mat&c=sources[n<=14?0:n<=18?1:2];
    std::vector<int> subset(c.n);for(int i=0;i<c.n;i++)subset[i]=i;
    if(trial){std::mt19937_64 rng(0x8284317ull+id);std::shuffle(subset.begin(),subset.end(),rng);}subset.resize(n);std::sort(subset.begin(),subset.end());
    Mat a{};a.n=n;for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)edge(a,i,j,c.a[subset[i]][subset[j]]);Score v=exact(a);
    #pragma omp critical
    {std::cout<<"{\"type\":\"principal_candidate\",\"n\":"<<n<<",\"source_n\":"<<c.n<<",\"trial\":"<<trial<<",\"phi\":"<<v.phi<<",\"witness_mask\":"<<v.mask<<",\"witness_q\":"<<v.q<<",\"upper\":\""<<bits(a)<<"\",\"subset\":[";for(int i=0;i<n;i++){if(i)std::cout<<',';std::cout<<subset[i];}std::cout<<"]}"<<std::endl;}
  }
}
