#define main initial_campaign_main
#include "search.cpp"
#undef main
#include <mutex>

struct Profile {int phi=0,q=0;uint32_t witness=0;uint64_t peaks=0;std::array<uint32_t,16> masks{};std::array<int,16> signs{};int captured=0;};
Profile profile(const Mat&a){
  std::array<uint32_t,26> neg{};int q=0;
  for(int i=0;i<a.n;i++)for(int j=0;j<a.n;j++)if(i!=j){if(a.a[i][j]<0)neg[i]|=1u<<j;if(i<j)q+=a.a[i][j];}
  Profile best{std::abs(q),q,0,1};best.masks[0]=0;best.signs[0]=q<0?-1:1;best.captured=1;uint32_t mask=0;
  for(uint32_t step=1;step<(1u<<(a.n-1));step++){
    int j=__builtin_ctz(step)+1;
    int field=a.n-1-2*__builtin_popcount((neg[j]^mask)&~(1u<<j));
    q-=2*((mask>>j)&1?-1:1)*field;mask^=1u<<j;
    int v=std::abs(q);if(v>best.phi){best={v,q,mask,1};best.masks[0]=mask;best.signs[0]=q<0?-1:1;best.captured=1;}else if(v==best.phi){best.peaks++;if(best.captured<16){best.masks[best.captured]=mask;best.signs[best.captured]=q<0?-1:1;best.captured++;}}
  }
  if(direct(a,best.witness)!=best.q)throw std::runtime_error("adaptive witness mismatch");return best;
}
Mat loadmat(const std::string&path){std::ifstream f(path);Mat a{};if(!(f>>a.n)||a.n<2||a.n>26)throw std::runtime_error("bad seed file "+path);for(int i=0;i<a.n;i++)for(int j=0;j<a.n;j++)if(!(f>>a.a[i][j]))throw std::runtime_error("short seed");exact(a);return a;}
Mat conference25(){
  Mat a{};a.n=26;std::array<int,25> chi;chi.fill(-1);chi[0]=0;
  for(int z=1;z<25;z++){int x=z%5,y=z/5;chi[(x*x+2*y*y)%5+5*((2*x*y)%5)]=1;}
  for(int i=1;i<26;i++)edge(a,0,i,1);
  for(int i=1;i<26;i++)for(int j=i+1;j<26;j++){int x=((j-1)%5-(i-1)%5+5)%5,y=((j-1)/5-(i-1)/5+5)%5;edge(a,i,j,chi[x+5*y]);}
  for(int i=0;i<26;i++)for(int j=0;j<26;j++){int v=0;for(int k=0;k<26;k++)v+=a.a[i][k]*a.a[k][j];if(v!=(i==j?25:0))throw std::runtime_error("GF25 conference square");}return a;
}
int main(int argc,char**argv){try{
  if(argc!=6)throw std::runtime_error("usage: adaptive threads first_worker seconds seed_directory label");
  int threads=std::atoi(argv[1]),first=std::atoi(argv[2]),duration=std::atoi(argv[3]);std::string dir=argv[4],label=argv[5];
  selftest();std::array<std::vector<Mat>,27> bank;
  for(int n=11;n<=26;n++)bank[n].push_back(loadmat(dir+"/best_n"+std::to_string(n)+".txt"));
  for(int p:{13,17}){Mat c=paley(p);bank[c.n].push_back(c);bank[c.n-1].push_back(principal(c,c.n-1));}
  Mat c26=conference25();bank[26].push_back(c26);bank[25].push_back(principal(c26,25));bank[24].push_back(principal(c26,24));
  for(int n=11;n<=26;n++){std::ifstream hot(dir+"/hot_n"+std::to_string(n)+".txt");if(hot.good())bank[n].push_back(loadmat(dir+"/hot_n"+std::to_string(n)+".txt"));}
  std::array<int,27> bestphi;bestphi.fill(100000);std::array<uint64_t,27> bestpeaks{};
  for(int n=11;n<=26;n++)for(auto&a:bank[n]){auto v=profile(a);if(v.phi<bestphi[n]||(v.phi==bestphi[n]&&v.peaks<bestpeaks[n])){bestphi[n]=v.phi;bestpeaks[n]=v.peaks;}}
  for(int n=11;n<=26;n++)bank[n].erase(std::remove_if(bank[n].begin(),bank[n].end(),[&](const Mat&a){return profile(a).phi>bestphi[n];}),bank[n].end());
  std::mutex banklock;std::atomic<uint64_t> evaluations{0};std::atomic<uint64_t> trajectories{0};auto begun=std::chrono::steady_clock::now();
  auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-begun).count();};
  auto emit=[&](std::string type,int worker,int n,const Mat&a,const Profile&v,uint64_t step,std::string mutation){
    std::cout<<std::setprecision(12)<<"{\"type\":\""<<type<<"\",\"label\":\""<<label<<"\",\"worker\":"<<worker<<",\"n\":"<<n<<",\"phi\":"<<v.phi<<",\"norm\":"<<v.phi/std::pow(double(n),1.5)<<",\"peaks\":"<<v.peaks<<",\"witness_mask\":"<<v.witness<<",\"witness_q\":"<<v.q<<",\"upper\":\""<<bits(a)<<"\",\"step\":"<<step<<",\"mutation\":\""<<mutation<<"\",\"evaluations\":"<<evaluations<<",\"elapsed\":"<<elapsed()<<"}"<<std::endl;};
  for(int n=11;n<=26;n++)for(auto&a:bank[n])emit("initial",-1,n,a,profile(a),0,"input_or_Paley");
  omp_set_num_threads(threads);
  #pragma omp parallel
  {
    int worker=first+omp_get_thread_num();std::mt19937_64 rng(0x4389450011220000ull+worker);uint64_t localsteps=0,round=0;
    while(elapsed()<duration){
      int n=14+(worker+round)%13;Mat a;
      std::string hotpath=dir+"/hot_n"+std::to_string(n)+".txt";std::ifstream hot(hotpath);
      if(hot.good()){Mat incoming=loadmat(hotpath);Profile iv=profile(incoming);std::lock_guard<std::mutex> g(banklock);if(iv.phi<bestphi[n]){bank[n].clear();bank[n].push_back(incoming);bestphi[n]=iv.phi;bestpeaks[n]=iv.peaks;emit("import",worker,n,incoming,iv,localsteps,"hot_seed");}}
      {std::lock_guard<std::mutex> g(banklock);a=bank[n][rng()%bank[n].size()];}
      Profile current=profile(a);evaluations++;int trajectorybest=current.phi;int stalled=0;
      trajectories++;
      for(int step=0;step<5000&&elapsed()<duration;step++,localsteps++){
        Mat b=a;int choice=rng()%20;std::string mutation;
        if(choice<6){mutation="active16_gradient";std::vector<std::pair<int,int>> choices;int strongest=-100000;for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){int g=0;for(int k=0;k<current.captured;k++)g+=current.signs[k]*((((current.masks[k]>>i)^(current.masks[k]>>j))&1)?-1:1);g*=a.a[i][j];if(g>strongest){strongest=g;choices.clear();}if(g==strongest)choices.emplace_back(i,j);}auto [i,j]=choices[rng()%choices.size()];edge(b,i,j,-b.a[i][j]);}
        else if(choice<13){int flips=choice<10?1:2;mutation="edge"+std::to_string(flips);for(int k=0;k<flips;k++){int i=rng()%n,j=rng()%(n-1);if(j>=i)j++;edge(b,i,j,-b.a[i][j]);}}
        else if(choice<16){mutation="triangle";int i=rng()%n,j=rng()%n,k=rng()%n;if(i==j||i==k||j==k)continue;edge(b,i,j,-b.a[i][j]);edge(b,i,k,-b.a[i][k]);edge(b,j,k,-b.a[j][k]);}
        else if(choice<18&&n%2==0){mutation="cross_matching";int m=n/2,shift=rng()%m;for(int i=0;i<m;i++)edge(b,i,m+(i+shift)%m,-b.a[i][m+(i+shift)%m]);}
        else {mutation="fourcycle";int i=rng()%n,j=rng()%n,k=rng()%n,l=rng()%n;if(i==j||i==k||i==l||j==k||j==l||k==l)continue;edge(b,i,j,-b.a[i][j]);edge(b,j,k,-b.a[j][k]);edge(b,k,l,-b.a[k][l]);edge(b,l,i,-b.a[l][i]);}
        Profile v=profile(b);evaluations++;
        double score=current.phi+.18*std::log(double(current.peaks)),candidate=v.phi+.18*std::log(double(v.peaks));
        double scale=std::array<double,4>{.3,.7,1.5,3.0}[worker%4];double temp=.06+scale*std::pow(1.0-(step%625)/625.0,2);
        if(candidate<=score||std::generate_canonical<double,53>(rng)<std::exp((score-candidate)/temp)){a=b;current=v;}
        bool improvement=false;
        {std::lock_guard<std::mutex> g(banklock);
          if(v.phi<bestphi[n]||(v.phi==bestphi[n]&&v.peaks<bestpeaks[n])){
            if(v.phi<bestphi[n])bank[n].clear();bestphi[n]=v.phi;bestpeaks[n]=v.peaks;bank[n].push_back(b);if(bank[n].size()>24)bank[n].erase(bank[n].begin());
            emit("best",worker,n,b,v,localsteps,mutation);improvement=true;
          }
          if(localsteps&&localsteps%1000==0)emit("progress",worker,n,a,current,localsteps,mutation);
        }
        if(v.phi<trajectorybest){trajectorybest=v.phi;stalled=0;}else stalled++;
        if(stalled>1800)break;
      }round++;
    }
  }
  std::cout<<"{\"type\":\"complete\",\"evaluations\":"<<evaluations<<",\"trajectories\":"<<trajectories<<",\"elapsed\":"<<elapsed()<<"}"<<std::endl;
}catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 1;}}
