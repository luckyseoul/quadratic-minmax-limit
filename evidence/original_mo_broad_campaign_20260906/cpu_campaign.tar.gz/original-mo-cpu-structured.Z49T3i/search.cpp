#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
#include <omp.h>

struct Mat {int n; std::array<std::array<int,26>,26> a{};};
struct Score {int phi; int q; uint32_t mask;};
void edge(Mat& a,int i,int j,int s){a.a[i][j]=a.a[j][i]=s;}
int direct(const Mat&a,uint32_t mask){
  int q=0; for(int i=0;i<a.n;i++)for(int j=i+1;j<a.n;j++)
    q+=a.a[i][j]*(((mask>>i)^(mask>>j))&1?-1:1); return q;
}
Score exact(const Mat&a){
  if(a.n<2||a.n>26)throw std::runtime_error("bad order");
  std::array<uint32_t,26> neg{};
  int q=0;for(int i=0;i<a.n;i++){
    if(a.a[i][i])throw std::runtime_error("bad diagonal");
    for(int j=0;j<a.n;j++)if(i!=j){
      if(std::abs(a.a[i][j])!=1||a.a[i][j]!=a.a[j][i])throw std::runtime_error("bad sign matrix");
      if(a.a[i][j]<0)neg[i]|=1u<<j;
      if(i<j)q+=a.a[i][j];
    }
  }
  Score best{std::abs(q),q,0};uint32_t mask=0;
  for(uint32_t step=1;step<(1u<<(a.n-1));step++){
    int j=__builtin_ctz(step)+1;
    int field=a.n-1-2*__builtin_popcount((neg[j]^mask)&~(1u<<j));
    q-=2*((mask>>j)&1?-1:1)*field;mask^=1u<<j;
    if(std::abs(q)>best.phi)best={std::abs(q),q,mask};
  }
  if(direct(a,best.mask)!=best.q)throw std::runtime_error("witness mismatch");
  return best;
}
Mat circulate(int n,uint64_t code,bool nega=false){
  Mat a{};a.n=n;
  for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
    int d=j-i;int k=std::min(d,n-d)-1;
    int s=(code>>k)&1?-1:1;if(nega&&d>n/2)s=-s;edge(a,i,j,s);
  }return a;
}
Mat random_mat(int n,std::mt19937_64&r){Mat a{};a.n=n;for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)edge(a,i,j,r()&1?1:-1);return a;}
Mat paley(int p){
  Mat a{};a.n=p+1;std::vector<int> chi(p,-1);chi[0]=0;
  for(int i=1;i<p;i++)chi[i*i%p]=1;
  for(int i=1;i<=p;i++)edge(a,0,i,1);
  for(int i=1;i<=p;i++)for(int j=i+1;j<=p;j++)edge(a,i,j,chi[(j-i)%p]);return a;
}
Mat principal(const Mat&a,int n){Mat b=a;b.n=n;return b;}
std::string bits(const Mat&a){std::string s;for(int i=0;i<a.n;i++)for(int j=i+1;j<a.n;j++)s+=a.a[i][j]>0?'+':'-';return s;}
std::array<std::vector<Mat>,14> seedbank(){
  std::array<std::vector<Mat>,14> bank;
  for(int n=6;n<=13;n++){
    std::mt19937_64 rng(0x384756213ull+n);int best=100000;
    auto consider=[&](const Mat&a){int v=exact(a).phi;if(v<best){best=v;bank[n].clear();}
      if(v==best&&bank[n].size()<16){std::string b=bits(a);bool duplicate=false;for(auto&old:bank[n])if(bits(old)==b)duplicate=true;if(!duplicate)bank[n].push_back(a);}};
    for(uint64_t k=0;k<(1ull<<(n/2));k++)consider(circulate(n,k,n%2));
    if(n==6)consider(paley(5));if(n==13)consider(principal(paley(13),13));
    for(int restart=0;restart<12;restart++){
      Mat a=restart<4?bank[n][restart%bank[n].size()]:random_mat(n,rng);int current=exact(a).phi;
      for(int it=0;it<700;it++){
        int i=rng()%n,j=rng()%(n-1);if(j>=i)j++;edge(a,i,j,-a.a[i][j]);int v=exact(a).phi;
        double temp=.4+2.0*(1.0-(it%175)/175.0);
        bool accept=v<=current||std::generate_canonical<double,53>(rng)<std::exp((current-v)/temp);
        if(accept){current=v;consider(a);}else edge(a,i,j,-a.a[i][j]);
      }
    }
  }return bank;
}
struct Candidate{Mat a;std::string family;int source_n=0,source_phi=0;};
Candidate block_candidate(uint64_t id,const std::array<std::vector<Mat>,14>&bank){
  std::mt19937_64 rng(0x8b219fc100000000ull+id);int m=6+id%8;
  const Mat&src=bank[m][rng()%bank[m].size()];
  Mat a{};a.n=2*m;int mode=(id/8)%8;
  std::vector<int> p(m),r(m),s(m);for(int i=0;i<m;i++){p[i]=i;r[i]=rng()&1?1:-1;s[i]=rng()&1?1:-1;}
  std::shuffle(p.begin(),p.end(),rng);
  int source2sign=(id/64)%2?1:-1;
  for(int i=0;i<m;i++)for(int j=i+1;j<m;j++){
    edge(a,i,j,src.a[i][j]);
    edge(a,m+i,m+j,source2sign*src.a[i][j]);
  }
  uint64_t pattern=rng();
  for(int i=0;i<m;i++)for(int j=0;j<m;j++){
    int v=1,d=(j-i+m)%m;
    if(mode==0)v=i==j?(rng()&1?1:-1):src.a[i][j];
    if(mode==1)v=i==p[j]?(rng()&1?1:-1):src.a[i][p[j]];
    if(mode==2)v=(pattern>>d)&1?1:-1;
    if(mode==3){v=(pattern>>std::min(d,m-d))&1?1:-1;if(d>m/2)v=-v;}
    if(mode==4)v=i==j?((pattern>>i)&1?1:-1):(i<j?src.a[i][j]:-src.a[i][j]);
    if(mode==5)v=i==p[j]?1:(i<p[j]?src.a[i][p[j]]:-src.a[i][p[j]]);
    if(mode==6)v=(__builtin_popcount((unsigned)(i&p[j]))&1)?-1:1;
    if(mode==7)v=rng()&1?1:-1;
    if((id/128)%2)v*=r[i];if((id/256)%2)v*=s[j];edge(a,i,m+j,v);
  }
  int flips=(id/512)%5;for(int k=0;k<flips;k++){int i=rng()%a.n,j=rng()%(a.n-1);if(j>=i)j++;edge(a,i,j,-a.a[i][j]);}
  if((id/2560)%3==1)a.n--;
  return{a,"block_"+std::to_string(mode)+"_flip"+std::to_string(flips),m,exact(src).phi};
}
void selftest(){
  std::mt19937_64 rng(8876123);
  for(int n=2;n<=10;n++)for(int k=0;k<24;k++){
    Mat a=random_mat(n,rng);int brute=0;
    for(uint32_t mask=0;mask<(1u<<n);mask++)brute=std::max(brute,std::abs(direct(a,mask)));
    if(exact(a).phi!=brute)throw std::runtime_error("brute mismatch");
  }
  if(exact(paley(5)).phi!=5)throw std::runtime_error("C6 known value");
  std::cout<<"{\"type\":\"selftest\",\"random_matrices\":216,\"max_n\":10,\"C6_phi\":5,\"ok\":true}"<<std::endl;
}
int main(int argc,char**argv){try{
  selftest();if(argc==2&&std::string(argv[1])=="--selftest")return 0;
  if(argc!=6)throw std::runtime_error("usage: search threads shard_start shard_count shard_mod block_count");
  int threads=std::atoi(argv[1]),start=std::atoi(argv[2]),count=std::atoi(argv[3]),mod=std::atoi(argv[4]);uint64_t blocks=std::strtoull(argv[5],nullptr,10);
  omp_set_num_threads(threads);auto begun=std::chrono::steady_clock::now();auto bank=seedbank();
  for(int n=6;n<=13;n++)for(size_t k=0;k<bank[n].size();k++)std::cout<<"{\"type\":\"seed\",\"n\":"<<n<<",\"index\":"<<k<<",\"phi\":"<<exact(bank[n][k]).phi<<",\"upper\":\""<<bits(bank[n][k])<<"\"}"<<std::endl;
  std::vector<std::pair<int,uint64_t>> structured;
  for(int n=12;n<=26;n++)for(uint64_t k=0;k<(1ull<<(n/2));k++)structured.emplace_back(n,k);
  uint64_t total=structured.size()+blocks;std::atomic<uint64_t> done{0};
  std::cout<<"{\"type\":\"start\",\"threads\":"<<threads<<",\"shard_start\":"<<start<<",\"shard_count\":"<<count<<",\"shard_mod\":"<<mod<<",\"structured_total\":"<<structured.size()<<",\"block_total\":"<<blocks<<"}"<<std::endl;
  #pragma omp parallel for schedule(dynamic,1)
  for(uint64_t id=0;id<total;id++){
    if(int(id%mod)<start||int(id%mod)>=start+count)continue;
    Candidate c;
    if(id<structured.size()){auto [n,k]=structured[id];c={circulate(n,k,n%2),n%2?"negacyclic":"circulant",0,0};}
    else c=block_candidate(id-structured.size(),bank);
    Score v=exact(c.a);uint64_t current=++done;
    double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-begun).count();
    #pragma omp critical
    {std::cout<<std::setprecision(12)<<"{\"type\":\"candidate\",\"id\":"<<id<<",\"family\":\""<<c.family<<"\",\"n\":"<<c.a.n<<",\"phi\":"<<v.phi<<",\"norm\":"<<v.phi/std::pow(double(c.a.n),1.5)<<",\"source_n\":"<<c.source_n<<",\"source_phi\":"<<c.source_phi<<",\"witness_mask\":"<<v.mask<<",\"witness_q\":"<<v.q<<",\"upper\":\""<<bits(c.a)<<"\",\"done\":"<<current<<",\"elapsed\":"<<seconds<<"}"<<std::endl;}
  }
  std::cout<<"{\"type\":\"complete\",\"done\":"<<done<<",\"elapsed\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-begun).count()<<"}"<<std::endl;
}catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 1;}}
