#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
g++ -O3 -march=native -std=c++17 -fopenmp adaptive_v2.cpp -o adaptive_v2
sha256sum search.cpp adaptive_v2.cpp adaptive_v2
nohup ./adaptive_v2 "$@" > adaptive_v2_results.jsonl 2> adaptive_v2_errors.log < /dev/null &
adaptive_v2_pid=$!
printf '%s\n' "$adaptive_v2_pid"
sleep 1
ps -p "$adaptive_v2_pid" -o pid,nlwp,pcpu,etime,args
