#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
g++ -O3 -march=native -std=c++17 -fopenmp search.cpp -o search
sha256sum search.cpp search
./search --selftest
nohup ./search "$@" > results.jsonl 2> errors.log < /dev/null &
search_pid=$!
printf '%s\n' "$search_pid"
sleep 1
ps -p "$search_pid" -o pid,nlwp,pcpu,etime,args
