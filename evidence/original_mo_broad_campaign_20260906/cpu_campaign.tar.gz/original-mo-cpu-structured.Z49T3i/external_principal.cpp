#define main initial_campaign_main
#include "search.cpp"
#undef main
int main(int argc,char**argv){if(argc!=3)return 1;int trials=std::atoi(argv[2]);std::ifstream f(argv[1]);int source_n;f>>source_n;std::vector<std::vector<int>> source(source_n,std::vector<int>(source_n));for(auto&row:source)for(int&v:row)f>>v;if(!f)return 2;
  omp_set_num_threads(4);
  #pragma omp parallel for schedule(dynamic,1)
  for(int id=0;id<17*trials;id++){
    int n=10+id/trials;int trial=id%trials;std::vector<int> subset(source_n);for(int i=0;i<source_n;i++)subset[i]=i;
    if(trial){std::mt19937_64 rng(0x423886021ull+id);std::shuffle(subset.begin(),subset.end(),rng);}subset.resize(n);std::sort(subset.begin(),subset.end());
    Mat a{};a.n=n;for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)edge(a,i,j,source[subset[i]][subset[j]]);Score v=exact(a);
    #pragma omp critical
    {std::cout<<"{\"type\":\"external_principal\",\"n\":"<<n<<",\"source_n\":"<<source_n<<",\"trial\":"<<trial<<",\"phi\":"<<v.phi<<",\"witness_mask\":"<<v.mask<<",\"witness_q\":"<<v.q<<",\"upper\":\""<<bits(a)<<"\",\"subset\":[";for(int i=0;i<n;i++){if(i)std::cout<<',';std::cout<<subset[i];}std::cout<<"]}"<<std::endl;}
  }
}
