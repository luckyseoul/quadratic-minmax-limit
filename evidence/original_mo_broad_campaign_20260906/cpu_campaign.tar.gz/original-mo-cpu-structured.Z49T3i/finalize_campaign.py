#!/usr/bin/env python3
"""Consolidate preserved campaign artifacts without claiming missing log data."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
from datetime import datetime, timezone


def parse_lines(path):
    records, invalid = [], []
    for number, line in enumerate(path.read_bytes().splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
            if not isinstance(record, dict):
                raise ValueError("not an object")
            records.append((number, record))
        except (ValueError, UnicodeDecodeError):
            invalid.append(number)
    return records, invalid


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def upper_matrix(record):
    n, signs = record["n"], record["upper"]
    if len(signs) != n * (n - 1) // 2 or any(v not in "+-" for v in signs):
        raise ValueError("invalid saved upper triangle")
    A = [[0] * n for _ in range(n)]
    k = 0
    for i in range(n):
        for j in range(i + 1, n):
            A[i][j] = A[j][i] = 1 if signs[k] == "+" else -1
            k += 1
    return A


def witness_check(record, A):
    if "witness_mask" not in record or "witness_q" not in record:
        return "not_saved"
    mask, n = record["witness_mask"], len(A)
    q = sum(A[i][j] * (-1 if ((mask >> i) ^ (mask >> j)) & 1 else 1)
            for i in range(n) for j in range(i + 1, n))
    if q != record["witness_q"] or abs(q) != record["phi"]:
        raise ValueError("retained extremal witness is inconsistent")
    return "PASS_DIRECT_INTEGER_REPLAY"


def finalize(base, prepare_only=False):
    manifest = {
        "classification": "FINITE_COMPUTATIONAL_CAMPAIGN_ORIGINAL_PROBLEM_OPEN",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "repository_start_sha": "6bcd7d46f307d0e55141244daa3e58044f32cf55",
        "no_main_repository_edits_by_cpu_agent": True,
        "hosts": {"soul": "192.168.1.113", "jelly": "192.168.1.191", "nuka": "192.168.1.192"},
        "worker_counts": {"soul": 76, "jelly": 12, "nuka": 12},
        "counts_mean_exact_evaluator_calls_not_distinct_switching_classes": True,
        "provenance_warning": (
            "During the transition from adaptive v1 to v2, a recursive staging copy accidentally "
            "overwrote parts of the old remote v1 log files with a local soul log. "
            "Authentic earlier per-host snapshots and raw mixed finals are retained. "
            "Only valid JSON records matching the expected host label enter the v1 reconstruction; "
            "its evaluation totals are honest logged lower bounds, not complete counts. "
            "The initial structured campaign and all v2 logs are unaffected."
        ),
        "initial": {}, "adaptive_v1": {}, "adaptive_v2": {}, "sidecars": {},
        "final_winners": [], "files": [],
    }
    candidate_records = []
    ids = set()
    initial_count = 0
    for label in ("soul", "jelly", "nuka"):
        path = base / f"{label}.jsonl"
        records, invalid = parse_lines(path)
        if invalid:
            raise ValueError(f"initial exact campaign corrupt: {path}:{invalid}")
        count = 0
        completions = []
        for line, record in records:
            if record.get("type") == "candidate":
                if record["id"] in ids:
                    raise ValueError("initial candidate IDs overlap")
                ids.add(record["id"])
                count += 1
                candidate_records.append((str(path.relative_to(base)), line, record))
            if record.get("type") == "complete":
                completions.append(record)
        if len(completions) != 1 or completions[0]["done"] != count:
            raise ValueError("initial completion count mismatch")
        manifest["initial"][label] = {"exact_evaluations": count, "complete": completions[0]}
        initial_count += count
    if initial_count != 57216:
        raise ValueError("initial expected total mismatch")
    manifest["initial"]["total_exact_evaluations"] = initial_count
    manifest["initial"]["unique_candidate_ids"] = len(ids)

    v1_total = 0
    for label in ("soul", "jelly", "nuka"):
        originals = [base / f"adaptive_{label}.jsonl", base / f"adaptive_v1_final_raw_{label}.jsonl"]
        unique, damage = {}, []
        for path in originals:
            records, invalid = parse_lines(path)
            damage.append({"path": path.name, "invalid_json_line_numbers": invalid})
            for line, record in records:
                if record.get("label") != label:
                    continue
                encoded = json.dumps(record, sort_keys=True, separators=(",", ":"))
                unique.setdefault(encoded, (path.name, line, record))
        reconstructed = sorted(unique.values(), key=lambda item: (
            item[2].get("elapsed", 0), item[2].get("evaluations", 0), item[2].get("worker", -1)))
        output = base / f"adaptive_v1_valid_{label}.jsonl"
        output.write_text("".join(json.dumps(record, sort_keys=True) + "\n" for _, _, record in reconstructed))
        count = max((record.get("evaluations", 0) for _, _, record in reconstructed), default=0)
        manifest["adaptive_v1"][label] = {"logged_exact_evaluations_lower_bound": count,
            "retained_matching_records": len(reconstructed), "damaged_raw_inputs": damage,
            "reconstructed_path": output.name}
        v1_total += count
        candidate_records.extend(reconstructed)
    manifest["adaptive_v1"]["total_logged_exact_evaluations_lower_bound"] = v1_total

    v2_total, all_complete = 0, True
    for label in ("soul", "jelly", "nuka"):
        path = base / f"adaptive_v2_final_raw_{label}.jsonl"
        records, invalid = parse_lines(path)
        matching = [(path.name, line, record) for line, record in records
                    if record.get("label") == label]
        wrong_labels = sorted({r.get("label") for _, r in records if r.get("label") not in (None, label)})
        if wrong_labels:
            raise ValueError(f"unexpected v2 cross-host labels: {wrong_labels}")
        progress = max((r.get("evaluations", 0) for _, _, r in matching), default=0)
        completions = [r for _, r in records if r.get("type") == "complete"]
        complete = len(completions) == 1 and not invalid
        count = completions[0]["evaluations"] if complete else progress
        if count < progress:
            raise ValueError("v2 completion counter smaller than progress")
        all_complete &= complete
        v2_total += count
        manifest["adaptive_v2"][label] = {"natural_completion_record_present": complete,
            "exact_evaluations" if complete else "logged_exact_evaluations_lower_bound": count,
            "invalid_json_line_numbers": invalid, "final_progress_lower_bound": progress,
            "complete_record": completions[0] if complete else None}
        candidate_records.extend(matching)
    manifest["adaptive_v2"]["all_hosts_naturally_completed"] = all_complete
    manifest["adaptive_v2"]["total_exact_evaluations" if all_complete else "total_logged_exact_evaluations_lower_bound"] = v2_total

    sidecar_total = 0
    for name, expected in (("principal_results.jsonl", 2048), ("external_principal_results.jsonl", 4352),
                           ("paired26_principal_results.jsonl", 2176)):
        path = base / name
        records, invalid = parse_lines(path)
        scored = [(name, line, r) for line, r in records if "upper" in r and "phi" in r]
        if invalid or len(scored) != expected:
            raise ValueError(f"sidecar count/integrity mismatch: {name}")
        manifest["sidecars"][name] = {"exact_evaluations": expected}
        sidecar_total += expected
        candidate_records.extend(scored)
    manifest["counted_exact_evaluations_lower_bound"] = initial_count + v1_total + v2_total + sidecar_total

    best = {}
    for path, line, record in candidate_records:
        n = record.get("n", 0)
        if n < 11 or n > 26 or "upper" not in record or "phi" not in record:
            continue
        key = (record["phi"], record.get("peaks", 10**18), record["upper"])
        if n not in best or key < best[n][0]:
            best[n] = (key, path, line, record)
    winners = base / "final_winners"
    winners.mkdir(exist_ok=True)
    for n in sorted(best):
        _, path, line, record = best[n]
        A = upper_matrix(record)
        winner = {"n": n, "A": A, "Phi": record["phi"], "normalized_Phi": record["phi"] / n**1.5,
                  "saved_witness_check": witness_check(record, A), "source_log": path,
                  "source_line": line, "record": record,
                  "classification": "EXACT_ENUMERATOR_FINITE_MATRIX_NOT_GLOBAL_OPTIMUM"}
        json_path = winners / f"best_n{n}.json"
        text_path = winners / f"best_n{n}.txt"
        json_path.write_text(json.dumps(winner, sort_keys=True) + "\n")
        text_path.write_text(str(n) + "\n" + "\n".join(" ".join(map(str, row)) for row in A) + "\n")
        manifest["final_winners"].append({"n": n, "Phi": record["phi"], "json": str(json_path.relative_to(base)),
            "text": str(text_path.relative_to(base)), "witness_check": winner["saved_witness_check"]})

    sat_paths = sorted((base / "eigen64_first").glob("*.json"))
    sat_records = [json.loads(path.read_text()) for path in sat_paths]
    if len(sat_records) != 16 or any(r["classification"] != "EXACT_SPECTRAL_EQUALITY_WITNESS" or r["exact_Phi"] != 256 for r in sat_records):
        raise ValueError("H64 witness census mismatch")
    manifest["H64_screen"] = {"matrices": 16, "exact_Phi": 256, "all_have_checked_Boolean_eigenvectors": True,
        "infeasible_models": 0, "max_elapsed_seconds": max(r["elapsed_seconds"] for r in sat_records)}

    if prepare_only:
        print(json.dumps({"phase": "winner_preparation_before_independent_verification",
            "counted_exact_evaluations_lower_bound": manifest["counted_exact_evaluations_lower_bound"],
            "adaptive_v2_all_complete": all_complete, "winners": manifest["final_winners"]}, sort_keys=True))
        return

    independent, invalid = parse_lines(base / "final_winners.verify.jsonl")
    independent = [record for _, record in independent]
    expected = {entry["n"]: entry["Phi"] for entry in manifest["final_winners"]}
    if invalid or len(independent) != len(expected) or any(
            record.get("checks") != "PASS" or expected.get(record["n"]) != record["phi"]
            for record in independent):
        raise ValueError("independent final-winner replay mismatch")
    manifest["independent_final_winner_replay"] = {
        "matrices": len(independent), "checks": "ALL_PASS",
        "receipt": "final_winners.verify.jsonl",
        "total_projective_states": sum(record["states"] for record in independent)}
    manifest["independent_imported_GPU_odd_replays"] = []
    for n, phi in ((27, 67), (29, 72), (31, 79)):
        path = base / f"gpu_odd_n{n}.verify.json"
        record = json.loads(path.read_text())
        if record["n"] != n or record["phi"] != phi or record["checks"] != "PASS":
            raise ValueError("imported GPU odd replay mismatch")
        manifest["independent_imported_GPU_odd_replays"].append({
            "n": n, "Phi": phi, "states": record["states"], "receipt": path.name,
            "not_counted_as_CPU_search_evaluations": True})

    for path in sorted(base.rglob("*")):
        if path.is_file() and path.name not in ("FINAL_MANIFEST.json", "FILES.sha256") and "__pycache__" not in path.parts:
            manifest["files"].append({"path": str(path.relative_to(base)), "bytes": path.stat().st_size, "sha256": sha(path)})
    manifest_path = base / "FINAL_MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    checksums = "".join(f"{item['sha256']}  {item['path']}\n" for item in manifest["files"])
    checksums += f"{sha(manifest_path)}  FINAL_MANIFEST.json\n"
    (base / "FILES.sha256").write_text(checksums)
    print(json.dumps({"manifest": str(manifest_path), "counted_exact_evaluations_lower_bound": manifest["counted_exact_evaluations_lower_bound"],
        "adaptive_v2_all_complete": all_complete, "winners": manifest["final_winners"]}, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    finalize(args.directory, args.prepare_only)
