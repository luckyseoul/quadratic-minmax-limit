# CPU campaign: finite evidence, original problem remains open

This package contains the sources, inputs, source matrices, all retained raw logs,
host-filtered recoverable records, finite winner matrices, sidecar searches, and
the 16 checked Boolean-eigenvector witnesses from the authorized September 6,
2026 broad compute campaign. The originating repository SHA was
`6bcd7d46f307d0e55141244daa3e58044f32cf55`. The CPU agent made no main-repository edits.

The three worker allocations were soulkiller 76, Jellyfin 12, and NUKA 12.
All matrix searches enumerate every projective Boolean state in integer arithmetic.
Evaluation counts count calls, not distinct matrices, switching classes, or theorems.
Initial source-bank preparation and small selftests are not included in reported
campaign counts. Finite exact scores do not prove global optimality or convergence.

## Explicit old-log limitation

While staging the v2 executable, a recursive copy accidentally overwrote parts of
the OLD remote adaptive-v1 logs with a local soul log. This was reported immediately
to the parent. Earlier authentic per-host snapshots and all final mixed raw logs
are preserved. `adaptive_v1_valid_*.jsonl` contains only valid JSON records whose
label matches the expected host, deduplicated against the earlier snapshots.
Its counts are logged lower bounds, never claimed complete. The initial 57,216
candidate campaign, sidecars, and NEW adaptive-v2 logs are unaffected.

## Replays

Build and replay the initial exhaustive family/shard campaign:

```sh
g++ -O3 -march=native -std=c++17 -fopenmp search.cpp -o search_replay
./search_replay --selftest
./search_replay 76 0 76 100 32768
./search_replay 12 76 12 100 32768
./search_replay 12 88 12 100 32768
```

Adaptive v1 and v2 are time-limited, shared-bank multi-start searches; seed streams
are deterministic per worker, but thread scheduling and wall-clock limits affect
the trajectory. Every retained best and progress record stores the actual full
upper-triangular matrix and an exact extremal witness. Their finite scores can
therefore be replayed independently of the original trajectory.

```sh
g++ -O3 -march=native -std=c++17 independent_verify.cpp -o independent_verify
./independent_verify final_winners/best_n26.txt
```

The independent verifier updates all integer local fields, unlike the searcher's
popcount update; it also checks first and second full-cube moments, energy parity,
extremal witnesses, and final local fields. Orders up to 10 are checked directly
at every state. The initial popcount implementation separately passed 216 random
full-cube brute-force comparisons at orders 2 through 10 and the Paley order-6
known-value test on each host.

`principal_sweep.cpp` and `external_principal.cpp` preserve source orders and exact
retained vertex subsets in every record. The original source matrix for the n32
principal sweep is `source_n32_gpu.txt`; for the paired n26 sweep it is
`v100_paired_n26_phi61.txt`, also reconstructed from the retained V100 checkpoint.

The H64 screen uses OR-Tools 9.15.6755, one solver worker per input:

```sh
python boolean_eigen_cpsat.py --output-dir eigen_replay --workers 8 --seconds 30 --inputs candidate_n64_*.json
```

All 16 shortlisted matrices have checked Boolean +8 eigenvectors and exact Phi 256.
No infeasibility, improvement below 256, or proof-log certificate is asserted for
them. Their lower heuristic scores were not upper bounds.

The low-peak n15/n16 source classes were independently verified and sent to the
V100 agent. Its imported `low_peak_lift_v100_receipt.json` records doubled scores
85 and 96 after all diagonal choices; these do not improve the stronger paired
families. Those GPU evaluations are excluded from this package's CPU counts.

The final sixteen CPU-bank matrices were all independently re-enumerated with
the integer-field verifier; receipts are in `final_winners.verify.jsonl`.
Imported GPU odd-order winners at orders 27, 29, and 31 were also independently
certified at Phi 67, 72, and 79. The order-31 check uses the retained 32-cap variant
`independent_verify32.cpp`; these checks are not counted as CPU search evaluations.

`FINAL_MANIFEST.json` records exact completed counts where available and explicitly
labels incomplete counts as lower bounds. `FILES.sha256` covers all packaged data
and the manifest, excluding itself. The final package is created only after the
05:08 UTC checkpoint and termination/completion checks on the CPU agent's own jobs.
