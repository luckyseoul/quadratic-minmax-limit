#!/usr/bin/env bash
set -euo pipefail
cd /tmp/original-mo-cpu-structured.Z49T3i
sha256sum boolean_eigen_cpsat.py
nohup env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 /home/nick/.venvs/mo-exact/bin/python boolean_eigen_cpsat.py --output-dir /tmp/original-mo-cpu-structured.Z49T3i/eigen64_first --workers 8 --seconds 30 --inputs /tmp/original-mo-cpu-structured.Z49T3i/candidate_n64_*.json > eigen64_first.log 2> eigen64_first.errors < /dev/null &
eigen_pid=$!
printf '%s\n' "$eigen_pid"
sleep 1
ps -p "$eigen_pid" -o pid,nlwp,pcpu,etime,args
