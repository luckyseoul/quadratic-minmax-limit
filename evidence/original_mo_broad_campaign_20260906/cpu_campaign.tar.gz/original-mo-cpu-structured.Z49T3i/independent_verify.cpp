#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

// Independent exact verifier: update ALL integer local fields on each
// projective Gray step. This does not use the searcher's popcount formula.
int main(int argc, char **argv) {
  try {
    if (argc != 2) throw std::runtime_error("usage: verify matrix.txt");
    std::ifstream input(argv[1]);
    int n;
    if (!(input >> n) || n < 2 || n > 30)
      throw std::runtime_error("matrix order must be 2..30");
    std::vector<int> a(n*n), x(n,1), fields(n,0);
    for (int &v : a) if (!(input >> v))
      throw std::runtime_error("missing matrix entry");
    std::string extra;
    if (input >> extra) throw std::runtime_error("unexpected trailing input");
    for (int i=0; i<n; ++i) for (int j=0; j<n; ++j) {
      if (a[i*n+j] != a[j*n+i] ||
          (i==j ? a[i*n+j]!=0 : std::abs(a[i*n+j])!=1))
        throw std::runtime_error("not a complete symmetric zero-diagonal signing");
      fields[i] += a[i*n+j];
    }
    auto direct = [&](uint64_t mask) {
      int q=0;
      for (int i=0; i<n; ++i) for (int j=i+1; j<n; ++j)
        q += a[i*n+j] * (((mask>>i)&1) ? -1:1)
                         * (((mask>>j)&1) ? -1:1);
      return q;
    };
    const auto started=std::chrono::steady_clock::now();
    const uint64_t states=uint64_t(1)<<(n-1);
    int q=direct(0), lo=q, hi=q;
    uint64_t mask=0, lo_mask=0, hi_mask=0;
    int64_t sum=0;
    uint64_t sum2=0, direct_checks=0;
    const int edges=n*(n-1)/2;
    std::vector<uint64_t> hist(2*edges+1,0);
    for (uint64_t t=0; t<states; ++t) {
      if (t) {
        const int i=1+__builtin_ctzll(t), old=x[i];
        q -= 2*old*fields[i];
        for (int j=0; j<n; ++j) fields[j] -= 2*old*a[j*n+i];
        x[i] = -old;
        mask ^= uint64_t(1)<<i;
      }
      if (n<=10) {
        if (q != direct(mask)) throw std::runtime_error("direct state mismatch");
        ++direct_checks;
      }
      if (q<lo) {lo=q; lo_mask=mask;}
      if (q>hi) {hi=q; hi_mask=mask;}
      if (q < -edges || q > edges || ((q-edges)&1))
        throw std::runtime_error("energy range or parity failure");
      ++hist[q+edges];
      sum += q;
      sum2 += int64_t(q)*q;
    }
    if (sum || sum2 != uint64_t(edges)*states)
      throw std::runtime_error("full-cube moment check failure");
    if (direct(lo_mask)!=lo || direct(hi_mask)!=hi || direct(mask)!=q)
      throw std::runtime_error("extremal/final witness check failure");
    for (int i=0; i<n; ++i) {
      int h=0;
      for (int j=0; j<n; ++j) h += a[i*n+j]*x[j];
      if (h!=fields[i]) throw std::runtime_error("final local-field mismatch");
    }
    const auto seconds=std::chrono::duration<double>(
        std::chrono::steady_clock::now()-started).count();
    const int phi=std::max(-lo,hi);
    std::cout << std::setprecision(17)
      << "{\"n\":" << n << ",\"states\":" << states
      << ",\"min_q\":" << lo << ",\"max_q\":" << hi
      << ",\"phi\":" << phi << ",\"alpha\":" << phi/std::pow(n,1.5)
      << ",\"min_witness_mask\":" << lo_mask
      << ",\"max_witness_mask\":" << hi_mask
      << ",\"sum_q\":" << sum << ",\"sum_q2\":" << sum2
      << ",\"direct_small_checks\":" << direct_checks
      << ",\"seconds\":" << seconds << ",\"histogram\":[";
    bool first=true;
    for (int e=-edges; e<=edges; ++e) if (hist[e+edges]) {
      if (!first) std::cout << ',';
      first=false;
      std::cout << '[' << e << ',' << hist[e+edges] << ']';
    }
    std::cout << "],\"checks\":\"PASS\"}\n";
  } catch (const std::exception &e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
