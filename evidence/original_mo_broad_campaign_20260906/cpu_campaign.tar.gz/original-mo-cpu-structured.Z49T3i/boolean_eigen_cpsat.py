#!/usr/bin/env python3
"""Exact linear Boolean eigenvector screening for symmetric flat sign matrices.

INFEASIBLE is a deterministic CP-SAT result with exported model and replay data,
not an independently checkable proof log. SAT witnesses are checked in integers.
"""
import argparse
import concurrent.futures
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import time

import ortools
from ortools.sat.python import cp_model


def validate(H):
    n = len(H)
    r = math.isqrt(n)
    if r * r != n or any(len(row) != n for row in H):
        raise ValueError("order must be a square and matrix square")
    if any(type(v) is not int or v not in (-1, 1) for row in H for v in row):
        raise ValueError("H must contain exact integer signs")
    if any(H[i][j] != H[j][i] for i in range(n) for j in range(n)):
        raise ValueError("H is not symmetric")
    if sum(H[i][i] for i in range(n)):
        raise ValueError("trace H is not zero")
    for i in range(n):
        for j in range(n):
            if sum(H[i][k] * H[k][j] for k in range(n)) != (n if i == j else 0):
                raise ValueError("H squared is not n times I")
    return n, r


def make_model(H, sigma):
    n, r = len(H), math.isqrt(len(H))
    model = cp_model.CpModel()
    b = [model.NewBoolVar(f"b_{j}") for j in range(n)]
    model.Add(b[0] == 1)
    for i in range(n):
        model.Add(2 * sum(H[i][j] * b[j] for j in range(n))
                  - 2 * sigma * r * b[i] == sum(H[i]) - sigma * r)
    return model, b


def checked_witness(H, x, sigma):
    n, r = validate(H)
    if len(x) != n or any(v not in (-1, 1) for v in x) or x[0] != 1:
        raise AssertionError("invalid Boolean witness")
    Hx = [sum(H[i][j] * x[j] for j in range(n)) for i in range(n)]
    if Hx != [sigma * r * v for v in x]:
        raise AssertionError("eigenvector witness does not satisfy all equations")
    q = sum(H[i][j] * x[i] * x[j] for i in range(n) for j in range(i + 1, n))
    if 2 * q != sigma * n * r:
        raise AssertionError("quadratic equality witness mismatch")
    return q


def selftest():
    H = [[1 if (i & j).bit_count() % 2 == 0 else -1 for j in range(4)] for i in range(4)]
    validate(H)
    for sigma in (1, -1):
        for bv in itertools.product((0, 1), repeat=4):
            x = [2 * v - 1 for v in bv]
            equations = all(2 * sum(H[i][j] * bv[j] for j in range(4))
                            - 4 * sigma * bv[i] == sum(H[i]) - 2 * sigma
                            for i in range(4))
            eigen = all(sum(H[i][j] * x[j] for j in range(4)) == 2 * sigma * x[i] for i in range(4))
            assert equations == eigen
        model, b = make_model(H, sigma)
        solver = cp_model.CpSolver()
        solver.parameters.num_search_workers = 1
        status = solver.Solve(model)
        assert status in (cp_model.OPTIMAL, cp_model.FEASIBLE)
        checked_witness(H, [2 * solver.Value(v) - 1 for v in b], sigma)
    impossible, _ = make_model(H, 1)
    impossible.Add(0 == 1)
    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = 1
    assert solver.Solve(impossible) == cp_model.INFEASIBLE
    return {"selftest": "PASS", "enumerated_equivalence_cases": 32,
            "sat_witnesses": 2, "artificial_infeasible_model": 1,
            "ortools_version": ortools.__version__}


def screen(task):
    source_path, output_dir, seconds = task
    began = time.monotonic()
    source = json.loads(Path(source_path).read_text())
    H = source["H"]
    n, r = validate(H)
    matrix_sha = hashlib.sha256(bytes((v + 1) // 2 for row in H for v in row)).hexdigest()
    output = Path(output_dir)
    stem = f"n{n}_{matrix_sha}"
    result = {"source": source_path, "n": n, "matrix_sha256_sign_bits": matrix_sha,
              "source_file_sha256": hashlib.sha256(Path(source_path).read_bytes()).hexdigest(),
              "ortools_version": ortools.__version__, "solver_workers": 1,
              "seconds_per_sign": seconds, "flat_validation": "PASS", "phases": [],
              "classification": "UNRESOLVED", "spectral_upper_Phi": n * r // 2}
    for sigma in (1, -1):
        model, b = make_model(H, sigma)
        solver = cp_model.CpSolver()
        solver.parameters.num_search_workers = 1
        solver.parameters.max_time_in_seconds = seconds
        solver.parameters.random_seed = int(matrix_sha[:7], 16)
        status = solver.Solve(model)
        phase = {"sigma": sigma, "status": solver.StatusName(status),
                 "wall_seconds": solver.WallTime(), "branches": solver.NumBranches(),
                 "conflicts": solver.NumConflicts(), "response_stats": solver.ResponseStats()}
        if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            x = [2 * solver.Value(v) - 1 for v in b]
            phase["witness_x"] = x
            phase["witness_Q"] = checked_witness(H, x, sigma)
            phase["witness_check"] = "PASS"
            result["classification"] = "EXACT_SPECTRAL_EQUALITY_WITNESS"
            result["exact_Phi"] = n * r // 2
            result["phases"].append(phase)
            break
        model_path = output / f"{stem}_sigma{sigma}.pbtxt"
        model.ExportToFile(str(model_path))
        phase["model_path"] = str(model_path)
        phase["model_sha256"] = hashlib.sha256(model_path.read_bytes()).hexdigest()
        result["phases"].append(phase)
    if len(result["phases"]) == 2 and all(p["status"] == "INFEASIBLE" for p in result["phases"]):
        result["classification"] = "CPSAT_BOTH_EIGENVALUE_SIGNS_INFEASIBLE"
        parity = (n * (n - 1) // 2) % 2
        result["certified_upper_Phi_from_solver_result"] = max(
            k for k in range(n * r // 2) if k % 2 == parity)
        result["proof_log_available"] = False
    result["elapsed_seconds"] = time.monotonic() - began
    result_path = output / f"{stem}.json"
    result_path.write_text(json.dumps(result, sort_keys=True) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", nargs="+", default=[])
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--seconds", type=float, default=30)
    parser.add_argument("--selftest-only", action="store_true")
    args = parser.parse_args()
    Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    print(json.dumps(selftest()), flush=True)
    if args.selftest_only:
        return
    tasks = [(p, args.output_dir, args.seconds) for p in args.inputs]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as executor:
        for result in executor.map(screen, tasks):
            print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
