#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
g++ -O3 -march=native -std=c++17 -fopenmp adaptive.cpp -o adaptive
sha256sum search.cpp adaptive.cpp adaptive
nohup ./adaptive "$@" > adaptive_results.jsonl 2> adaptive_errors.log < /dev/null &
adaptive_pid=$!
printf '%s\n' "$adaptive_pid"
sleep 1
ps -p "$adaptive_pid" -o pid,nlwp,pcpu,etime,args
