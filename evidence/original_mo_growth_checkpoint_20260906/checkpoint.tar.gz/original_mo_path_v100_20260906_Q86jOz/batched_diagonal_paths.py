#!/usr/bin/env python3
"""Batched exact XOR profiles followed by the separable Hamming transform.

For projective t_0=1, profiles L,M give max_t(L(t)+d.t,M(t)-d.t).
Index full signs by their minus-bit mask. Set f[2v]=L[v] and
f[2v+1]=M[(2**(n-1)-1)^v]. Then every diagonal score is
n+max_x(f[x]-2*d_H(d,x)). The imported simultaneous two-point kernel
computes this exactly, independently in each aligned parent cube.
Only fixed-source diagonal families are exhausted; no global theorem.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import socket
import sys
import time

import cupy as cp
import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path, value):
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value,indent=2)+'\n')
    temporary.replace(path)


def valid(a):
    batch,n,k=a.shape
    assert batch>0 and 2<=n<=19 and k==n
    assert np.array_equal(a,a.transpose(0,2,1))
    assert np.all(a[:,np.arange(n),np.arange(n)]==0)
    assert np.all(np.abs(a[:,np.triu_indices(n,1)[0],np.triu_indices(n,1)[1]])==1)


def profiles(matrices, x_batch):
    valid(matrices)
    batch,n,_=matrices.shape; m=1<<(n-1)
    masks=cp.arange(m,dtype=cp.int32)
    s=cp.ones((m,n),dtype=cp.float32)
    s[:,1:]=1-2*((masks[:,None]>>cp.arange(n-1,dtype=cp.int32))&1)
    af=cp.asarray(matrices,dtype=cp.float32)
    q=cp.sum(cp.matmul(s[None],af)*s[None],axis=2)/2
    lo=cp.full((batch,m),-np.inf,dtype=cp.float32); hi=lo.copy()
    for start in range(0,m,x_batch):
        stop=min(m,start+x_batch); xids=masks[start:stop]
        yids=xids[:,None]^masks[None,:]
        c=cp.matmul(cp.matmul(s[None,start:stop],af),s.T)
        c=cp.take_along_axis(c,yids[None],axis=2)
        delta=cp.abs(q[:,start:stop,None]-q[:,yids])
        lo=cp.maximum(lo,cp.max(delta+c,axis=1))
        hi=cp.maximum(hi,cp.max(delta-c,axis=1))
    parent_phi=cp.asnumpy(cp.max(cp.abs(q),axis=1)).astype(np.int32)
    # All quantities are integral and bounded by 2*n*n < 2**24.
    assert bool(cp.all(lo==cp.rint(lo))) and bool(cp.all(hi==cp.rint(hi)))
    return lo,hi,parent_phi


def diagonals(engine,lo,hi,n):
    batch=lo.shape[0]; size=1<<n
    assert lo.shape==hi.shape==(batch,size//2)
    f=cp.empty((batch,size),dtype=cp.int16)
    f[:,0::2]=lo.astype(cp.int16); f[:,1::2]=hi[:,::-1].astype(cp.int16)
    # Global witness offsets are harmless: each bit update stays within one
    # size-aligned parent cube, and only its score is consumed here.
    w=cp.arange(batch*size,dtype=cp.uint32)
    pairs=batch*size//2
    assert batch*size<2**32
    for bit in range(n):
        engine.step(((pairs+255)//256,),(256,),
                    (f,w,np.uint32(1<<bit),np.uint32(pairs)))
    return cp.asnumpy(f).astype(np.int32)+n


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--legacy-directory',type=Path,required=True)
    p.add_argument('--transform-directory',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--archives',nargs='*',type=Path)
    p.add_argument('--validation',type=Path)
    p.add_argument('--parents',type=Path)
    p.add_argument('--skip-result',type=Path)
    p.add_argument('--batch',type=int,default=16)
    p.add_argument('--x-batch',type=int,default=64)
    p.add_argument('--limit',type=int)
    args=p.parse_args(); assert args.batch>0 and args.x_batch>0
    sys.path.insert(0,str(args.legacy_directory))
    sys.path.insert(0,str(args.transform_directory))
    from extension_transform import Engine
    from diagonal_wave5 import diagonal_profile,score_diagonals,streaming_cross_phi
    args.output.mkdir(parents=True,exist_ok=False)
    cp.get_default_memory_pool().set_limit(size=10*1024**3)
    engine=Engine('cuda'); started=time.time()
    manifest=dict(script_sha256=sha(__file__),
                  transform_sha256=sha(args.transform_directory/'extension_transform.py'),
                  legacy_profile_sha256=sha(args.legacy_directory/'diagonal_wave5.py'),
                  hostname=socket.gethostname(),pid=os.getpid(),device=engine.device,
                  arguments={k:([str(x) for x in v] if isinstance(v,list) else str(v) if isinstance(v,Path) else v)
                             for k,v in vars(args).items()})
    if args.archives:
        cases=[]
        archives=[np.load(path) for path in args.archives]
        n=len(archives[0]['A']); assert all(len(z['A'])==n for z in archives)
        matrices=np.stack([z['A'] for z in archives])
        lo,hi,pa=profiles(matrices,args.x_batch); phi=diagonals(engine,lo,hi,n)
        lows=cp.asnumpy(lo).astype(np.int32); highs=cp.asnumpy(hi).astype(np.int32)
        for i,(path,z) in enumerate(zip(args.archives,archives)):
            assert np.array_equal(lows[i],z['L']) and np.array_equal(highs[i],z['M'])
            assert np.array_equal(phi[i],z['phi'])
            cases.append(dict(path=str(path),sha256=sha(path),n=n,all_diagonals=1<<n,
                              parent_phi=int(pa[i]),best_child_phi=int(phi[i].min())))
        # Different small matrix orders test batch separation and the original
        # scorer independently of the stored profile archives.
        rng=np.random.default_rng(2026090611)
        for n in (4,6,8):
            a=np.triu(rng.choice([-1,1],(3,n,n)),1).astype(np.int8)
            a+=a.transpose(0,2,1)
            lo,hi,pa=profiles(a,7); phi=diagonals(engine,lo,hi,n)
            for i in range(3):
                s,l,h,old_pa=diagonal_profile(a[i],x_batch=9)
                expected=score_diagonals(s,l,h,n,batch=13)
                assert np.array_equal(phi[i],expected) and int(pa[i])==old_pa
                d=1-2*((int(np.argmin(phi[i]))>>np.arange(n))&1).astype(np.int8)
                b=a[i].copy();b[np.arange(n),np.arange(n)]=d
                assert streaming_cross_phi(a[i],b)==int(phi[i].min())
            cases.append(dict(n=n,random_parents=3,all_diagonals=3*(1<<n)))
        receipt=dict(status='PASS',manifest=manifest,cases=cases,elapsed_seconds=time.time()-started)
        atomic(args.output/'validation.json',receipt); print(json.dumps(receipt),flush=True)
        return
    assert args.parents and args.validation
    checked=json.loads(args.validation.read_text()); assert checked['status']=='PASS'
    for key in ('script_sha256','transform_sha256','legacy_profile_sha256'):
        assert checked['manifest'][key]==manifest[key]
    parents=json.loads(args.parents.read_text()); skip=set()
    if args.skip_result:
        old=json.loads(args.skip_result.read_text())
        skip={int(row['source_id']) for row in old['results']}
        for row in old['results']:
            assert np.array_equal(row['A'],parents[row['source_id']]['A'])
    selected=[(i,row) for i,row in enumerate(parents) if i not in skip]
    if args.limit is not None:selected=selected[:args.limit]
    manifest.update(parent_sha256=sha(args.parents),validation_sha256=sha(args.validation),
                    skip_result_sha256=sha(args.skip_result) if args.skip_result else None,
                    skipped_parents=len(skip),selected_parents=len(selected))
    results=[]; best=None
    if not selected:
        atomic(args.output/'result.json',dict(status='completed',manifest=manifest,
               results=[],diagonal_evaluations={},elapsed_seconds=time.time()-started))
        return
    for begin in range(0,len(selected),args.batch):
        group=selected[begin:begin+args.batch]
        a=np.asarray([row['A'] for _,row in group],dtype=np.int8); n=len(a[0])
        begun=time.time();lo,hi,pa=profiles(a,args.x_batch); phi=diagonals(engine,lo,hi,n)
        assert all(int(pa[i])==source['Phi'] for i,(_,source) in enumerate(group))
        lows=cp.asnumpy(lo).astype(np.int32);highs=cp.asnumpy(hi).astype(np.int32)
        for i,(source_id,source) in enumerate(group):
            winner=int(np.argmin(phi[i])); value=int(phi[i,winner])
            d=1-2*((winner>>np.arange(n))&1).astype(np.int8)
            b=a[i].copy();b[np.arange(n),np.arange(n)]=d
            replay=None
            if best is None or value<best:
                replay=streaming_cross_phi(a[i],b); assert replay==value; best=value
            archive=args.output/f'n{n}_source{source_id:04d}_diagonals.npz'
            np.savez_compressed(archive,A=a[i],phi=phi[i],L=lows[i],M=highs[i],winner_d=d)
            row=dict(name=archive.stem,n=n,order=2*n,source_id=source_id,
                     A=a[i].tolist(),B=b.tolist(),phi_A=int(pa[i]),phi_K=value,
                     alpha_K=value/(2*n)**1.5,cross_ratio=value/(2*math.sqrt(2)*int(pa[i])),
                     diagonal_family_size=1<<n,winner_mask=winner,
                     winner_count=int(np.count_nonzero(phi[i]==value)),
                     gpu_original_all_pairs_replay_phi=replay,
                     archive=str(archive),archive_sha256=sha(archive))
            results.append(row)
            if replay is not None:atomic(args.output/f'n{n}_best_checkpoint.json',row)
        summary=dict(status='running',manifest=manifest,results=results,
                     diagonal_evaluations={str(n):len(results)*(1<<n)},
                     elapsed_seconds=time.time()-started,
                     classification='exact fixed-parent diagonal path transitions; no global closure')
        atomic(args.output/'result.json',summary)
        print(json.dumps(dict(stage='batch',parents=len(results),last_source_id=group[-1][0],
                              pool_best=best,batch_seconds=time.time()-begun,
                              elapsed_seconds=time.time()-started)),flush=True)
    summary['status']='completed'; atomic(args.output/'result.json',summary)


if __name__=='__main__':main()
