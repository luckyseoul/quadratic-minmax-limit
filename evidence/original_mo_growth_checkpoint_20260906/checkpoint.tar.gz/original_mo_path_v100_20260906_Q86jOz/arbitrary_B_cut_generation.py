#!/usr/bin/env python3
"""Fixed-A arbitrary-B feasibility with rigorous cuts and exact GPU separation.

For projective x,y, Phi([[A,B],[B.T,-A]]) = max(|Qx-Qy|+|xBy|).
Thus each pair gives -R <= sum c_ij*(2*z_ij-1) <= R,
R=T-|Qx-Qy|. Any subset is necessary, never a sampled norm certificate.
Only B00=+1 is fixed, using the unconditional B -> -B symmetry.
UNKNOWN stops an unchanged model. INFEASIBLE is solver-reported, not a
portable independently checked proof. A passing full separator is exact.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import time
import numpy as np
from ortools.sat.python import cp_model


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path, value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)


def states(n):
    ids=np.arange(1<<(n-1),dtype=np.uint32)
    s=np.ones((len(ids),n),dtype=np.int64)
    s[:,1:]=1-2*((ids[:,None]>>np.arange(n-1))&1).astype(np.int64)
    return s


class Cuts:
    def __init__(self,a,target):
        self.a=a.astype(np.int64);self.n=len(a);self.target=target
        self.s=states(self.n);self.q=np.sum((self.s@self.a)*self.s,axis=1)//2
        self.model=cp_model.CpModel()
        self.bits=[self.model.new_bool_var(f'b_{i}_{j}') for i in range(self.n) for j in range(self.n)]
        self.model.add(self.bits[0]==1);self.pairs=[];self.known=set()

    def add(self,xi,yi):
        key=(int(xi),int(yi))
        if key in self.known:return False
        self.known.add(key);self.pairs.append(key)
        c=np.outer(self.s[xi],self.s[yi]).reshape(-1)
        rhs=self.target-abs(int(self.q[xi]-self.q[yi]))
        expr=cp_model.LinearExpr.weighted_sum(self.bits,(2*c).tolist())-int(c.sum())
        self.model.add_linear_constraint(expr,-rhs,rhs)
        return True

    def hint(self,b):
        self.model.clear_hints()
        if b[0,0]<0:b=-b
        for bit,value in zip(self.bits,b.reshape(-1),strict=True):self.model.add_hint(bit,int(value>0))

    def verify_candidate(self,b):
        assert np.all(np.abs(b)==1) and b[0,0]==1
        for xi,yi in self.pairs:
            value=abs(int(self.q[xi]-self.q[yi]))+abs(int(self.s[xi]@b@self.s[yi]))
            assert value<=self.target,(xi,yi,value,self.target)


class Separator:
    def __init__(self,a):
        import cupy as cp
        self.cp=cp;self.a=a.astype(np.int64);self.s=states(len(a))
        self.q=np.sum((self.s@self.a)*self.s,axis=1)//2
        self.sg=cp.asarray(self.s,dtype=cp.float32);self.qg=cp.asarray(self.q,dtype=cp.float32)

    def exact(self,b,target,x_batch=1024,per_tile=16):
        cp=self.cp;m=len(self.s);by=cp.asarray(b,dtype=cp.float32)@self.sg.T
        best=-1;witness=None;cuts=[]
        for start in range(0,m,x_batch):
            stop=min(start+x_batch,m)
            value=cp.abs(self.qg[start:stop,None]-self.qg[None,:])+cp.abs(self.sg[start:stop]@by)
            flat=value.reshape(-1);where=int(cp.argmax(flat));maximum=int(flat[where])
            if maximum>best:best=maximum;witness=(start+where//m,where%m)
            if maximum<=target:continue
            k=min(per_tile,len(flat))
            positions=cp.argpartition(flat,len(flat)-k)[-k:]
            for loc,val in zip(cp.asnumpy(positions),cp.asnumpy(flat[positions]),strict=True):
                if val>target:cuts.append((start+int(loc)//m,int(loc)%m))
        assert witness is not None
        # CPU integer checks every exported cut and the maximizing witness.
        for xi,yi in cuts+[witness]:
            direct=abs(int(self.q[xi]-self.q[yi]))+abs(int(self.s[xi]@b.astype(np.int64)@self.s[yi]))
            assert direct>target if (xi,yi)!=witness else direct==best
        return best,witness,sorted(set(cuts))


def solve(cuts,seconds,workers,seed):
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=seconds
    solver.parameters.num_search_workers=workers;solver.parameters.random_seed=seed
    status=solver.solve(cuts.model);name=solver.status_name(status)
    b=None
    if status in (cp_model.FEASIBLE,cp_model.OPTIMAL):
        b=np.asarray([2*solver.value(z)-1 for z in cuts.bits],dtype=np.int64).reshape(cuts.n,cuts.n)
        cuts.verify_candidate(b)
    return name,b,solver.response_stats()


def selftest():
    from joint_path_walkers import Scorer
    rng=np.random.default_rng(2026090618);rows=[]
    for n in (2,3):
        a=np.triu(rng.choice([-1,1],(n,n)),1);a+=a.T
        s=states(n);q=np.sum((s@a)*s,axis=1)//2;full=states(2*n);norms=[]
        for mask in range(1<<(n*n)):
            b=(1-2*((mask>>np.arange(n*n))&1)).reshape(n,n)
            value=int(np.max(np.abs(q[:,None]-q[None,:])+np.abs(s@b@s.T)))
            k=np.block([[a,b],[b.T,-a]])
            direct=int(np.max(np.abs(np.sum((full@k)*full,axis=1)//2)))
            assert value==direct;norms.append(value)
        optimum=min(norms)
        for target,expected in ((optimum-2,'INFEASIBLE'),(optimum,'OPTIMAL')):
            cuts=Cuts(a,target)
            for xi in range(len(s)):
                for yi in range(len(s)):cuts.add(xi,yi)
            status,b,_=solve(cuts,10,1,2026090618)
            assert status==expected,(status,expected)
            if b is not None:assert int(np.max(np.abs(q[:,None]-q[None,:])+np.abs(s@b@s.T)))<=target
        rows.append(dict(n=n,exhaustive_B_matrices=len(norms),minimum=optimum,complete_CP_SAT_boundary='PASS'))
    for n in (4,6,8):
        a=np.triu(rng.choice([-1,1],(n,n)),1);a+=a.T
        b=rng.choice([-1,1],(n,n));old=Scorer(n);expected,_=old.exact(a,b)
        value,witness,violations=Separator(a).exact(b,expected-2,x_batch=7,per_tile=5)
        assert value==expected and len(violations)>0
        rows.append(dict(n=n,old_original_all_pairs_phi=expected,new_separator_phi=value,exported_violations=len(violations)))
    return rows


def main():
    p=argparse.ArgumentParser();p.add_argument('--anchor',type=Path,required=True)
    p.add_argument('--anchor-index',type=int,default=0);p.add_argument('--band',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--reviewed-directory',type=Path,required=True)
    p.add_argument('--target',type=int,required=True);p.add_argument('--initial-peaks',type=int,default=512)
    p.add_argument('--random-pairs',type=int,default=128);p.add_argument('--rounds',type=int,default=100)
    p.add_argument('--solve-seconds',type=float,default=120);p.add_argument('--seconds',type=float,default=1200)
    p.add_argument('--workers',type=int,default=8);p.add_argument('--seed',type=int,default=2026090618)
    p.add_argument('--selftest-only',action='store_true');args=p.parse_args()
    assert args.initial_peaks>0 and args.random_pairs>=0 and args.rounds>0
    assert args.solve_seconds>0 and args.seconds>0 and args.workers>0
    sys.path.insert(0,str(args.reviewed_directory))
    args.output.mkdir(parents=True,exist_ok=False);started=time.time();tests=selftest()
    loaded=json.loads(args.anchor.read_text());anchor=loaded[args.anchor_index] if isinstance(loaded,list) else loaded
    a=np.asarray(anchor['A'],dtype=np.int64);b=np.asarray(anchor['B'],dtype=np.int64);n=len(a)
    assert 2<=n<=16 and a.shape==b.shape==(n,n)
    assert np.array_equal(a,a.T) and np.all(np.diag(a)==0)
    assert np.all(np.abs(a[np.triu_indices(n,1)])==1) and np.all(np.abs(b)==1)
    assert args.target<anchor['phi_K'] and args.target%2==anchor['phi_K']%2
    cuts=Cuts(a,args.target);separator=Separator(a)
    assert int(np.abs(cuts.q).max())==anchor['phi_A']
    z=np.load(args.band);assert np.array_equal(z['A'],a) and np.array_equal(z['B'],b)
    xx=z['x'];yy=z['y'];delta=z['delta'].astype(np.int64);cross=z['cross'].astype(np.int64)
    assert np.array_equal(delta,cuts.q[xx]-cuts.q[yy])
    assert np.array_equal(cross,np.sum((cuts.s[xx]@b)*cuts.s[yy],axis=1))
    f=np.abs(delta)+np.abs(cross);assert int(f.max())==anchor['phi_K']
    validation=dict(status='PASS',selftests=tests,all_saved_band_entries_CPU_verified=len(f),
                    parent_phi=int(np.abs(cuts.q).max()),source_Q_min=int(cuts.q.min()),source_Q_max=int(cuts.q.max()))
    manifest=dict(script_sha256=sha(__file__),reviewed_oracle_sha256=sha(args.reviewed_directory/'joint_path_walkers.py'),
                  anchor_sha256=sha(args.anchor),band_sha256=sha(args.band),anchor_index=args.anchor_index,
                  n=n,target=args.target,seed=args.seed,host=socket.gethostname(),pid=os.getpid(),
                  solver_version=__import__('ortools').__version__,parameters=vars(args).copy())
    manifest['parameters']={k:str(v) if isinstance(v,Path) else v for k,v in manifest['parameters'].items()}
    atomic(args.output/'validation.json',validation);atomic(args.output/'manifest.json',manifest)
    if args.selftest_only:return
    rng=np.random.default_rng(args.seed)
    peak_indices=np.flatnonzero(f==f.max());rng.shuffle(peak_indices)
    for index in peak_indices[:args.initial_peaks]:cuts.add(int(xx[index]),int(yy[index]))
    lows=np.flatnonzero(cuts.q==cuts.q.min());highs=np.flatnonzero(cuts.q==cuts.q.max())
    for xi in lows:
        for yi in highs:cuts.add(int(xi),int(yi));cuts.add(int(yi),int(xi))
    for _ in range(args.random_pairs):cuts.add(int(rng.integers(len(cuts.s))),int(rng.integers(len(cuts.s))))
    cuts.hint(b);classification='BOUNDED_OPEN';candidate_count=0
    for iteration in range(args.rounds):
        remaining=args.seconds-(time.time()-started)
        if remaining<=0:break
        np.save(args.output/f'cuts_{iteration:04d}.npy',np.asarray(cuts.pairs,dtype=np.int32))
        cuts.model.export_to_file(str(args.output/f'model_{iteration:04d}.pbtxt'))
        status,proposal,stats=solve(cuts,min(args.solve_seconds,remaining),args.workers,args.seed+iteration)
        (args.output/f'solver_{iteration:04d}.txt').write_text(stats+'\n')
        report=dict(iteration=iteration,necessary_cut_pairs=len(cuts.pairs),solver_status=status,elapsed=time.time()-started)
        if proposal is None:
            classification='SOLVER_REPORTED_FIXED_A_INFEASIBLE' if status=='INFEASIBLE' else 'OPEN_SOLVER_STOP_'+status
            report['classification']=classification;atomic(args.output/f'round_{iteration:04d}.json',report)
            print(json.dumps(report),flush=True);break
        candidate_count+=1;value,witness,violations=separator.exact(proposal,args.target)
        candidate=dict(A=a.tolist(),B=proposal.tolist(),phi_A=anchor['phi_A'],phi_K=value,
                       target=args.target,witness=list(witness),source_anchor=anchor,
                       status='EXACT_FULL_PROJECTIVE_ALL_PAIRS',growth_orders=[n,2*n],growth_moves=1,
                       optimization_rounds_are_growth=False,changed_B_entries=int(np.count_nonzero(proposal!=b)))
        atomic(args.output/f'candidate_{iteration:04d}.json',candidate)
        report.update(exact_child_phi=value,exported_violating_pairs=len(violations),candidate_count=candidate_count,
                      changed_B_entries=candidate['changed_B_entries'])
        if value<=args.target:
            from joint_path_walkers import Scorer
            independent_value,_=Scorer(n).exact(a,proposal);assert independent_value==value
            classification='EXACT_TARGET_WITNESS_FOUND';atomic(args.output/'winner.json',candidate)
            report['classification']=classification;atomic(args.output/f'round_{iteration:04d}.json',report)
            print(json.dumps(report),flush=True);break
        added=sum(cuts.add(xi,yi) for xi,yi in violations);assert added>0
        report['new_necessary_cut_pairs']=added;atomic(args.output/f'round_{iteration:04d}.json',report)
        print(json.dumps(report),flush=True);cuts.hint(proposal)
    atomic(args.output/'result.json',dict(classification=classification,manifest=manifest,
        necessary_cut_pairs=len(cuts.pairs),exactly_scored_candidates=candidate_count,elapsed=time.time()-started,
        solver_infeasibility_is_not_independently_checked_proof=True))


if __name__=='__main__':main()
