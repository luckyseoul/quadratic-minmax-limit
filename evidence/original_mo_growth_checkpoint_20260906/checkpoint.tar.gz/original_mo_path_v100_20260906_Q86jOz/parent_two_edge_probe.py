#!/usr/bin/env python3
"""Exact source-only test of all unordered two-edge repairs of retained minors."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import cupy as cp
import numpy as np


def main():
    p=argparse.ArgumentParser();p.add_argument('--legacy-directory',type=Path,required=True)
    p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--limit',type=int,default=16);args=p.parse_args()
    sys.path.insert(0,str(args.legacy_directory));from campaign import score_source,spins
    args.output.mkdir(parents=True,exist_ok=False);started=time.time()
    inputs=json.loads(args.input.read_text());rows=[];cache={}
    n=15;ii,jj=np.triu_indices(n,1);first,second=np.triu_indices(len(ii),1)
    assert len(first)==5460
    s=cp.asarray(spins(n),dtype=cp.float32)
    cp.get_default_memory_pool().set_limit(size=10*1024**3)
    for source_id,source in enumerate(inputs[:args.limit]):
        a=np.asarray(source['A'],dtype=np.int8);assert source['phi_A']==29
        assert a.shape==(n,n) and np.array_equal(a,a.T) and np.all(np.diag(a)==0)
        key=a.tobytes()
        if key in cache:phi=cache[key].copy();reused=True
        else:
            phi=np.empty(len(first),dtype=np.int32);reused=False
            for start in range(0,len(first),128):
                stop=min(start+128,len(first));batch=stop-start
                candidates=np.broadcast_to(a,(batch,n,n)).copy();ids=np.arange(batch)
                for edge_ids in (first[start:stop],second[start:stop]):
                    candidates[ids,ii[edge_ids],jj[edge_ids]]*=-1
                    candidates[ids,jj[edge_ids],ii[edge_ids]]*=-1
                values,_=score_source(cp.asarray(candidates,dtype=cp.float32),s)
                phi[start:stop]=values
            cache[key]=phi.copy()
        good=np.flatnonzero(phi<=27)
        archive=args.output/f'source{source_id:02d}_two_edge_parent_norms.npz'
        np.savez_compressed(archive,A=a,first_edge=first,second_edge=second,parent_phi=phi)
        row=dict(source_id=source_id,source_reference=source['id'],minimum_parent_phi=int(phi.min()),
                 exact_unordered_two_edge_repairs=len(phi),reused_identical_parent=reused,
                 strict_repairs=[dict(first_edge=int(first[k]),second_edge=int(second[k]),
                     first_vertices=[int(ii[first[k]]),int(jj[first[k]])],
                     second_vertices=[int(ii[second[k]]),int(jj[second[k]])],phi_A=int(phi[k])) for k in good],
                 archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
        rows.append(row);print(json.dumps(dict(source_id=source_id,min_phi=row['minimum_parent_phi'],
             strict_repairs=len(good),reused=reused,elapsed=time.time()-started)),flush=True)
    result=dict(script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                original_scorer_sha256=hashlib.sha256((args.legacy_directory/'campaign.py').read_bytes()).hexdigest(),
                input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),records=rows,
                elapsed=time.time()-started,classification='exact source norms only; no descendant norm claimed')
    (args.output/'result.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
