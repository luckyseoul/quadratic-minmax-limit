#!/usr/bin/env python3
"""Join two already certified Phi27 parents to their best coherent lift seeds."""
import hashlib
import json
from pathlib import Path
stage=Path(__file__).parent
sources=[('soul_58',stage/'prefix_growth_results/result.json'),
         ('nuka_69540',stage/'nuka27_lift_results/result.json')]
rows=[]
for node_id,path in sources:
    item=next(r for r in json.loads(path.read_text())['results'] if r['n']==15)
    assert item['phi_A']==27
    row=dict(id=node_id,A=item['A'],B=item['B'],phi_A=27,phi_K=item['phi_K'],
             source_receipt=str(path),source_receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    if node_id=='soul_58':
        ancestry=stage/'prefix_growth_ledger/cpu_ancestry_receipt.json'
        data=json.loads(ancestry.read_text());row['cpu_ancestry']=[data['soul_4'],data['soul_58']]
    else:
        ancestry=Path('/tmp/original-mo-pathwalkers.0Suy9n/path_nuka_286876.verified.json')
        data=json.loads(ancestry.read_text());end=next(i for i,r in enumerate(data) if r['node']['id']==node_id)
        row['cpu_ancestry']=data[:end+1]
    row['cpu_ancestry_source']=str(ancestry)
    row['cpu_ancestry_sha256']=hashlib.sha256(ancestry.read_bytes()).hexdigest()
    rows.append(row)
out=stage/'joint_n15_anchors.json';assert not out.exists();out.write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([dict(id=r['id'],phi_A=r['phi_A'],phi_K=r['phi_K']) for r in rows]))
