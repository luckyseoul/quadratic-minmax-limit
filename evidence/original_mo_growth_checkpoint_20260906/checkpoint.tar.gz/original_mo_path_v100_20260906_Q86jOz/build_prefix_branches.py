#!/usr/bin/env python3
"""Consume newly verified CPU growth nodes as ancestors of GPU lifts."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np

p=argparse.ArgumentParser();p.add_argument('--source15',type=Path,required=True)
p.add_argument('--source19',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
for path,n,phi,root_phi,node_id,root_id in ((args.source15,15,27,21,'soul_58','soul_4'),
                                         (args.source19,19,39,33,'soul_194','soul_6')):
    values=list(map(int,path.read_text().split()));assert values[0]==n and len(values)==n*n+1
    a=np.asarray(values[1:],dtype=np.int8).reshape(n,n)
    assert np.array_equal(a,a.T) and np.all(np.diag(a)==0)
    row=dict(n=n,A=a.tolist(),Phi=phi,root_n=n-1,root_phi=root_phi,root_A=a[:-1,:-1].tolist(),
             cpu_node_id=node_id,cpu_root_id=root_id,first_move='vertex_extension',
             extension_column=a[:-1,-1].tolist(),path_orders=[n-1,n,2*n],
             source_path=str(path),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    (args.output/f'n{n}_best32.json').write_text(json.dumps([row])+'\n')
