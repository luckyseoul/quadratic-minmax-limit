#!/usr/bin/env python3
"""One pinned signed principal embedding test; a timeout is not exclusion.

For A->B, fix the image r of source vertex0 and global sign g. Switching
then forces every d_i from the edge0i. The remaining problem is induced
embedding of signed triangle products, solved with exact bitset domains.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import random
import subprocess
import time

SOURCE_SHA='3485229d48b46cae9e64f57c74f1f6e7f5b07d7e8bf8290bc8972a5f86d7e920'
TARGET_SHA='40eb02857299421f23b2ef6d67a75fdc00e1afb65aa26fc6091ef54cb43b60ba'
VERIFIER_SHA='384cc06d03ddcb18579df9b5cff4ba356c85737a23e9cc3dffdaa28a3224539c'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    values=list(map(int,Path(path).read_text().split()));n=values[0]
    assert len(values)==1+n*n
    a=[values[1+i*n:1+(i+1)*n] for i in range(n)]
    assert all(a[i][j]==a[j][i] and (a[i][j]==0 if i==j else abs(a[i][j])==1)
               for i in range(n) for j in range(n))
    return a


def upper(a):return ''.join('1' if a[i][j]>0 else '0' for i in range(len(a)) for j in range(i+1,len(a)))


def check(a,b,p,g):
    d=[1]+[g*a[0][i]*b[p[0]][p[i]] for i in range(1,len(a))]
    assert len(set(p))==len(a)
    valid=all(b[p[i]][p[j]]==g*d[i]*a[i][j]*d[j] for i in range(len(a)) for j in range(len(a)))
    return d if valid else None


class Cutoff(Exception):pass


def embed(a,b,seconds=120,max_nodes=5000000):
    n=len(a);m=len(b);assert 2<=n<=m
    begun=time.monotonic();nodes=0;completed=[];found=None;active=None
    def visit(domains,mapping,signs,neighbors,available):
        nonlocal nodes
        nodes+=1
        if nodes>max_nodes or time.monotonic()-begun>seconds:raise Cutoff()
        if not domains:return mapping
        k=min(domains,key=lambda i:(domains[i].bit_count(),i))
        choices=domains[k]
        if not choices:return None
        union=0
        for mask in domains.values():union|=mask
        if union.bit_count()<len(domains):return None
        while choices:
            low=choices&-choices;choices^=low;v=low.bit_length()-1
            following={}
            for j,mask in domains.items():
                if j==k:continue
                allowed=neighbors[v] if signs[k][j]>0 else available^neighbors[v]
                following[j]=mask&allowed&~low
            result=visit(following,{**mapping,k:v},signs,neighbors,available)
            if result is not None:return result
        return None
    try:
        for g in (1,-1):
            signs=[[g*a[0][i]*a[i][j]*a[0][j] for j in range(1,n)] for i in range(1,n)]
            degrees=[sum(v>0 for v in row) for row in signs]
            for root in range(m):
                active=dict(global_sign=g,target_root=root);before=nodes
                available=((1<<m)-1)^(1<<root)
                neighbors=[sum(1<<u for u in range(m) if u!=root and u!=v and
                               b[root][v]*b[v][u]*b[root][u]>0) for v in range(m)]
                domains={i:sum(1<<v for v in range(m) if v!=root and
                              neighbors[v].bit_count()>=degrees[i] and
                              m-2-neighbors[v].bit_count()>=n-2-degrees[i]) for i in range(n-1)}
                answer=visit(domains,{},signs,neighbors,available)
                if answer is not None:
                    p=[root]+[answer[i] for i in range(n-1)];d=check(a,b,p,g);assert d is not None
                    found=dict(permutation=p,global_sign=g,diagonal_signs=d)
                    return dict(status='FOUND_ENTRYWISE_VERIFIED',embedding=found,nodes=nodes,
                                completed_root_sign_cases=completed,successful_case=active,
                                seconds=time.monotonic()-begun)
                completed.append(dict(**active,nodes=nodes-before));active=None
    except Cutoff:
        return dict(status='UNKNOWN_BOUNDED_SEARCH',embedding=None,nodes=nodes,
                    completed_root_sign_cases=completed,interrupted_case=active,
                    seconds=time.monotonic()-begun)
    assert len(completed)==2*m
    return dict(status='EXHAUSTIVE_NO_SIGNED_PRINCIPAL_EMBEDDING',embedding=None,nodes=nodes,
                completed_root_sign_cases=completed,seconds=time.monotonic()-begun)


def brute(a,b):
    return any(check(a,b,list(p),g) is not None for p in itertools.permutations(range(len(b)),len(a)) for g in (1,-1))


def matrix(n,code):
    a=[[0]*n for _ in range(n)];bit=0
    for i in range(n):
        for j in range(i+1,n):a[i][j]=a[j][i]=1 if (code>>bit)&1 else -1;bit+=1
    return a


def selftest():
    comparisons=0;negative_cases=0
    for ac in range(8):
        for bc in range(64):
            a=matrix(3,ac);b=matrix(4,bc);answer=embed(a,b)
            assert answer['status']!='UNKNOWN_BOUNDED_SEARCH'
            assert (answer['embedding'] is not None)==brute(a,b);comparisons+=1
    # Equal-order4 cases include genuine negative instances; order3 alone
    # would be vacuous after switching plus permitted global negation.
    for ac in range(64):
        for bc in range(64):
            a=matrix(4,ac);b=matrix(4,bc);answer=embed(a,b)
            assert answer['status']!='UNKNOWN_BOUNDED_SEARCH'
            expected=brute(a,b);assert (answer['embedding'] is not None)==expected
            negative_cases+=not expected;comparisons+=1
    rng=random.Random(20260906)
    for _ in range(24):
        a=matrix(4,rng.randrange(64));b=matrix(6,rng.randrange(1<<15));answer=embed(a,b)
        assert answer['status']!='UNKNOWN_BOUNDED_SEARCH'
        assert (answer['embedding'] is not None)==brute(a,b);comparisons+=1
    assert negative_cases>0
    return dict(status='PASS',complete_small_signed_embedding_comparisons=comparisons,
                exhaustive_negative_order4_comparisons=negative_cases)


def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True)
    p.add_argument('--target',type=Path,required=True);p.add_argument('--source-dag',type=Path,required=True)
    p.add_argument('--source-log',type=Path,required=True);p.add_argument('--verifier-source',type=Path,required=True)
    p.add_argument('--seconds',type=float,default=120);p.add_argument('--max-nodes',type=int,default=5000000)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    assert sha(args.source)==SOURCE_SHA and sha(args.target)==TARGET_SHA and sha(args.verifier_source)==VERIFIER_SHA
    a=load(args.source);b=load(args.target);assert len(a)==11 and len(b)==19
    dag=json.loads(args.source_dag.read_text());root=dag[0]['node']
    assert root['id']=='soulv2_1' and root['type']=='root' and root['n']==11 and root['phi']==17
    assert root['upper']==upper(a)
    source_line=args.source_log.read_text().splitlines()[4231];source_record=json.loads(source_line)
    assert source_record['id']==34688 and source_record['n']==11 and source_record['phi']==17
    assert source_record['family']=='block_0_flip0' and source_record['source_n']==6 and source_record['source_phi']==5
    assert source_record['upper'].replace('+','1').replace('-','0')==upper(a)
    args.output.mkdir(parents=True,exist_ok=False);verifier=args.output/'field_verify'
    subprocess.run(['g++','-O3','-std=c++17',str(args.verifier_source),'-o',str(verifier)],check=True)
    fields=[json.loads(subprocess.check_output([str(verifier),str(path)],text=True)) for path in (args.source,args.target)]
    assert fields[0]['phi']==17 and fields[1]['phi']==41 and all(r['checks']=='PASS' for r in fields)
    validation=selftest();print(json.dumps(validation),flush=True)
    result=embed(a,b,args.seconds,args.max_nodes)
    result.update(source=str(args.source),target=str(args.target),source_sha256=SOURCE_SHA,target_sha256=TARGET_SHA,
        script_sha256=sha(__file__),verifier_source_sha256=VERIFIER_SHA,verifier_binary_sha256=sha(verifier),
        source_dag_sha256=sha(args.source_dag),source_log_sha256=sha(args.source_log),source_log_line=4232,
        source_record=source_record,source_root_node=root,source_matrix=a,target_matrix=b,
        integer_field_receipts=fields,validation=validation,seconds_limit=args.seconds,node_limit=args.max_nodes,
        classification='One fixed warm11 and one fixed reverse19; signed permutation and global negation are not growth. No smaller fallback or source-bank census.')
    if result['embedding'] is not None:
        w=result['embedding'];assert check(a,b,w['permutation'],w['global_sign'])==w['diagonal_signs']
        result['remaining_target_vertices']=[i for i in range(19) if i not in w['permutation']]
    (args.output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','embedding','nodes','seconds')}),flush=True)


if __name__=='__main__':main()
