#!/usr/bin/env python3
"""Bounded, explicitly partitioned exact two-growth lookahead on grown sources.

The imported CUDA engine is pinned to the reviewed, reference-tested source.
Incoming DAGs are retained by hash and source identity; their existing move
certificates are not silently replaced by fresh claims. New moves are exactly
two principal-prefix extensions, with independent integer norm witnesses.
Sources are compared by parent norm, endpoint norm, and actual rooted path
cost. A larger parent never receives credit merely for improving a ratio.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import socket
import subprocess
import time
import numpy as np

ENGINE_SHA='219af9a224ea5e04d035a005470da0de8584ffaeb2967cb2ef12428fed14fcdf'
VERIFIER_SHA='384cc06d03ddcb18579df9b5cff4ba356c85737a23e9cc3dffdaa28a3224539c'
EXPORTER_SHA='2fadcc9430f46e7fff53211432bdb9f31330a7bef27d0cd688ffb3a65b872290'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path,value):
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(path)


def upper(a):return ''.join('1' if v>0 else '0' for v in a[np.triu_indices(len(a),1)])


def graph_nodes(value):
    nodes={}
    def visit(item):
        if isinstance(item,dict):
            if all(key in item for key in ('id','n','upper','phi')):
                identifier=item['id'];identity=tuple(item.get(key) for key in ('n','upper','phi','parent_id'))
                if identifier in nodes:
                    assert identity==tuple(nodes[identifier].get(key) for key in ('n','upper','phi','parent_id'))
                else:nodes[identifier]=item
            for child in item.values():visit(child)
        elif isinstance(item,list):
            for child in item:visit(child)
    visit(value);return nodes


def chain_to_root(nodes,identifier):
    chain=[];seen=set()
    while identifier not in (None,''):
        assert identifier not in seen and identifier in nodes,(identifier,'missing or cyclic ancestry')
        seen.add(identifier);node=nodes[identifier]
        n=int(node['n']);assert len(node['upper'])==n*(n-1)//2 and set(node['upper'])<=set('01')
        chain.append(node);identifier=node.get('parent_id')
    chain.reverse();assert chain;return chain


def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True)
    p.add_argument('--source-ids',required=True);p.add_argument('--engine',type=Path,required=True)
    p.add_argument('--verifier-source',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--target',type=int,default=44);p.add_argument('--max-sources',type=int,default=32)
    p.add_argument('--stop-on-target',action='store_true');args=p.parse_args()
    assert sha(args.engine)==ENGINE_SHA and sha(args.verifier_source)==VERIFIER_SHA
    requested=args.source_ids.split(',');assert 0<len(requested)<=args.max_sources<=32 and len(set(requested))==len(requested)
    supplied=json.loads(args.manifest.read_text());records=supplied['sources'] if isinstance(supplied,dict) else supplied
    assert isinstance(supplied,dict) and supplied['exporter_sha256']==EXPORTER_SHA
    indexed={r['id']:r for r in records};assert len(indexed)==len(records) and all(i in indexed for i in requested)
    selected=[indexed[i] for i in requested]
    assert all(r['n']==19 and r['phi'] in (39,41,43) for r in selected)
    assert all(r['backend_allocation']=='cuda' for r in selected)
    args.output.mkdir(parents=True,exist_ok=False);started=time.time()
    spec=importlib.util.spec_from_file_location('reviewed_ternary',args.engine);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);engine=module.Engine();verifier=args.output/'field_verify'
    subprocess.run(['g++','-O3','-std=c++17',str(args.verifier_source),'-o',str(verifier)],check=True)
    tests=module.selftest(engine,verifier,args.output)
    provenance=dict(driver_sha256=sha(__file__),engine_sha256=sha(args.engine),manifest_sha256=sha(args.manifest),
        verifier_source_sha256=sha(args.verifier_source),verifier_binary_sha256=sha(verifier),hostname=socket.gethostname(),
        input_manifest=str(args.manifest),reviewed_engine=str(args.engine),verifier_source=str(args.verifier_source),
        explicit_source_ids=requested,target=args.target,classification='bounded complete two-growth source-diversity test',selftests=tests)
    dump(args.output/'manifest.json',provenance)
    cached={};raw_signings=set();prepared=[]
    # Preflight every requested input before scoring: exact IDs and ancestry,
    # known source norm, actual grown source, and no duplicate raw matrices.
    for record in selected:
        matrix=(args.manifest.parent/record['matrix']).resolve();ancestry=(args.manifest.parent/record['ancestry']).resolve()
        tokens=list(map(int,matrix.read_text().split()));n=tokens[0]
        assert n==record['n'] and len(tokens)==1+n*n
        a=np.asarray(tokens[1:],dtype=np.int64).reshape(n,n);module.validate(a);encoded=upper(a)
        assert sha(matrix)==record['matrix_sha256']
        assert hashlib.sha256(a.astype(np.int8).tobytes()).hexdigest()==record['matrix_int8_sha256']
        assert sha(ancestry)==record['ancestry_sha256']
        assert encoded not in raw_signings;raw_signings.add(encoded)
        if str(ancestry) not in cached:
            value=json.loads(ancestry.read_text());nodes=graph_nodes(value);digest=sha(ancestry)
            saved=args.output/f'ancestry_{digest}.json'
            if not saved.exists():shutil.copy2(ancestry,saved)
            cached[str(ancestry)]=(nodes,digest,saved)
        nodes,digest,saved=cached[str(ancestry)];identifier=record['id'];assert identifier in nodes
        node=nodes[identifier];assert node['n']==n and node['upper']==encoded and node['phi']==record['phi']
        chain=chain_to_root(nodes,identifier);assert len(chain)>1 and chain[0]['n']<19,'primitive warm order19 root is excluded'
        assert all(node['depth']==depth for depth,node in enumerate(chain))
        move_receipt=record['ancestry_move_receipt']
        assert move_receipt['matrix_transitions_and_path_loss']=='PASS'
        assert move_receipt['source_sha256']==digest and move_receipt['records']==len(chain)
        assert sum(b['n']>a0['n'] for a0,b in zip(chain,chain[1:]))>0
        prepared.append((record,matrix,a,chain,digest,saved))
    results=[];new_nodes=[]
    for index,(record,matrix,a,chain,dag_sha,saved_dag) in enumerate(prepared):
        item=args.output/f'source_{index:02d}_{record["id"]}';item.mkdir(exist_ok=False);begun=time.time()
        source=module.verify(verifier,item/'source.txt',a);assert source['phi']==record['phi']
        result=engine.optimize(a);assert result['source_phi']==source['phi']
        raw_first=module.verify(verifier,item/'raw_first.txt',result['first'])
        alternative=result['first'].copy();alternative[:19,19]=result['c'];alternative[19,:19]=result['c']
        alt_first=module.verify(verifier,item/'alternative_first.txt',alternative)
        swap=alt_first['phi']<raw_first['phi'];first=alternative if swap else result['first'];second=result['second']
        if swap:
            order=list(range(19))+[20,19];second=second[np.ix_(order,order)]
        assert np.array_equal(first[:19,:19],a) and np.array_equal(second[:20,:20],first)
        module.write_matrix(item/'first.txt',first);first_receipt=alt_first if swap else raw_first
        endpoint=module.verify(verifier,item/'second.txt',second);assert endpoint['phi']==result['minimum']
        np.savez_compressed(item/'support_optima.npz',U_plus=result['U_plus'],U_minus=result['U_minus'])
        incoming_alphas=[node['phi']/node['n']**1.5 for node in chain]
        child_alphas=[first_receipt['phi']/20**1.5,endpoint['phi']/21**1.5]
        all_alphas=incoming_alphas+child_alphas
        incoming_positive=sum(max(0,b-a0) for a0,b in zip(incoming_alphas,incoming_alphas[1:]))
        new_positive=sum(max(0,b-a0) for a0,b in zip(all_alphas,all_alphas[1:]))
        parent_id=record['id'];added=[]
        for step,(child,receipt) in enumerate(((first,first_receipt),(second,endpoint)),1):
            node_id=f'cuda_macro_{record["id"]}_add{step}'
            node_alphas=incoming_alphas+child_alphas[:step]
            witness_is_max=receipt['max_q']>=-receipt['min_q']
            node=dict(id=node_id,parent_id=parent_id,root_id=chain[0]['id'],n=len(child),phi=receipt['phi'],upper=upper(child),
                root_n=chain[0]['n'],depth=len(chain)-1+step,alpha=node_alphas[-1],
                path_max_alpha=max(node_alphas),path_positive_loss=sum(max(0,b-a0) for a0,b in zip(node_alphas,node_alphas[1:])),
                move='add_vertex',params=''.join('1' if z>0 else '0' for z in child[-1,:-1]),
                extension_row=child[-1,:-1].tolist(),status='EXACT_INTEGER_FIELD_VERIFIED',
                witness_mask=receipt['max_witness_mask'] if witness_is_max else receipt['min_witness_mask'],
                witness_q=receipt['max_q'] if witness_is_max else receipt['min_q'],
                peaks=sum(count for q,count in receipt['histogram'] if abs(q)==receipt['phi']),
                certificate=receipt,construction_growth=True,source_DAG_sha256=dag_sha)
            added.append(node);new_nodes.append(node);parent_id=node_id
        report=dict(source_id=record['id'],root_id=chain[0]['id'],root_n=chain[0]['n'],root_phi=chain[0]['phi'],
            orders=[19,20,21],phis=[source['phi'],first_receipt['phi'],endpoint['phi']],endpoint_optimum=result['minimum'],
            target=args.target,target_reached=endpoint['phi']<=args.target,
            source_input_sha256=sha(matrix),source_DAG_sha256=dag_sha,retained_source_DAG=str(saved_dag),
            incoming_parent_chain_ids=[node['id'] for node in chain],incoming_path_max_alpha=max(incoming_alphas),
            incoming_path_positive_loss=incoming_positive,new_path_max_alpha=max(all_alphas),new_path_positive_loss=new_positive,
            rooted_max_normalized_drift=max(all_alphas)-incoming_alphas[0],
            source_matrix=a.tolist(),first_matrix=first.tolist(),second_matrix=second.tolist(),new_growth_nodes=added,
            actual_new_growth_moves=2,selection_rounds_are_growth=False,support=result['support'],
            arg_plus=result['arg_plus'],arg_minus=result['arg_minus'],swapped_new_vertex_order=swap,
            intermediate_choice_scope='better of two orders for one recovered endpoint, not globally tie-optimized',
            integer_field_verifier_records=dict(source=source,first=first_receipt,endpoint=endpoint),
            support_archive_sha256=sha(item/'support_optima.npz'),GPU_seconds=result['elapsed'],elapsed=time.time()-begun,
            classification='finite complete endpoint optimum from this exact source; no global or asymptotic norm claim')
        dump(item/'result.json',report);results.append(report)
        with (args.output/'new_growth_nodes.jsonl').open('a') as out:
            for node in added:out.write(json.dumps(node)+'\n')
        scores=[dict(source_id=r['source_id'],parent_phi=r['phis'][0],first_phi=r['phis'][1],endpoint_phi=r['phis'][2],
                     rooted_path_max=r['new_path_max_alpha'],rooted_positive_loss=r['new_path_positive_loss']) for r in results]
        summary=dict(status='running',provenance=provenance,completed_source_ids=[r['source_id'] for r in results],
            source_scores=scores,target_sources=[r['source_id'] for r in results if r['target_reached']],
            best_endpoint=min(r['phis'][2] for r in results),elapsed=time.time()-started)
        dump(args.output/'result.json',summary)
        print(json.dumps(dict(source_id=record['id'],phis=report['phis'],target_reached=report['target_reached'],
                              new_path_max_alpha=report['new_path_max_alpha'],GPU_seconds=report['GPU_seconds'])),flush=True)
        if report['target_reached'] and args.stop_on_target:break
    summary['status']='completed';dump(args.output/'result.json',summary)


if __name__=='__main__':main()
