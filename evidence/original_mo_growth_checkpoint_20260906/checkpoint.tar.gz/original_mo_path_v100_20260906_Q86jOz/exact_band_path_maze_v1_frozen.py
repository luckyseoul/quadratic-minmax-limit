#!/usr/bin/env python3
"""Exact one-move joint A/B neighborhoods, with a bounded path-search frontier.

F_A,B(x,y)=|Q_A(x)-Q_A(y)|+|x^T B y| on projective x,y.
One A-edge flip changes F by <=4; one B-entry flip changes F by <=2.
For exact P=max F, all neighbors have norm >=P-4. Pairs with old F<P-8
have new F<P-4 and cannot determine a larger maximum. Thus retaining ALL
pairs with F>=P-8 gives every one-move neighbor norm exactly. Equality
is included. The band is rebuilt after every expanded state: radii never
silently accumulate. This is finite exact local search, not global closure.
"""
import argparse
import hashlib
import heapq
import json
import os
from pathlib import Path
import socket
import sys
import time
import cupy as cp
import numpy as np


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)


def pair_key(a,b):return hashlib.sha256(a.tobytes()+b.tobytes()).hexdigest()


class BandScorer:
    def __init__(self,n):
        self.n=n;self.ii,self.jj=np.triu_indices(n,1)
        z=np.arange(1<<(n-1),dtype=np.uint32)
        self.s=np.ones((len(z),n),dtype=np.int8)
        self.s[:,1:]=1-2*((z[:,None]>>np.arange(n-1))&1).astype(np.int8)
        self.sg=cp.asarray(self.s,dtype=cp.float32)
        self.source_features=(self.sg[:,self.ii]*self.sg[:,self.jj]).T

    def neighborhood(self,a,b,p,x_batch=128,band_batch=32768):
        n=self.n;m=len(self.s);af=cp.asarray(a,dtype=cp.float32)
        q=cp.sum((self.sg@af)*self.sg,axis=1)/2
        by=cp.asarray(b,dtype=cp.float32)@self.sg.T
        band_x=[];band_y=[];band_delta=[];band_cross=[];actual=-1;outside=-1
        for start in range(0,m,x_batch):
            stop=min(m,start+x_batch)
            delta=q[start:stop,None]-q[None,:];cross=self.sg[start:stop]@by
            value=cp.abs(delta)+cp.abs(cross);actual=max(actual,int(cp.max(value)))
            outside=max(outside,int(cp.max(cp.where(value<p-8,value,-1))))
            xx,yy=cp.nonzero(value>=p-8)
            band_x.append((xx+start).astype(cp.int32));band_y.append(yy.astype(cp.int32))
            band_delta.append(delta[xx,yy].astype(cp.int16));band_cross.append(cross[xx,yy].astype(cp.int16))
        assert actual==p,(actual,p)
        xx=cp.concatenate(band_x);yy=cp.concatenate(band_y)
        dd=cp.concatenate(band_delta);zz=cp.concatenate(band_cross)
        assert len(xx)>0
        ae=cp.asarray(a[self.ii,self.jj],dtype=cp.float32)
        bf=cp.asarray(b.reshape(-1),dtype=cp.float32)
        child_a=cp.full(len(ae),-1,dtype=cp.float32)
        child_b=cp.full(n*n,-1,dtype=cp.float32)
        for start in range(0,len(xx),band_batch):
            stop=min(len(xx),start+band_batch)
            x=self.sg[xx[start:stop]];y=self.sg[yy[start:stop]]
            d=dd[start:stop].astype(cp.float32);z=zz[start:stop].astype(cp.float32)
            da=(x[:,self.ii]*x[:,self.jj]-y[:,self.ii]*y[:,self.jj]).T
            db=(x[:,:,None]*y[:,None,:]).reshape(len(x),n*n).T
            va=cp.abs(d[None,:]-2*ae[:,None]*da)+cp.abs(z)[None,:]
            vb=cp.abs(d)[None,:]+cp.abs(z[None,:]-2*bf[:,None]*db)
            child_a=cp.maximum(child_a,cp.max(va,axis=1))
            child_b=cp.maximum(child_b,cp.max(vb,axis=1))
        parent_a=cp.max(cp.abs(q[None,:]-2*ae[:,None]*self.source_features),axis=1)
        pa=int(cp.max(cp.abs(q)))
        ca=cp.asnumpy(child_a).astype(np.int32);cb=cp.asnumpy(child_b).astype(np.int32)
        ap=cp.asnumpy(parent_a).astype(np.int32)
        assert np.all((ca>=p-4)&(ca<=p+4)) and np.all((cb>=p-2)&(cb<=p+2))
        assert np.all(ca%2==p%2) and np.all(cb%2==p%2)
        if outside>=0:
            assert outside+4<int(ca.min()) and outside+2<int(cb.min())
        # The band itself is a replay artifact; full scan completeness is supplied
        # by this frozen source and original-all-pairs selftests, not a sample.
        band=dict(x=cp.asnumpy(xx),y=cp.asnumpy(yy),delta=cp.asnumpy(dd),cross=cp.asnumpy(zz))
        return dict(parent_phi=pa,A_parent_phi=ap,A_child_phi=ca,B_child_phi=cb,
                    band_size=len(xx),threshold=p-8,band=band,full_scan_maximum=actual,
                    omitted_maximum=outside,omitted_A_upper=outside+4 if outside>=0 else None,
                    omitted_B_upper=outside+2 if outside>=0 else None)


def apply_move(a,b,kind,index,ii,jj):
    aa=a.copy();bb=b.copy()
    if kind=='A':
        i,j=int(ii[index]),int(jj[index]);aa[i,j]*=-1;aa[j,i]*=-1
    else:bb.flat[index]*=-1
    return aa,bb


def selftest():
    from diagonal_wave5 import streaming_cross_phi
    rng=np.random.default_rng(2026090613);records=[]
    for n in (4,5,6):
        scorer=BandScorer(n)
        a=np.triu(rng.choice([-1,1],(n,n)),1).astype(np.int8);a+=a.T
        b=rng.choice([-1,1],(n,n)).astype(np.int8)
        p=streaming_cross_phi(a,b);result=scorer.neighborhood(a,b,p,x_batch=7,band_batch=11)
        for kind,values in (('A',result['A_child_phi']),('B',result['B_child_phi'])):
            for index,value in enumerate(values):
                aa,bb=apply_move(a,b,kind,index,scorer.ii,scorer.jj)
                assert streaming_cross_phi(aa,bb)==int(value)
                if kind=='A':
                    q=np.sum((scorer.s.astype(np.int64)@aa)*scorer.s,axis=1)//2
                    assert int(np.abs(q).max())==int(result['A_parent_phi'][index])
        records.append(dict(n=n,all_A_neighbors=len(result['A_child_phi']),
                            all_B_neighbors=len(result['B_child_phi']),band_size=result['band_size']))
    return records


def main():
    p=argparse.ArgumentParser();p.add_argument('--legacy-directory',type=Path,required=True)
    p.add_argument('--anchors',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--n',type=int,default=15);p.add_argument('--frontier',type=int,default=4096)
    p.add_argument('--seconds',type=float,default=1800);p.add_argument('--max-expanded',type=int,default=100000)
    p.add_argument('--barrier',type=int,default=2);p.add_argument('--seed',type=int,default=2026090613)
    p.add_argument('--selftest-only',action='store_true');args=p.parse_args()
    sys.path.insert(0,str(args.legacy_directory))
    from diagonal_wave5 import streaming_cross_phi
    args.output.mkdir(parents=True,exist_ok=False);started=time.time();rng=np.random.default_rng(args.seed)
    assert 2<=args.n<=16 and args.frontier>0 and args.barrier>=0
    assert args.seconds>0 and args.max_expanded>0
    cp.get_default_memory_pool().set_limit(size=10*1024**3)
    tests=selftest();scorer=BandScorer(args.n);n=args.n
    anchors=[r for r in json.loads(args.anchors.read_text()) if len(r['A'])==n];assert anchors
    manifest=dict(script_sha256=sha(__file__),legacy_sha256=sha(args.legacy_directory/'diagonal_wave5.py'),
                  anchor_sha256=sha(args.anchors),hostname=socket.gethostname(),pid=os.getpid(),
                  selftests=tests,n=n,frontier_limit=args.frontier,seed=args.seed,
                  classification='complete exact local neighborhoods in a heuristic joint path maze')
    atomic(args.output/'manifest.json',manifest)
    # Large-anchor band-size measurement is also a full exact neighborhood check.
    measured=[]
    for index,anchor in enumerate(anchors):
        a=np.asarray(anchor['A'],dtype=np.int8);b=np.asarray(anchor['B'],dtype=np.int8)
        assert np.array_equal(a,a.T) and np.all(np.diag(a)==0)
        assert np.all(np.abs(a[np.triu_indices(n,1)])==1) and np.all(np.abs(b)==1)
        result=scorer.neighborhood(a,b,anchor['phi_K'])
        assert result['parent_phi']==anchor['phi_A']
        # Independently replay each A/B family minimum on the real anchors.
        for kind,values in (('A',result['A_child_phi']),('B',result['B_child_phi'])):
            j=int(np.argmin(values));aa,bb=apply_move(a,b,kind,j,scorer.ii,scorer.jj)
            assert streaming_cross_phi(aa,bb)==int(values[j])
        np.savez_compressed(args.output/f'anchor{index}_neighborhood.npz',A=a,B=b,
            A_parent_phi=result['A_parent_phi'],A_child_phi=result['A_child_phi'],
            B_child_phi=result['B_child_phi'],**result['band'])
        measured.append(dict(anchor_id=anchor['id'],parent_phi=anchor['phi_A'],child_phi=anchor['phi_K'],
                             band_size=result['band_size'],threshold=result['threshold'],
                             omitted_maximum=result['omitted_maximum'],
                             omitted_A_upper=result['omitted_A_upper'],omitted_B_upper=result['omitted_B_upper'],
                             best_B_neighbor_phi=int(result['B_child_phi'].min()),
                             allowed_A_neighbors=int(np.count_nonzero(result['A_parent_phi']<=anchor['phi_A']))))
    atomic(args.output/'validation.json',dict(status='PASS',manifest=manifest,actual_anchors=measured,elapsed=time.time()-started))
    print(json.dumps(dict(stage='validation',anchors=measured,elapsed=time.time()-started)),flush=True)
    if args.selftest_only:return
    heap=[];seen=set();states={};serial=0;best=min(r['phi_K'] for r in anchors)

    def offer(state):
        nonlocal serial
        a=np.asarray(state['A'],dtype=np.int8);b=np.asarray(state['B'],dtype=np.int8);identifier=pair_key(a,b)
        if identifier in seen:return
        seen.add(identifier);state['id']=identifier;states[identifier]=state
        # Tie randomization spreads the exact frontier across neutral plateaus.
        priority=(state['phi_K'],state['phi_A'],float(rng.random()),serial)
        serial+=1;heapq.heappush(heap,(priority,identifier))

    for index,anchor in enumerate(anchors):
        offer(dict(anchor_index=index,A=anchor['A'],B=anchor['B'],phi_A=anchor['phi_A'],phi_K=anchor['phi_K'],
                   search_parent=None,move=None,depth=0))
    expanded=0;neighbor_evaluations=0;best_record=None;search_started=time.time();expanded_ids=set()
    while heap and expanded<args.max_expanded and time.time()-search_started<args.seconds:
        _,identifier=heapq.heappop(heap);state=states[identifier]
        if state['phi_K']>best+args.barrier:continue
        a=np.asarray(state['A'],dtype=np.int8);b=np.asarray(state['B'],dtype=np.int8)
        begun=time.time();result=scorer.neighborhood(a,b,state['phi_K'])
        assert result['parent_phi']==state['phi_A']
        expanded+=1;expanded_ids.add(identifier)
        neighbor_evaluations+=len(result['A_child_phi'])+len(result['B_child_phi'])
        # Store finite score certificates and the complete retained band per expansion.
        archive=args.output/f'expanded_{expanded:06d}.npz'
        np.savez_compressed(archive,A=a,B=b,A_parent_phi=result['A_parent_phi'],
            A_child_phi=result['A_child_phi'],B_child_phi=result['B_child_phi'],**result['band'])
        receipt=dict(state=state,archive=str(archive),archive_sha256=sha(archive),
                     threshold=result['threshold'],band_size=result['band_size'],
                     full_scan_maximum=result['full_scan_maximum'],omitted_maximum=result['omitted_maximum'],
                     omitted_A_upper=result['omitted_A_upper'],omitted_B_upper=result['omitted_B_upper'])
        with (args.output/'expanded_states.jsonl').open('a') as out:out.write(json.dumps(receipt)+'\n')
        cap=anchors[state['anchor_index']]['phi_A']
        for kind,values in (('A',result['A_child_phi']),('B',result['B_child_phi'])):
            for index,value in enumerate(values):
                child_phi=int(value);parent_phi=int(result['A_parent_phi'][index]) if kind=='A' else state['phi_A']
                if parent_phi>cap or child_phi>best+args.barrier:continue
                aa,bb=apply_move(a,b,kind,index,scorer.ii,scorer.jj)
                child=dict(anchor_index=state['anchor_index'],A=aa.tolist(),B=bb.tolist(),
                           phi_A=parent_phi,phi_K=child_phi,search_parent=identifier,
                           move=dict(kind=kind,index=index),depth=state['depth']+1)
                offer(child)
                if child_phi<best:
                    assert streaming_cross_phi(aa,bb)==child_phi
                    best=child_phi;best_record=child.copy();genes=[];cursor=child
                    while cursor['search_parent'] is not None:
                        genes.append(cursor['move']);cursor=states[cursor['search_parent']]
                    genes.reverse();ra=np.asarray(cursor['A'],dtype=np.int8);rb=np.asarray(cursor['B'],dtype=np.int8)
                    for gene in genes:ra,rb=apply_move(ra,rb,gene['kind'],gene['index'],scorer.ii,scorer.jj)
                    assert np.array_equal(ra,aa) and np.array_equal(rb,bb)
                    best_record.update(search_genes=genes,anchor=anchors[state['anchor_index']],
                        growth_orders=[n,2*n],growth_moves=1,same_order_search_moves_are_growth=False,
                        max_normalized_drift_from_good_anchor=max(0,best/(2*n)**1.5-cap/n**1.5),
                        status='EXACT_BAND_NEIGHBOR_AND_ORIGINAL_ALL_PAIRS_REPLAY')
                    atomic(args.output/f'best_phi{best}.json',best_record)
        if len(heap)>args.frontier:
            kept=heapq.nsmallest(args.frontier,heap);kept_ids={item[1] for item in kept}
            for _,dropped_id in heap:
                if dropped_id not in kept_ids and dropped_id not in expanded_ids:states.pop(dropped_id,None)
            heap=kept;heapq.heapify(heap)
        summary=dict(status='running',manifest=manifest,expanded_states=expanded,
                     exact_neighbor_evaluations=neighbor_evaluations,frontier=len(heap),seen_states=len(seen),
                     best_exact_child_phi=best,last_band_size=result['band_size'],last_parent_phi=state['phi_A'],
                     elapsed=time.time()-started,last_expansion_seconds=time.time()-begun,
                     best_record=best_record)
        atomic(args.output/'shared_path_bank.json',summary)
        if expanded%8==0 or best_record is not None:
            print(json.dumps({k:v for k,v in summary.items() if k not in ('manifest','best_record')}),flush=True)
    summary['status']='completed';atomic(args.output/'shared_path_bank.json',summary)


if __name__=='__main__':main()
