#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <mutex>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
#include <omp.h>

// One optimization over signed injections, not a sequence of radius tests.
// The caller must justify prior_lower_bound independently; the pinned wrapper
// uses the already exhaustive zero-mismatch exclusion for these exact inputs.
using Mat=std::vector<std::vector<int>>;
using Costs=std::array<std::array<unsigned char,48>,16>;
using Map=std::array<int,16>;
using Clock=std::chrono::steady_clock;
void require(bool x,const char* why){if(!x)throw std::runtime_error(why);}
Mat read(const char* path){
    std::ifstream f(path);int n;require(bool(f>>n)&&n>=2&&n<=24,"bad matrix order");
    Mat a(n,std::vector<int>(n));for(auto&row:a)for(int&x:row)require(bool(f>>x),"missing entry");
    std::string extra;require(!(f>>extra),"trailing input");
    for(int i=0;i<n;i++)for(int j=0;j<n;j++)require(a[i][j]==a[j][i]&&(i==j?a[i][j]==0:std::abs(a[i][j])==1),"invalid signing");
    return a;
}
int sign(int s){return (s&1)?-1:1;}
int count(const Mat&a,const Mat&b,const Map&p,int g){
    int cost=0;uint32_t used=0;
    for(int i=0;i<int(a.size());i++){
        require(p[i]>=0&&p[i]<2*int(b.size()),"bad signed image");
        require(!(used&(1u<<(p[i]/2))),"repeated target");used|=1u<<(p[i]/2);
        for(int j=0;j<i;j++)cost+=a[i][j]!=g*sign(p[i])*sign(p[j])*b[p[i]/2][p[j]/2];
    }return cost;
}

struct Solver{
    const Mat&a;const Mat&b;int n,m,prior,threads;double seconds_limit;uint64_t node_limit;
    // compatible[gindex][source_i][source_j][signed_image_i] is a bitset of
    // signed target images for j with distinct target and zero edge mismatch.
    uint64_t compatible[2][16][16][48]{};
    std::atomic<int> best;
    std::atomic<uint64_t> nodes{0};
    std::atomic<bool> timed_out{false},nodes_out{false};
    std::mutex winner_lock;Map winner{};int winner_g=1;
    std::vector<int> completed;
    Clock::time_point started;
    double elapsed=0;
    Solver(const Mat&aa,const Mat&bb,double secs,uint64_t cap,int workers,int lb):
        a(aa),b(bb),n(a.size()),m(b.size()),prior(lb),threads(workers),seconds_limit(secs),node_limit(cap),best(0),completed(2*m,0){
        require(n>=2&&n<=16&&n<=m&&m<=24,"solver size cap");
        require(prior>=0&&prior<=n*(n-1)/2&&workers>=1&&secs>0&&cap>0,"bad limits");
        for(int i=0;i<n;i++)winner[i]=2*i;
        best=count(a,b,winner,1);require(best>=prior,"prior lower bound exceeds initial witness");
        for(int gi=0;gi<2;gi++)for(int i=0;i<n;i++)for(int j=0;j<n;j++)if(i!=j)
            for(int s=0;s<2*m;s++)for(int t=0;t<2*m;t++)if(s/2!=t/2&&
                a[i][j]==(gi?-1:1)*sign(s)*sign(t)*b[s/2][t/2])compatible[gi][i][j][s]|=uint64_t(1)<<t;
    }
    bool stopped(){return best.load(std::memory_order_relaxed)==prior||timed_out.load()||nodes_out.load();}
    bool visit(int gi,uint32_t assigned,uint64_t available,const Costs&costs,int cost,Map&mapping){
        // false denotes interruption, never an exhaustively closed subtree.
        if(stopped())return false;
        uint64_t id=nodes.fetch_add(1,std::memory_order_relaxed)+1;
        if(id>node_limit){nodes_out=true;return false;}
        if((id&1023)==0&&std::chrono::duration<double>(Clock::now()-started).count()>seconds_limit){timed_out=true;return false;}
        int incumbent=best.load(std::memory_order_relaxed);
        if(cost>=incumbent)return true;
        if(assigned==((1u<<n)-1)){
            require(count(a,b,mapping,gi?-1:1)==cost,"incremental mismatch error");
            std::lock_guard<std::mutex> lock(winner_lock);
            if(cost<best){winner=mapping;winner_g=gi?-1:1;best=cost;}
            return true;
        }
        std::array<int,16> minimum{};std::array<uint64_t,16> min_domain{};
        std::vector<int> remaining;int sum_min=0;
        for(int i=0;i<n;i++)if(!(assigned&(1u<<i))){
            remaining.push_back(i);int v=100;uint64_t candidates=available,domain=0;
            while(candidates){int s=__builtin_ctzll(candidates);candidates&=candidates-1;
                int c=costs[i][s];if(c<v){v=c;domain=0;}if(c==v)domain|=uint64_t(1)<<s;
            }
            require(v<100,"empty signed image domain");minimum[i]=v;min_domain[i]=domain;sum_min+=v;
        }
        if(cost+sum_min>=incumbent)return true;
        // A disjoint pair lacking any compatible pair of minimum-cost images
        // needs >=1 additional unit: an extra assigned-edge cost OR a mismatch
        // on that pair's own edge. Disjoint pairs make these costs disjoint.
        uint32_t paired=0;int pair_bound=0;
        for(int i:remaining)if(!(paired&(1u<<i)))for(int j:remaining)if(j>i&&!(paired&(1u<<j))){
            bool match=false;uint64_t candidates=min_domain[i];
            while(candidates&&!match){int s=__builtin_ctzll(candidates);candidates&=candidates-1;
                match=bool(compatible[gi][i][j][s]&min_domain[j]);}
            if(!match){paired|=(1u<<i)|(1u<<j);pair_bound++;break;}
        }
        if(cost+sum_min+pair_bound>=incumbent)return true;
        // MRV with a safe per-vertex budget derived from the other minima.
        int chosen=-1,smallest=100;uint64_t choices=0;
        for(int i:remaining){
            int limit=incumbent-cost-(sum_min-minimum[i]);uint64_t domain=0,candidates=available;
            while(candidates){int s=__builtin_ctzll(candidates);candidates&=candidates-1;
                if(costs[i][s]<limit)domain|=uint64_t(1)<<s;}
            int size=__builtin_popcountll(domain);if(!size)return true;
            if(size<smallest){smallest=size;chosen=i;choices=domain;}
        }
        std::vector<std::pair<int,int>> ordered;
        while(choices){int s=__builtin_ctzll(choices);choices&=choices-1;ordered.emplace_back(costs[chosen][s],s);}
        std::sort(ordered.begin(),ordered.end());
        for(auto [increment,s]:ordered){
            if(stopped())return false;
            if(cost+increment>=best.load(std::memory_order_relaxed))continue;
            uint64_t next_available=available&~(uint64_t(3)<<(2*(s/2)));
            Costs next=costs;
            for(int j:remaining)if(j!=chosen){uint64_t candidates=next_available;
                while(candidates){int t=__builtin_ctzll(candidates);candidates&=candidates-1;
                    next[j][t]+=!(compatible[gi][chosen][j][s]&(uint64_t(1)<<t));}}
            mapping[chosen]=s;
            if(!visit(gi,assigned|(1u<<chosen),next_available,next,cost+increment,mapping))return false;
        }
        return true;
    }
    void run(){
        started=Clock::now();
        #pragma omp parallel for num_threads(threads) schedule(dynamic,1)
        for(int task=0;task<2*m;task++){
            if(stopped())continue;int gi=task/m,root=task%m;Costs costs{};Map mapping{};
            mapping.fill(-1);mapping[0]=2*root; // d_0=+1 only fixes simultaneous sign redundancy.
            uint64_t available=((uint64_t(1)<<(2*m))-1)&~(uint64_t(3)<<(2*root));
            for(int i=1;i<n;i++)for(int s=0;s<2*m;s++)
                costs[i][s]=!(compatible[gi][0][i][2*root]&(uint64_t(1)<<s));
            completed[task]=visit(gi,1,available,costs,0,mapping);
        }
        elapsed=std::chrono::duration<double>(Clock::now()-started).count();
        require(count(a,b,winner,winner_g)==best,"final mismatch witness failed");
    }
    bool complete()const{return std::all_of(completed.begin(),completed.end(),[](int x){return x==1;});}
    void report()const{
        int lo=(complete()||best==prior)?int(best):prior;
        std::cout<<std::setprecision(17)<<"{\"best_mismatches\":"<<best<<",\"lower_bound\":"<<lo
          <<",\"all_root_sign_cases_completed\":"<<(complete()?"true":"false")
          <<",\"optimal_by_prior_lower_bound\":"<<(best==prior?"true":"false")
          <<",\"nodes\":"<<nodes<<",\"seconds\":"<<elapsed<<",\"node_limit_hit\":"<<(nodes_out?"true":"false")
          <<",\"seconds_limit_hit\":"<<(timed_out?"true":"false")<<",\"global_sign\":"<<winner_g<<",\"permutation\":[";
        for(int i=0;i<n;i++){if(i)std::cout<<',';std::cout<<winner[i]/2;}
        std::cout<<"],\"diagonal_signs\":[";for(int i=0;i<n;i++){if(i)std::cout<<',';std::cout<<sign(winner[i]);}
        std::cout<<"],\"completed_root_sign_cases\":[";for(int t=0;t<2*m;t++){if(t)std::cout<<',';std::cout<<completed[t];}
        std::cout<<"],\"mismatch_edges\":[";bool first=true;
        for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)if(a[i][j]!=winner_g*sign(winner[i])*sign(winner[j])*b[winner[i]/2][winner[j]/2]){
            if(!first)std::cout<<',';first=false;std::cout<<'['<<i<<','<<j<<']';}
        std::cout<<"]}"<<std::endl;
    }
};

Mat matrix(int n,uint64_t bits){Mat a(n,std::vector<int>(n));int k=0;
    for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)a[i][j]=a[j][i]=((bits>>k++)&1)?1:-1;return a;}
int brute(const Mat&a,const Mat&b){
    int n=a.size(),m=b.size(),best=n*(n-1)/2;std::vector<int> permutation(m);
    for(int i=0;i<m;i++)permutation[i]=i;
    do{for(int g:{1,-1})for(int d=0;d<(1<<(n-1));d++){
        Map p{};for(int i=0;i<n;i++)p[i]=2*permutation[i]+(i?((d>>(i-1))&1):0);
        best=std::min(best,count(a,b,p,g));if(!best)return 0;
    }}while(std::next_permutation(permutation.begin(),permutation.end()));return best;
}
void selftest(){
    int cases=0,positive=0;
    auto compare=[&](const Mat&a,const Mat&b){
        int expected=brute(a,b);Solver solver(a,b,30,10000000,1,0);solver.run();
        require(solver.best==expected,"independent brute mismatch");
        require(solver.complete()||solver.best==0,"small search incomplete");cases++;positive+=expected>0;
    };
    for(int ac=0;ac<64;ac++)for(int bc=0;bc<64;bc++)compare(matrix(4,ac),matrix(4,bc));
    std::mt19937_64 rng(20260906);for(int k=0;k<24;k++)compare(matrix(4,rng()%64),matrix(6,rng()%(1<<15)));
    require(positive>0,"selftests need positive distance instances");
    std::cout<<"{\"status\":\"PASS\",\"complete_small_mismatch_comparisons\":"<<cases
             <<",\"positive_minimum_instances\":"<<positive<<"}"<<std::endl;
}
int main(int argc,char**argv){try{
    if(argc==2&&std::string(argv[1])=="--selftest"){selftest();return 0;}
    require(argc==8,"usage: repair source target seconds node_limit workers prior_lower_bound");
    auto a=read(argv[1]),b=read(argv[2]);Solver solver(a,b,std::stod(argv[3]),std::stoull(argv[4]),std::stoi(argv[5]),std::stoi(argv[6]));
    require(std::string(argv[7])=="--reviewed-inputs","explicit reviewed-inputs marker required");solver.run();solver.report();
}catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 1;}}
