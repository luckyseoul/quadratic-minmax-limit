#!/usr/bin/env python3
"""Independent integer validation of max-plus all-diagonal query reduction."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def diagonal_transform(lo,hi,n):
    f=np.empty(1<<n,dtype=np.int32)
    f[0::2]=lo;f[1::2]=hi[::-1]
    for bit in range(n):
        stride=1<<bit;view=f.reshape(-1,2*stride)
        left=view[:,:stride].copy();right=view[:,stride:].copy()
        view[:,:stride]=np.maximum(left,right-2)
        view[:,stride:]=np.maximum(right,left-2)
    return f+n


def main():
    p=argparse.ArgumentParser();p.add_argument('archives',type=Path,nargs='+')
    p.add_argument('--output',type=Path,required=True);args=p.parse_args();rows=[]
    for path in args.archives:
        z=np.load(path);n=len(z['A']);got=diagonal_transform(z['L'],z['M'],n)
        assert np.array_equal(got,z['phi']),path
        rows.append(dict(n=n,diagonals=len(got),minimum=int(got.min()),archive=str(path),
                         archive_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    receipt=dict(status='PASS',all_diagonals_checked=sum(r['diagonals'] for r in rows),cases=rows,
                 script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    args.output.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))


if __name__=='__main__':main()
