#!/usr/bin/env python3
"""Find previously omitted Hadamard-completion paths for the SAME best roots."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np

p=argparse.ArgumentParser();p.add_argument('--parents',type=Path,required=True)
p.add_argument('--output',type=Path,required=True);args=p.parse_args()
roots={r['root_id']:r for r in json.loads(args.parents.read_text())}
rows=[];s=np.ones((1<<15,16),dtype=np.int32)
s[:,1:]=1-2*((np.arange(1<<15)[:,None]>>np.arange(15))&1)
for root_id,record in roots.items():
    a=np.asarray(record['root_A'],dtype=np.int32)
    for mask in range(256):
        d=1-2*((mask>>np.arange(8))&1);b=a+np.diag(d)
        if not np.array_equal(b@b,8*np.eye(8,dtype=np.int32)):continue
        parent=np.block([[a,b],[b.T,-a]])
        phi=int(np.abs(np.sum((s@parent)*s,axis=1)//2).max())
        key=a.astype(np.int8).tobytes()+b.astype(np.int8).tobytes()
        rows.append(dict(n=16,A=parent.tolist(),Phi=phi,root_id=root_id,root_n=8,root_phi=10,
                         root_A=a.tolist(),first_lift_B=b.tolist(),path_orders=[8,16,32],
                         path_id=hashlib.sha256(key).hexdigest(),completion_mask=mask,
                         classification='same best root; omitted Hadamard diagonal completion'))
assert rows
args.output.mkdir(parents=True,exist_ok=True)
(args.output/'n16_best32.json').write_text(json.dumps(rows)+'\n')
print(json.dumps([dict(root_id=r['root_id'],Phi16=r['Phi'],completion_mask=r['completion_mask']) for r in rows]))
