#!/usr/bin/env python3
"""Exact three-B-entry improvement test from the retained Phi80 band.

Outside F>=72, old F<=70 can rise by at most6, hence stays<=76.
F=72 stays<=78 automatically. For F>=74, |cross|>=F-64>=10>6,
so three flips change F by -2*sum(e). At F=80/78 at most one e may
be negative; at F=76/74 not all three may be negative. These are exact
conditions for a three-entry child with norm<=78, not sampled tests.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bit_columns(negative):
    packed=np.packbits(negative,axis=0,bitorder='little')
    return [int.from_bytes(packed[:,j].tobytes(),'little') for j in range(negative.shape[1])]


def main():
    p=argparse.ArgumentParser();p.add_argument('--archive',type=Path,required=True)
    p.add_argument('--receipt',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--legacy-directory',type=Path,required=True);args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=False);start=time.time()
    receipt=json.loads(args.receipt.read_text());assert sha(args.archive)==receipt['archive_sha256']
    assert receipt['parent_phi']==32 and receipt['baseline_child_phi']==80
    z=np.load(args.archive);a=z['A'].astype(np.int64);b=z['B'].astype(np.int64);n=len(a);assert n==16
    masks=np.arange(1<<(n-1),dtype=np.uint32);s=np.ones((len(masks),n),dtype=np.int64)
    s[:,1:]=1-2*((masks[:,None]>>np.arange(n-1))&1).astype(np.int64)
    q=np.sum((s@a)*s,axis=1)//2;assert int(np.abs(q).max())==32
    x=s[z['x']];y=s[z['y']];delta=z['delta'].astype(np.int64);cross=z['cross'].astype(np.int64)
    assert np.array_equal(delta,q[z['x']]-q[z['y']])
    assert np.array_equal(cross,np.sum((x@b)*y,axis=1))
    f=np.abs(delta)+np.abs(cross)
    assert int(f.max())==80 and int(f.min())>=72 and np.all(f%2==0)
    high=f>=78;low=(f>=74)&(f<78)
    assert np.all(np.abs(cross[high|low])>6)
    def negatives(selected):
        xx=x[selected].astype(np.int8);yy=y[selected].astype(np.int8)
        return (np.sign(cross[selected])[:,None,None]*b[None,:,:]*xx[:,:,None]*yy[:,None,:]).reshape(len(xx),256)<0
    high_bits=bit_columns(negatives(high));low_bits=bit_columns(negatives(low))
    adjacency=[0]*256;edge_count=0
    for i in range(256):
        for j in range(i+1,256):
            if high_bits[i]&high_bits[j]:continue
            adjacency[i]|=1<<j;adjacency[j]|=1<<i;edge_count+=1
    print(json.dumps(dict(stage='compatibility_graph',high_pairs=int(high.sum()),low_pairs=int(low.sum()),
                          compatible_edges=edge_count,elapsed=time.time()-start)),flush=True)
    triangles=0;accepted=0;candidates=[]
    for i in range(256):
        js=adjacency[i]&~((1<<(i+1))-1)
        while js:
            bit=js&-js;js-=bit;j=bit.bit_length()-1
            ks=adjacency[i]&adjacency[j]&~((1<<(j+1))-1)
            low_intersection=low_bits[i]&low_bits[j]
            while ks:
                bit=ks&-ks;ks-=bit;k=bit.bit_length()-1;triangles+=1
                if low_intersection&low_bits[k]:continue
                accepted+=1
                if len(candidates)<16:candidates.append([i,j,k])
    replayed=[]
    if candidates:
        sys.path.insert(0,str(args.legacy_directory));from diagonal_wave5 import streaming_cross_phi
        for cells in candidates:
            bb=b.astype(np.int8).copy();bb.flat[cells]*=-1
            value=streaming_cross_phi(a.astype(np.int8),bb);assert value<=78
            replayed.append(dict(A=a.tolist(),B=bb.tolist(),phi_A=32,phi_K=value,cells=cells,
                                 vertices=[list(divmod(j,16)) for j in cells],status='EXACT_ORIGINAL_ALL_PAIRS'))
    graph=np.asarray([[(row>>j)&1 for j in range(256)] for row in adjacency],dtype=np.int8)
    np.savez_compressed(args.output/'compatibility_graph.npz',adjacency=graph)
    result=dict(status='PASS',script_sha256=sha(__file__),archive_sha256=sha(args.archive),receipt_sha256=sha(args.receipt),
                source_phi=32,original_child_phi=80,target_child_phi=78,complete_saved_band_points=len(f),
                high_F78_or80_points=int(high.sum()),low_F74_or76_points=int(low.sum()),
                omitted_old_upper=70,omitted_new_upper=76,F72_new_upper=78,
                minimum_cross_among_constrained_points=int(np.abs(cross[high|low]).min()),
                compatible_edges=edge_count,graph_triangles=triangles,accepted_triples=accepted,
                replayed=replayed,elapsed=time.time()-start,
                classification='exact fixed-A fixed-B three-entry family test; no other move-family exclusion')
    (args.output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='replayed'}),flush=True)


if __name__=='__main__':main()
