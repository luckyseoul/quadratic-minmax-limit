#!/usr/bin/env python3
"""Exact matched principal restrictions of the certified Phi80 block matrix.

Restriction gives Phi(K30)<=80; the odd edge count improves this to <=79.
The deletion is NOT a growing-path step and the Phi29 source is NOT credited
as a strict good-parent lift. Only Phi<=27 repaired sources qualify below.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np


def main():
    p=argparse.ArgumentParser();p.add_argument('--legacy-directory',type=Path,required=True)
    p.add_argument('--engine-directory',type=Path,required=True)
    p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();sys.path.insert(0,str(args.legacy_directory));sys.path.insert(0,str(args.engine_directory))
    from diagonal_wave5 import streaming_cross_phi
    from exact_band_path_maze_v2 import BandScorer,apply_move
    args.output.mkdir(parents=True,exist_ok=False);started=time.time()
    checkpoint=json.loads(args.checkpoint.read_text());assert checkpoint['phi_K']==80
    source=np.asarray(checkpoint['A'],dtype=np.int8);cross=np.asarray(checkpoint['B'],dtype=np.int8)
    assert source.shape==(16,16) and cross.shape==(16,16)
    scorer=BandScorer(15);rows=[];strict=[]
    for deleted in range(16):
        a=np.delete(np.delete(source,deleted,axis=0),deleted,axis=1)
        b=np.delete(np.delete(cross,deleted,axis=0),deleted,axis=1)
        value=streaming_cross_phi(a,b);assert value<=79 and value%2==1
        result=scorer.neighborhood(a,b,value)
        assert result['parent_phi']==29
        allowed=np.flatnonzero(result['A_parent_phi']<=27)
        candidates=[]
        for index in allowed:
            aa,bb=apply_move(a,b,'A',int(index),scorer.ii,scorer.jj)
            phi=int(result['A_child_phi'][index])
            candidate=dict(id=f'principal16delete{deleted}-Aedge{index}',A=aa.tolist(),B=bb.tolist(),
                           phi_A=int(result['A_parent_phi'][index]),phi_K=phi,
                           matched_deleted_index=deleted,repair_A_edge=[int(scorer.ii[index]),int(scorer.jj[index])])
            if phi<=81:
                assert streaming_cross_phi(aa,bb)==phi
                strict.append(candidate)
            candidates.append(dict(A_edge=int(index),parent_phi=candidate['phi_A'],child_phi=phi))
        archive=args.output/f'delete{deleted:02d}_neighborhood.npz'
        np.savez_compressed(archive,A=a,B=b,A_parent_phi=result['A_parent_phi'],
                            A_child_phi=result['A_child_phi'],B_child_phi=result['B_child_phi'],**result['band'])
        row=dict(id=f'principal16delete{deleted}',A=a.tolist(),B=b.tolist(),phi_A=29,phi_K=value,
                 deleted_index=deleted,restriction_is_growth=False,strict_source_cap=27,
                 band_size=result['band_size'],allowed_A_neighbors=candidates,
                 archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
        rows.append(row)
        print(json.dumps(dict(deleted=deleted,source_phi=29,child_phi=value,
                              strict_A_neighbors=candidates,elapsed=time.time()-started)),flush=True)
    summary=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                 checkpoint_sha256=hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
                 engine_sha256=hashlib.sha256((args.engine_directory/'exact_band_path_maze_v2.py').read_bytes()).hexdigest(),
                 records=rows,strict_good_parent_lifts=strict,elapsed=time.time()-started)
    (args.output/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
    (args.output/'transit_anchors.json').write_text(json.dumps(rows,indent=2)+'\n')
    (args.output/'strict_anchors.json').write_text(json.dumps(strict,indent=2)+'\n')


if __name__=='__main__':main()
