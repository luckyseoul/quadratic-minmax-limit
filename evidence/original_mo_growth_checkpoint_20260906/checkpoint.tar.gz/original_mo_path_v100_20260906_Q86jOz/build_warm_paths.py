#!/usr/bin/env python3
"""Create anchored 8->16->32 construction-path parents from existing scores."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np

p=argparse.ArgumentParser();p.add_argument('--corpus',type=Path,required=True)
p.add_argument('--output',type=Path,required=True);p.add_argument('--walkers',type=int,default=4096)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(2026090611);pool=[];seen=set()
for dirname in ('results','wave2_results','wave3_results'):
    result=json.loads((a.corpus/dirname/'result.json').read_text())
    for record in result['results']:
        if record['n']!=8:continue
        assert record['phi_A']==10
        z=np.load(a.corpus/dirname/Path(record['archive']).name)
        root=z['A'];bs=z['B'];phis=z['phi']
        ids=np.flatnonzero(phis<=34)
        for k in rng.permutation(ids):
            b=bs[k];key=root.tobytes()+b.tobytes()
            if key in seen:continue
            seen.add(key)
            parent=np.block([[root,b],[b.T,-root]])
            assert np.array_equal(parent,parent.T) and np.all(np.diag(parent)==0)
            pool.append(dict(n=16,A=parent.tolist(),Phi=int(phis[k]),
                             root_id=hashlib.sha256(root.tobytes()).hexdigest(),root_n=8,root_phi=10,
                             root_A=root.tolist(),first_lift_B=b.tolist(),
                             source_archive=str(a.corpus/dirname/Path(record['archive']).name),
                             source_archive_sha256=record['archive_sha256'],source_index=int(k),
                             path_id=hashlib.sha256(key).hexdigest(),path_orders=[8,16,32]))
rng.shuffle(pool);pool.sort(key=lambda r:r['Phi']);pool=pool[:a.walkers]
assert len(pool)==a.walkers,(len(pool),a.walkers)
(a.output/'n16_best32.json').write_text(json.dumps(pool)+'\n')
(a.output/'warm_path_manifest.json').write_text(json.dumps(dict(logical_walkers=len(pool),
    root_norm_fixed=10,parent_norms={str(k):sum(r['Phi']==k for r in pool) for k in (32,34)},
    classification='reused exact parent norms; new descendant diagonal families',
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')
print(json.dumps(dict(logical_walkers=len(pool),parent_norms=sorted({r['Phi'] for r in pool}))))
