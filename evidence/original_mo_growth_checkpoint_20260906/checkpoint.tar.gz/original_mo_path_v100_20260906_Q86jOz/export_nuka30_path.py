#!/usr/bin/env python3
"""Attach the independently verified CPU ancestry to the new GPU lift."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def upper(a):
    i,j=np.triu_indices(len(a),1)
    return ''.join('1' if v>0 else '0' for v in a[i,j])


def from_upper(node):
    n=node['n']; a=np.zeros((n,n),dtype=np.int8);i,j=np.triu_indices(n,1)
    assert len(node['upper'])==len(i)
    a[i,j]=np.asarray([1 if v=='1' else -1 for v in node['upper']],dtype=np.int8)
    return a+a.T


def main():
    p=argparse.ArgumentParser();p.add_argument('--ancestry',type=Path,required=True)
    p.add_argument('--results',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=False)
    history=json.loads(args.ancestry.read_text());nodes=[item['node'] for item in history]
    assert nodes[-1]['id']=='nuka_286876'
    for index,item in enumerate(history):
        assert item['node']['phi']==item['certificate']['phi']
        if index:assert item['node']['parent_id']==history[index-1]['node']['id']
    anchor=next(item for item in nodes if item['id']=='nuka_69540')
    a15=from_upper(anchor);a16=from_upper(nodes[-1])
    assert np.array_equal(a16[:15,:15],a15)
    row=json.loads(args.results.read_text())['results'][0]
    assert row['phi_A']==30 and row['phi_K']==94 and anchor['phi']==27
    assert np.array_equal(a16,np.asarray(row['A'],dtype=np.int8))
    b=np.asarray(row['B'],dtype=np.int8); child=np.block([[a16,b],[b.T,-a16]])
    child_id='v100-'+hashlib.sha256(child.tobytes()).hexdigest()
    orders=[15,16,32]; phis=[27,30,94];alphas=[v/n**1.5 for v,n in zip(phis,orders)]
    excess=[phis[i+1]-(orders[i+1]/orders[i])**1.5*phis[i] for i in range(2)]
    increments=[alphas[i+1]-alphas[i] for i in range(2)]
    path=dict(node_ids=[anchor['id'],nodes[-1]['id'],child_id],root_id=anchor['id'],
              orders=orders,phis=phis,alphas=alphas,growth_depth=2,
              growth_moves=['add_vertex_with_new_row_repair','block_lift'],
              compressed_cpu_moves=['add_vertex','edge_7_15'],
              compression_justification='The final n16 leading n15 principal submatrix equals the n15 Phi27 anchor exactly.',
              extension_column=a16[:15,15].tolist(),second_lift_B=b.tolist(),
              edge_excess=excess,edge_excess_over_parent_n=[excess[i]/orders[i] for i in range(2)],
              max_normalized_drift=max(0,max(alphas)-alphas[0]),
              worst_normalized_scaling_loss=max(0,max(increments)),
              descendant_family_size=row['diagonal_family_size'],
              profile_archive=row['archive'],profile_sha256=row['archive_sha256'],
              cpu_ancestry_sha256=hashlib.sha256(args.ancestry.read_bytes()).hexdigest(),
              classification='verified fixed-source finite path; not a global or all-order certificate')
    node=dict(id=child_id,parent_id=nodes[-1]['id'],root_id=anchor['id'],n=32,upper=upper(child),
              phi=94,status='EXACT_GPU',move='block_lift',growth_depth=2,
              path_max_alpha=max(alphas),path_positive_loss=sum(max(0,v) for v in increments))
    (args.output/'branch_path.json').write_text(json.dumps(path,indent=2)+'\n')
    (args.output/'gpu_growth_node.jsonl').write_text(json.dumps(node)+'\n')
    (args.output/'cpu_ancestry_receipt.json').write_text(json.dumps(history,indent=2)+'\n')
    print(json.dumps(dict(orders=orders,phis=phis,alphas=alphas,max_normalized_drift=path['max_normalized_drift'])))


if __name__=='__main__':main()
