#!/usr/bin/env python3
"""Join verified CPU prefix ancestry to exact GPU doubling descendants."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def upper(a):
    i,j=np.triu_indices(len(a),1)
    return ''.join('1' if v>0 else '0' for v in a[i,j])


def main():
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True)
    p.add_argument('--results',type=Path,required=True);p.add_argument('--cpu-ledger',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    wanted={'soul_58','soul_194','soul_4','soul_8'};cpu={}
    with args.cpu_ledger.open() as stream:
        for line in stream:
            row=json.loads(line)
            if row.get('id') in wanted:cpu[row['id']]=row
            if set(cpu)==wanted:break
    assert set(cpu)==wanted
    data=json.loads(args.results.read_text());paths=[];nodes=[]
    for row in data['results']:
        n=row['n'];source=json.loads((args.inputs/f'n{n}_best32.json').read_text())[0]
        parent=cpu[source['cpu_node_id']];ancestor=cpu[parent['root_id']]
        a=np.asarray(row['A'],dtype=np.int8);b=np.asarray(row['B'],dtype=np.int8)
        root=a[:-1,:-1]
        assert upper(a)==parent['upper'] and upper(root)==ancestor['upper']
        assert row['phi_A']==parent['phi'] and source['root_phi']==ancestor['phi']
        assert parent['parent_id']==ancestor['id'] and parent['move']=='add_vertex'
        child=np.block([[a,b],[b.T,-a]]);node_id='v100-'+hashlib.sha256(child.tobytes()).hexdigest()
        orders=[n-1,n,2*n];phis=[ancestor['phi'],parent['phi'],row['phi_K']]
        alphas=[phi/nn**1.5 for phi,nn in zip(phis,orders)]
        increments=[alphas[i+1]-alphas[i] for i in range(2)]
        excess=[phis[i+1]-(orders[i+1]/orders[i])**1.5*phis[i] for i in range(2)]
        nodes.append(dict(id=node_id,parent_id=parent['id'],root_id=ancestor['id'],n=2*n,upper=upper(child),
                          phi=row['phi_K'],status='EXACT_GPU',move='block_lift',growth_depth=2,
                          path_max_alpha=max(alphas),path_positive_loss=sum(max(0,v) for v in increments)))
        paths.append(dict(node_ids=[ancestor['id'],parent['id'],node_id],orders=orders,phis=phis,alphas=alphas,
                          root_id=ancestor['id'],growth_moves=['add_vertex','block_lift'],
                          extension_column=a[:-1,-1].tolist(),second_lift_B=b.tolist(),
                          edge_excess=excess,edge_excess_over_parent_n=[excess[i]/orders[i] for i in range(2)],
                          max_normalized_drift=max(0,max(alphas)-alphas[0]),
                          worst_normalized_scaling_loss=max(0,max(increments)),
                          descendant_family_size=row['diagonal_family_size'],
                          profile_archive=row['archive'],profile_sha256=row['archive_sha256'],
                          cpu_ancestry_verified=True))
    (args.output/'branch_paths.json').write_text(json.dumps(paths,indent=2)+'\n')
    (args.output/'gpu_growth_nodes.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in nodes))
    (args.output/'cpu_ancestry_receipt.json').write_text(json.dumps(cpu,indent=2)+'\n')
    print(json.dumps([dict(orders=r['orders'],phis=r['phis'],max_normalized_drift=r['max_normalized_drift']) for r in paths]))


if __name__=='__main__':main()
