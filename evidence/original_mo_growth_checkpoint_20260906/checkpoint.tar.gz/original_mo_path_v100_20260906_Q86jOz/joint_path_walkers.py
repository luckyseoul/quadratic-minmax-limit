#!/usr/bin/env python3
"""Joint parent/cross-block walkers with an exact adaptive separation oracle.

The witness-pool child score is ONLY a lower bound. Full original all-pairs
separation certifies every retained elite and adds the violating spin pair.
Every parent norm is exact and capped at its known anchor's norm. Parent
repairs are same-order mutations, not growth. The final block lift is growth.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import time
import cupy as cp
import numpy as np


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)


def key(a,b):return hashlib.sha256(a.tobytes()+b.tobytes()).hexdigest()


class Scorer:
    def __init__(self,n):
        self.n=n; self.ii,self.jj=np.triu_indices(n,1)
        z=np.arange(1<<(n-1),dtype=np.uint32)
        self.s=np.ones((len(z),n),dtype=np.int8)
        self.s[:,1:]=1-2*((z[:,None]>>np.arange(n-1))&1).astype(np.int8)
        self.sg=cp.asarray(self.s,dtype=cp.float32)
        self.edges=cp.asarray((self.s[:,self.ii]*self.s[:,self.jj]).T,dtype=cp.float32)
        self.pool=[];self.pool_keys=set();self.exact_calls=0

    def parent(self,a):
        ae=cp.asarray(a[:,self.ii,self.jj],dtype=cp.float32)
        out=[]
        for start in range(0,len(a),256):
            q=ae[start:start+256]@self.edges
            out.extend(cp.asnumpy(cp.max(cp.abs(q),axis=1)).astype(np.int32).tolist())
        return np.asarray(out,dtype=np.int32)

    def add(self,x,y):
        pair=(tuple(map(int,x)),tuple(map(int,y)))
        if pair in self.pool_keys:return False
        self.pool_keys.add(pair);self.pool.append((np.asarray(x,dtype=np.int8),np.asarray(y,dtype=np.int8)))
        return True

    def refresh(self):
        x=np.stack([p[0] for p in self.pool]);y=np.stack([p[1] for p in self.pool])
        self.delta=cp.asarray((x[:,self.ii]*x[:,self.jj]-y[:,self.ii]*y[:,self.jj]).T,dtype=cp.float32)
        self.cross=cp.asarray((x[:,:,None]*y[:,None,:]).reshape(len(x),-1).T,dtype=cp.float32)

    def lower(self,a,b):
        ae=cp.asarray(a[:,self.ii,self.jj],dtype=cp.float32)
        bf=cp.asarray(b.reshape(len(b),-1),dtype=cp.float32)
        values=cp.abs(ae@self.delta)+cp.abs(bf@self.cross)
        lower=cp.max(values,axis=1);peaks=cp.sum(values==lower[:,None],axis=1)
        fit=lower+0.1*cp.log1p(peaks)/np.log1p(len(self.pool))
        return cp.asnumpy(lower).astype(np.int32),cp.asnumpy(fit)

    def exact(self,a,b):
        q=cp.sum((self.sg@cp.asarray(a,dtype=cp.float32))*self.sg,axis=1)/2
        by=cp.asarray(b,dtype=cp.float32)@self.sg.T
        best=-1;xy=None
        for start in range(0,len(self.s),128):
            v=cp.abs(self.sg[start:start+128]@by)+cp.abs(q[start:start+128,None]-q[None,:])
            loc=int(cp.argmax(v));value=int(v.ravel()[loc])
            if value>best:
                i,j=divmod(loc,len(self.s));best=value;xy=(self.s[start+i].copy(),self.s[j].copy())
        x,y=(z.astype(np.int64) for z in xy)
        original=abs(int(x@a.astype(np.int64)@x-y@a.astype(np.int64)@y)//2)+abs(int(x@b.astype(np.int64)@y))
        assert original==best
        self.exact_calls+=1
        return best,xy


def validate(n,a):
    assert a.shape==(n,n) and np.array_equal(a,a.T) and np.all(np.diag(a)==0)
    assert np.all(np.abs(a[np.triu_indices(n,1)])==1)


def replay(anchor,genes):
    a=np.asarray(anchor['A'],dtype=np.int8).copy();b=np.asarray(anchor['B'],dtype=np.int8).copy()
    for gene in genes:
        for i,j in gene['A']:a[i,j]*=-1;a[j,i]*=-1
        for i,j in gene['B']:b[i,j]*=-1
    return a,b


def selftest(legacy):
    from diagonal_wave5 import streaming_cross_phi
    rng=np.random.default_rng(2026090612);rows=[]
    for n in (4,6,8):
        scorer=Scorer(n)
        a=np.triu(rng.choice([-1,1],(n,n)),1).astype(np.int8);a+=a.T
        b=rng.choice([-1,1],(n,n)).astype(np.int8)
        exact,xy=scorer.exact(a,b); assert exact==streaming_cross_phi(a,b)
        q=np.sum((scorer.s.astype(np.int64)@a)*scorer.s,axis=1)//2
        assert int(scorer.parent(a[None])[0])==int(np.abs(q).max())
        for _ in range(64):scorer.add(scorer.s[rng.integers(len(scorer.s))],scorer.s[rng.integers(len(scorer.s))])
        scorer.refresh();lower,_=scorer.lower(a[None],b[None]);assert lower[0]<=exact
        scorer.add(*xy);scorer.refresh();lower,_=scorer.lower(a[None],b[None]);assert lower[0]==exact
        rows.append(dict(n=n,parent_phi=int(np.abs(q).max()),child_phi=exact))
    return rows


def main():
    p=argparse.ArgumentParser();p.add_argument('--legacy-directory',type=Path,required=True)
    p.add_argument('--anchors',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--n',type=int,default=15);p.add_argument('--walkers',type=int,default=4096)
    p.add_argument('--steps',type=int,default=512);p.add_argument('--interval',type=int,default=16)
    p.add_argument('--separate',type=int,default=16);p.add_argument('--pool',type=int,default=512)
    p.add_argument('--seed',type=int,default=2026090612);p.add_argument('--selftest-only',action='store_true')
    args=p.parse_args();sys.path.insert(0,str(args.legacy_directory))
    args.output.mkdir(parents=True,exist_ok=False);started=time.time();rng=np.random.default_rng(args.seed)
    assert 2<=args.n<=16 and args.walkers>0 and args.interval>0 and args.separate>0
    cp.get_default_memory_pool().set_limit(size=10*1024**3)
    anchors=[r for r in json.loads(args.anchors.read_text()) if len(r['A'])==args.n]
    assert anchors
    tests=selftest(args.legacy_directory);scorer=Scorer(args.n);n=args.n
    for anchor in anchors:
        a=np.asarray(anchor['A'],dtype=np.int8);b=np.asarray(anchor['B'],dtype=np.int8)
        validate(n,a);assert b.shape==(n,n) and np.all(np.abs(b)==1)
        assert int(scorer.parent(a[None])[0])==anchor['phi_A']
        exact,xy=scorer.exact(a,b);assert exact==anchor['phi_K'];scorer.add(*xy)
    manifest=dict(script_sha256=sha(__file__),legacy_sha256=sha(args.legacy_directory/'diagonal_wave5.py'),
                  anchor_sha256=sha(args.anchors),hostname=socket.gethostname(),pid=os.getpid(),
                  selftests=tests,seed=args.seed,n=n,walkers=args.walkers,
                  classification='sampled joint path optimization with exact certified elites only')
    atomic(args.output/'manifest.json',manifest)
    if args.selftest_only:
        atomic(args.output/'validation.json',dict(status='PASS',manifest=manifest,elapsed=time.time()-started));return
    parent_evaluations=len(anchors)
    root=np.arange(args.walkers)%len(anchors)
    a=np.asarray([anchors[i]['A'] for i in root],dtype=np.int8)
    b=np.asarray([anchors[i]['B'] for i in root],dtype=np.int8)
    cap=np.asarray([anchors[i]['phi_A'] for i in root],dtype=np.int32)
    genes=[[] for _ in root];parent_phi=cap.copy()
    for _ in range(args.pool):scorer.add(scorer.s[rng.integers(len(scorer.s))],scorer.s[rng.integers(len(scorer.s))])
    scorer.refresh();lower,fit=scorer.lower(a,b);seen={};elites=[]
    # Known anchor lifts are eligible feedback seeds, with no invented mutation.
    for i,anchor in enumerate(anchors):
        elites.append(dict(anchor_index=i,A=anchor['A'],B=anchor['B'],phi_A=anchor['phi_A'],phi_K=anchor['phi_K'],genes=[]))
    for step in range(args.steps):
        trial_a=a.copy();trial_b=b.copy();proposals=[];a_changed=[]
        for k in range(args.walkers):
            ag=[];bg=[]
            if rng.random()<0.25:
                for edge in rng.choice(len(scorer.ii),size=1 if rng.random()<0.8 else 2,replace=False):
                    i,j=int(scorer.ii[edge]),int(scorer.jj[edge]);ag.append([i,j])
                    trial_a[k,i,j]*=-1;trial_a[k,j,i]*=-1
                a_changed.append(k)
            count=1 if rng.random()<0.8 else (2 if rng.random()<0.8 else 4)
            for cell in rng.choice(n*n,size=count,replace=False):
                i,j=divmod(int(cell),n);bg.append([i,j]);trial_b[k,i,j]*=-1
            proposals.append(dict(step=step,A=ag,B=bg))
        pp=parent_phi.copy()
        if a_changed:
            pp[a_changed]=scorer.parent(trial_a[a_changed]);parent_evaluations+=len(a_changed)
        ll,ff=scorer.lower(trial_a,trial_b)
        # Exact source caps prevent high-norm parent inflation from receiving credit.
        temperature=0.08+0.8*(1-(step%64)/64)**2
        accept=(pp<=cap)&((ff<=fit)|(rng.random(args.walkers)<np.exp(np.minimum(0,(fit-ff)/temperature))))
        a[accept]=trial_a[accept];b[accept]=trial_b[accept];parent_phi[accept]=pp[accept]
        lower[accept]=ll[accept];fit[accept]=ff[accept]
        for k in np.flatnonzero(accept):
            proposals[k]['phi_A_exact']=int(pp[k]);genes[k].append(proposals[k])
        if (step+1)%args.interval!=0 and step+1!=args.steps:continue
        selected=[]
        for k in np.argsort(fit):
            matrix_key=key(a[k],b[k])
            if matrix_key in seen:continue
            seen[matrix_key]=True;selected.append(int(k))
            if len(selected)>=args.separate:break
        for k in selected:
            exact,xy=scorer.exact(a[k],b[k]);assert exact>=int(lower[k]);scorer.add(*xy)
            replay_a,replay_b=replay(anchors[int(root[k])],genes[k])
            assert np.array_equal(replay_a,a[k]) and np.array_equal(replay_b,b[k])
            node=dict(anchor_index=int(root[k]),anchor_id=anchors[int(root[k])]['id'],
                      A=a[k].tolist(),B=b[k].tolist(),phi_A=int(parent_phi[k]),phi_K=exact,
                      lower_bound_before_separation=int(lower[k]),genes=genes[k].copy(),
                      witness=[v.tolist() for v in xy],iteration=step+1,
                      parent_mutations_are_growth=False,growth_moves=1,
                      normalized_increment=exact/(2*n)**1.5-int(parent_phi[k])/n**1.5,
                      growth_orders=[n,2*n],anchor_phi=anchors[int(root[k])]['phi_A'],
                      max_normalized_drift_from_good_anchor=max(0,exact/(2*n)**1.5-anchors[int(root[k])]['phi_A']/n**1.5),
                      edge_excess=exact-2*np.sqrt(2)*int(parent_phi[k]),
                      edge_excess_over_parent_n=(exact-2*np.sqrt(2)*int(parent_phi[k]))/n,
                      status='EXACT_ORIGINAL_ALL_PAIRS',matrix_pair_sha256=key(a[k],b[k]))
            with (args.output/'exact_elites.jsonl').open('a') as out:out.write(json.dumps(node)+'\n')
            elites.append(node)
        # Keep a genuine (parent norm, child norm) Pareto bank, not ratios alone.
        pareto=[x for x in elites if not any(y['phi_A']<=x['phi_A'] and y['phi_K']<=x['phi_K'] and
                 (y['phi_A']<x['phi_A'] or y['phi_K']<x['phi_K']) for y in elites)]
        bank=sorted(pareto,key=lambda x:(x['phi_K'],x['phi_A']))[:128]
        # Exact elites feed the living population; their complete genes travel too.
        for k in rng.choice(args.walkers,size=max(1,args.walkers//8),replace=False):
            elite=bank[int(rng.integers(len(bank)))];root[k]=elite['anchor_index']
            a[k]=np.asarray(elite['A'],dtype=np.int8);b[k]=np.asarray(elite['B'],dtype=np.int8)
            parent_phi[k]=elite['phi_A'];cap[k]=anchors[int(root[k])]['phi_A']
            genes[k]=elite['genes'].copy()
        scorer.refresh();lower,fit=scorer.lower(a,b)
        summary=dict(status='running',manifest=manifest,iteration=step+1,
                     logical_walkers=args.walkers,proposed_joint_moves=(step+1)*args.walkers,
                     exact_parent_evaluations=parent_evaluations,exact_cross_calls=scorer.exact_calls,
                     witness_pairs=len(scorer.pool),pareto_pairs=sorted({(x['phi_A'],x['phi_K']) for x in bank}),
                     best_exact_child_phi=min(x['phi_K'] for x in elites),
                     current_lower_bound_min=int(lower.min()),elite_bank=bank,elapsed=time.time()-started)
        atomic(args.output/'shared_path_bank.json',summary)
        print(json.dumps({k:v for k,v in summary.items() if k not in ('manifest','elite_bank')}),flush=True)
    summary['status']='completed';atomic(args.output/'shared_path_bank.json',summary)


if __name__=='__main__':main()
