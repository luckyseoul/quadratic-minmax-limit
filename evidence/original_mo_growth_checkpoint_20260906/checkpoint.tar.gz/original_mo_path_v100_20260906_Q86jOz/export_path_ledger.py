#!/usr/bin/env python3
"""Attach retained ancestors to exact descendant results; no norm recomputation."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import time

import numpy as np


def identity(a):
    return 'v100-'+hashlib.sha256(np.asarray(a,dtype=np.int8).tobytes()).hexdigest()


def upper(a):
    a=np.asarray(a);ii,jj=np.triu_indices(len(a),1)
    return ''.join('1' if x>0 else '0' for x in a[ii,jj])


def atomic_json(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)


def main():
    p=argparse.ArgumentParser();p.add_argument('--parents',type=Path,required=True)
    p.add_argument('--results',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    parents=json.loads(args.parents.read_text());done=0;seen_nodes=set();paths=[]
    ledger=args.output/'exact_nodes.jsonl';pathlog=args.output/'exact_paths.jsonl'
    # Fresh output directories are required; no existing genealogy is truncated.
    assert not ledger.exists() and not pathlog.exists()
    while True:
        try:
            result=json.loads(args.results.read_text())
        except (FileNotFoundError,json.JSONDecodeError):
            time.sleep(1);continue
        for row in result['results'][done:]:
            ancestor=parents[row['source_id']]
            a8=np.asarray(ancestor['root_A'],dtype=np.int8)
            a16=np.asarray(row['A'],dtype=np.int8);b16=np.asarray(row['B'],dtype=np.int8)
            b8=np.asarray(ancestor['first_lift_B'],dtype=np.int8)
            assert np.array_equal(a16,np.block([[a8,b8],[b8.T,-a8]]))
            a32=np.block([[a16,b16],[b16.T,-a16]])
            matrices=[a8,a16,a32];phis=[ancestor['root_phi'],row['phi_A'],row['phi_K']]
            assert phis[0]==10 and phis[1]==ancestor['Phi']
            orders=[8,16,32];alphas=[phi/n**1.5 for phi,n in zip(phis,orders)]
            ids=[identity(a) for a in matrices]
            increments=[alphas[i+1]-alphas[i] for i in range(2)]
            excesses=[phis[i+1]-2*math.sqrt(2)*phis[i] for i in range(2)]
            for i,(matrix,phi,n,node_id) in enumerate(zip(matrices,phis,orders,ids)):
                if node_id in seen_nodes:continue
                node=dict(id=node_id,parent_id=None if i==0 else ids[i-1],root_id=ids[0],
                          n=n,upper=upper(matrix),phi=phi,status='EXACT',move='anchor' if i==0 else 'block_lift',
                          growth_depth=i,path_max_alpha=max(alphas[:i+1]),
                          path_positive_loss=sum(max(0,x) for x in increments[:i]),
                          path_max_normalized_drift=max(0,max(alphas[:i+1])-alphas[0]))
                with ledger.open('a') as out:out.write(json.dumps(node)+'\n')
                seen_nodes.add(node_id)
            path=dict(id='path-'+ids[-1][5:],root_id=ids[0],node_ids=ids,source_id=row['source_id'],
                      orders=orders,phis=phis,alphas=alphas,edge_excess=excesses,
                      edge_excess_over_parent_n=[excesses[i]/orders[i] for i in range(2)],
                      normalized_increments=increments,worst_normalized_scaling_loss=max(0,max(increments)),
                      max_normalized_drift=max(0,max(alphas)-alphas[0]),
                      positive_loss=sum(max(0,x) for x in increments),
                      first_lift_B=b8.tolist(),second_lift_B=b16.tolist(),
                      descendant_family_size=row['diagonal_family_size'],
                      descendant_profile_archive=row['archive'],descendant_profile_sha256=row['archive_sha256'],
                      warm_path_id=ancestor['path_id'],status='EXACT_PATH_AND_DIAGONAL_FAMILY_MIN')
            with pathlog.open('a') as out:out.write(json.dumps(path)+'\n')
            paths.append(path);done+=1
        if paths:
            nondominated=[]
            for x in paths:
                if any(y['phis'][1]<=x['phis'][1] and y['phis'][2]<=x['phis'][2] and
                       (y['phis'][1]<x['phis'][1] or y['phis'][2]<x['phis'][2]) for y in paths):continue
                nondominated.append(x)
            elite=sorted(nondominated,key=lambda x:(x['max_normalized_drift'],x['worst_normalized_scaling_loss'],x['phis'][2]))[:64]
            atomic_json(args.output/'shared_elite_cache.json',dict(status=result['status'],logical_walkers=len(parents),
                        exact_paths=done,exact_nodes=len(seen_nodes),exact_new_descendant_transitions=done*65536,
                        pareto_pairs=sorted({tuple(x['phis'][1:]) for x in nondominated}),elite_paths=elite,
                        classification='anchored finite construction paths; not an all-order proof'))
        if result['status']=='completed':break
        time.sleep(10)


if __name__=='__main__':main()
