#!/usr/bin/env python3
"""One predetermined restriction of the retained Phi44 order21 champion.

Delete exactly zero-based vertices19,20. This preparation is NOT growth,
and no incoming construction ancestry is invented. The original two rows
are a constructive upper bound44 on the exact order19 two-extension test.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np

INPUT_SHA='36cfeee751e0b88fe8a453a28e43dd9e800c131b2c2f1a52e1f36e94a450f936'
CHAMPION_SHA='eab46a73e4ff54bf4fd54f647b686ae594404c5609399843c90cfa0204cb697d'
OLD_REPLAY_SHA='3c93638e87fb01cc2ef0a42ea9fdd717431068cae6ebfc9b3da8754d12ebb371'
ENGINE_SHA='219af9a224ea5e04d035a005470da0de8584ffaeb2967cb2ef12428fed14fcdf'
VERIFIER_SHA='384cc06d03ddcb18579df9b5cff4ba356c85737a23e9cc3dffdaa28a3224539c'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n')


def main():
    p=argparse.ArgumentParser();p.add_argument('--champion',type=Path,required=True)
    p.add_argument('--champion-json',type=Path,required=True);p.add_argument('--old-replay',type=Path,required=True)
    p.add_argument('--engine',type=Path,required=True);p.add_argument('--verifier',type=Path,required=True)
    p.add_argument('--verifier-manifest',type=Path,required=True);p.add_argument('--pool-manifest',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    assert sha(args.champion)==INPUT_SHA and sha(args.champion_json)==CHAMPION_SHA
    assert sha(args.old_replay)==OLD_REPLAY_SHA and sha(args.engine)==ENGINE_SHA
    verifier_provenance=json.loads(args.verifier_manifest.read_text())
    assert verifier_provenance['verifier_source_sha256']==VERIFIER_SHA
    assert sha(args.verifier)==verifier_provenance['verifier_binary_sha256']
    spec=importlib.util.spec_from_file_location('reviewed_ternary',args.engine);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);args.output.mkdir(parents=True,exist_ok=False)
    values=list(map(int,args.champion.read_text().split()));assert values[0]==21 and len(values)==442
    original=np.asarray(values[1:],dtype=np.int64).reshape(21,21);module.validate(original)
    champion=json.loads(args.champion_json.read_text());assert champion['n']==21 and champion['Phi']==44
    assert np.array_equal(np.asarray(champion['A']),original)
    old=[json.loads(line) for line in args.old_replay.read_text().splitlines() if line]
    old21=[row for row in old if row['n']==21];assert len(old21)==1 and old21[0]['phi']==44 and old21[0]['checks']=='PASS'
    original_receipt=module.verify(args.verifier,args.output/'original21.txt',original)
    for key in ('n','states','min_q','max_q','phi','min_witness_mask','max_witness_mask','sum_q','sum_q2','histogram'):
        assert original_receipt[key]==old21[0][key]
    assert original_receipt['phi']==44
    retained=list(range(19));deleted=[19,20];a=original[:19,:19].copy()
    source_receipt=module.verify(args.verifier,args.output/'restriction19.txt',a)
    assert source_receipt['phi']<=43
    b=original[:19,19].copy();c=original[:19,20].copy();d=int(original[19,20])
    restored=np.zeros_like(original);restored[:19,:19]=a
    restored[:19,19]=restored[19,:19]=b;restored[:19,20]=restored[20,:19]=c
    restored[19,20]=restored[20,19]=d;assert np.array_equal(restored,original)
    # Gauge only the last added vertex if necessary. Original source and
    # first extension remain unchanged, and norm44 is preserved by switching.
    gauge=np.ones(21,dtype=np.int64);gauge[20]=d
    gauged=gauge[:,None]*original*gauge[None,:]
    assert gauged[19,20]==1 and np.array_equal(gauged[:19,:19],a)
    assert np.array_equal(gauged[:19,19],b) and np.array_equal(gauged[:19,20],d*c)
    preparation=dict(status='VERIFIED_SINGLE_PREDETERMINED_RESTRICTION',original_input_sha256=INPUT_SHA,
        original_champion_json_sha256=CHAMPION_SHA,old_complete_field_replay_sha256=OLD_REPLAY_SHA,
        old_champion_record=champion,original_matrix=original.tolist(),original_field_receipt=original_receipt,
        retained_original_vertex_indices=retained,deleted_original_vertex_indices=deleted,
        restricted_matrix=a.tolist(),restricted_input_sha256=sha(args.output/'restriction19.txt'),
        restricted_field_receipt=source_receipt,original_extension_b=b.tolist(),original_extension_c=c.tolist(),
        original_joining_sign=d,gauged_extension_c=(d*c).tolist(),gauged_joining_sign=1,
        restriction_is_growth=False,incoming_construction_ancestry=None,known_two_extension_upper_bound=44,
        classification='positive control and reverse entrance only; no forward-path bridge has been established')
    dump(args.output/'preparation.json',preparation)
    engine=module.Engine();result=engine.optimize(a)
    assert result['source_phi']==source_receipt['phi'] and result['minimum']<=44
    first_receipt=module.verify(args.verifier,args.output/'optimized20.txt',result['first'])
    endpoint_receipt=module.verify(args.verifier,args.output/'optimized21.txt',result['second'])
    assert endpoint_receipt['phi']==result['minimum']<=44
    np.savez_compressed(args.output/'support_optima.npz',U_plus=result['U_plus'],U_minus=result['U_minus'])
    a2=a@a;d3=np.diag(a2@a);d4=np.sum(a2*a2,axis=1)
    vertices=min(sorted((int(x),int(y)) for x,y in zip(d3,d4)),
                 sorted((-int(x),int(y)) for x,y in zip(d3,d4)))
    peaks=sum(count for q,count in source_receipt['histogram'] if abs(q)==source_receipt['phi'])
    profile=dict(projective_norm_peaks=peaks,vertex_diagonal_A3_A4=vertices)
    signature=hashlib.sha256(json.dumps(profile,sort_keys=True).encode()).hexdigest()
    pool=json.loads(args.pool_manifest.read_text())
    matches=[row['id'] for row in pool['sources'] if row['profile_signature']==signature]
    report=dict(status='PASS_EXACT_REVERSE_ENTRANCE_POSITIVE_CONTROL',source_phi=source_receipt['phi'],
        exact_two_extension_optimum=result['minimum'],reconstructed_phis=[source_receipt['phi'],first_receipt['phi'],endpoint_receipt['phi']],
        support=result['support'],arg_plus=result['arg_plus'],arg_minus=result['arg_minus'],
        source_profile=profile,source_profile_signature=signature,equal_invariant_profile_forward_pool_ids=matches,
        profile_equality_is_not_matrix_equivalence=True,pool_manifest_sha256=sha(args.pool_manifest),
        first_matrix=result['first'].tolist(),endpoint_matrix=result['second'].tolist(),
        first_field_receipt=first_receipt,endpoint_field_receipt=endpoint_receipt,
        script_sha256=sha(__file__),engine_sha256=ENGINE_SHA,verifier_binary_sha256=sha(args.verifier),
        preparation_sha256=sha(args.output/'preparation.json'),support_archive_sha256=sha(args.output/'support_optima.npz'),
        GPU_seconds=result['elapsed'],restriction_is_growth=False,incoming_construction_ancestry=None,
        classification='known successful entrance recovered; no bridge from grown forward sources and no asymptotic conclusion')
    dump(args.output/'result.json',report)
    print(json.dumps({key:report[key] for key in ('status','source_phi','exact_two_extension_optimum','reconstructed_phis',
        'source_profile_signature','equal_invariant_profile_forward_pool_ids','GPU_seconds')}),flush=True)


if __name__=='__main__':main()
