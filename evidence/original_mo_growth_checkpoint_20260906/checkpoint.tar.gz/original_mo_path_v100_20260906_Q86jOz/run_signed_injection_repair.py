#!/usr/bin/env python3
"""Pinned one-optimizer old-edge repair bridge for the same actual A11/A21."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

CPP_SHA='d74fb20dfe3b0391862094dd02a7eb6977152376770b69a57c66bc398196b54f'
PRIOR_SHA='d0aabf6310e9929320a725f9e5f3e43fb18729244006f99c05592934788a11f4'
SOURCE_SHA='3485229d48b46cae9e64f57c74f1f6e7f5b07d7e8bf8290bc8972a5f86d7e920'
TARGET_SHA='36cfeee751e0b88fe8a453a28e43dd9e800c131b2c2f1a52e1f36e94a450f936'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    x=list(map(int,Path(path).read_text().split()));n=x[0];assert len(x)==1+n*n
    a=[x[1+i*n:1+(i+1)*n] for i in range(n)]
    assert all(a[i][j]==a[j][i] and (a[i][j]==0 if i==j else abs(a[i][j])==1)
               for i in range(n) for j in range(n))
    return a


def main():
    p=argparse.ArgumentParser();p.add_argument('--cpp',type=Path,required=True)
    p.add_argument('--prior',type=Path,required=True);p.add_argument('--source',type=Path,required=True)
    p.add_argument('--target',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seconds',type=float,default=120);p.add_argument('--max-nodes',type=int,default=100000000)
    p.add_argument('--workers',type=int,default=8);args=p.parse_args()
    assert 1<=args.workers<=8 and 0<args.seconds<=120 and 0<args.max_nodes<=100000000
    for path,digest in ((args.cpp,CPP_SHA),(args.prior,PRIOR_SHA),(args.source,SOURCE_SHA),(args.target,TARGET_SHA)):
        assert sha(path)==digest
    prior=json.loads(args.prior.read_text());a=load(args.source);b=load(args.target)
    assert len(a)==11 and len(b)==21 and a==prior['source_matrix'] and b==prior['target_matrix']
    assert prior['source_sha256']==SOURCE_SHA and prior['target_sha256']==TARGET_SHA
    assert prior['status']=='EXHAUSTIVE_NO_SIGNED_PRINCIPAL_EMBEDDING'
    assert len(prior['completed_root_sign_cases'])==42 and prior['embedding'] is None
    assert prior['source_field_receipt']['phi']==17 and prior['target_field_receipt']['phi']==44
    args.output.mkdir(parents=True,exist_ok=False);binary=args.output/'signed_injection_repair'
    subprocess.run(['g++','-O3','-std=c++17','-fopenmp',str(args.cpp),'-o',str(binary)],check=True)
    validation=json.loads(subprocess.check_output([str(binary),'--selftest'],text=True))
    assert validation['status']=='PASS' and validation['complete_small_mismatch_comparisons']==4120
    assert validation['positive_minimum_instances']>0
    print(json.dumps(validation),flush=True)
    result=json.loads(subprocess.check_output([str(binary),str(args.source),str(args.target),str(args.seconds),
        str(args.max_nodes),str(args.workers),'1','--reviewed-inputs'],text=True))
    permutation=result['permutation'];d=result['diagonal_signs'];g=result['global_sign']
    assert len(permutation)==11 and len(set(permutation))==11 and all(0<=i<21 for i in permutation)
    assert len(d)==11 and d[0]==1 and all(v in (-1,1) for v in d) and g in (-1,1)
    repaired=[[g*d[i]*d[j]*b[permutation[i]][permutation[j]] for j in range(11)] for i in range(11)]
    flips=[[i,j] for i in range(11) for j in range(i+1,11) if a[i][j]!=repaired[i][j]]
    assert flips==result['mismatch_edges'] and len(flips)==result['best_mismatches']>=1
    completed=result['completed_root_sign_cases'];assert len(completed)==42 and all(v in (0,1) for v in completed)
    assert result['all_root_sign_cases_completed']==all(completed)
    assert result['optimal_by_prior_lower_bound']==(len(flips)==1)
    optimal=result['all_root_sign_cases_completed'] or result['optimal_by_prior_lower_bound']
    assert result['lower_bound']==(len(flips) if optimal else 1)
    order=permutation+[i for i in range(21) if i not in permutation];extended_d=d+[1]*10
    aligned=[[g*extended_d[i]*extended_d[j]*b[order[i]][order[j]] for j in range(21)] for i in range(21)]
    assert [row[:11] for row in aligned[:11]]==repaired
    result.update(status='EXACT_MINIMUM_OLD_EDGE_REPAIRS' if optimal else 'BOUNDED_REPAIR_UPPER_BOUND',
        script_sha256=sha(__file__),cpp_sha256=CPP_SHA,binary_sha256=sha(binary),prior_receipt_sha256=PRIOR_SHA,
        source_sha256=SOURCE_SHA,target_sha256=TARGET_SHA,source_matrix=a,target_matrix=b,
        repaired_source_matrix=repaired,aligned_target_order=order,aligned_target_diagonal_signs=extended_d,
        aligned_full_target_matrix=aligned,reused_source_field_receipt=prior['source_field_receipt'],
        reused_target_field_receipt=prior['target_field_receipt'],source_root_node=prior['source_root_node'],
        validation=validation,workers=args.workers,seconds_limit=args.seconds,node_limit=args.max_nodes,
        classification='One signed-injection mismatch optimization on the same two actual matrices. The witness changes only listed old-source edges; signs/permutations/global negation align coordinates, not growth. No path objective, delayed-flip schedule, other target, or smaller-root fallback is claimed.')
    (args.output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','best_mismatches','lower_bound','nodes','seconds','mismatch_edges')}),flush=True)


if __name__=='__main__':main()
