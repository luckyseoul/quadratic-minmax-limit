#!/usr/bin/env python3
"""Retain the certified row union without changing either source receipt."""
import argparse
import hashlib
import json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--inputs',nargs='+',type=Path,required=True)
p.add_argument('--output',type=Path,required=True);args=p.parse_args()
assert not args.output.exists();rows=[];seen=set();sources={}
for path in args.inputs:
    sources[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    for row in json.loads(path.read_text())['results']:
        assert row['source_id'] not in seen
        seen.add(row['source_id']);rows.append(row)
rows.sort(key=lambda row:row['source_id'])
args.output.write_text(json.dumps(dict(status='retained_completed_prefix',results=rows,
    source_sha256=sources,completed_parents=len(rows),exact_transitions=sum(row['diagonal_family_size'] for row in rows)),indent=2)+'\n')
print(json.dumps(dict(parents=len(rows),last_source_id=max(seen),output=str(args.output))))
