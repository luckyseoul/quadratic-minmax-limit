#!/usr/bin/env python3
"""Finish the same warm-source gate against its retained order21 target.

Reuse the reviewed search without rerunning prior selftests or field norms.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

ENGINE_SHA='dab94a26d65c83d084c120aacca7658a8de2f879688d57ec1365ed2fbef93122'
PRIOR_SHA='f15de2eeb1e81eb2bc533641d12162bf7174b029306dbc9fba51a321c38d4f14'
SOURCE_SHA='3485229d48b46cae9e64f57c74f1f6e7f5b07d7e8bf8290bc8972a5f86d7e920'
TARGET_SHA='36cfeee751e0b88fe8a453a28e43dd9e800c131b2c2f1a52e1f36e94a450f936'
PREPARATION_SHA='7daf11e526a41d74dd6f523c92b1b67044c25d0eba89a25cf03327e35dd6d497'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--engine',type=Path,required=True)
    p.add_argument('--prior',type=Path,required=True);p.add_argument('--source',type=Path,required=True)
    p.add_argument('--target',type=Path,required=True);p.add_argument('--preparation',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--seconds',type=float,default=120)
    p.add_argument('--max-nodes',type=int,default=5000000);args=p.parse_args()
    for path,digest in ((args.engine,ENGINE_SHA),(args.prior,PRIOR_SHA),(args.source,SOURCE_SHA),
                        (args.target,TARGET_SHA),(args.preparation,PREPARATION_SHA)):
        assert sha(path)==digest
    spec=importlib.util.spec_from_file_location('reviewed_embedding',args.engine)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    prior=json.loads(args.prior.read_text());preparation=json.loads(args.preparation.read_text())
    assert prior['script_sha256']==ENGINE_SHA and prior['validation']['status']=='PASS'
    assert prior['validation']['complete_small_signed_embedding_comparisons']==4632
    assert prior['validation']['exhaustive_negative_order4_comparisons']==1536
    a=module.load(args.source);b=module.load(args.target)
    assert len(a)==11 and len(b)==21 and a==prior['source_matrix'] and b==preparation['original_matrix']
    assert prior['source_sha256']==SOURCE_SHA and preparation['original_input_sha256']==TARGET_SHA
    source_field=prior['integer_field_receipts'][0];target_field=preparation['original_field_receipt']
    assert source_field['n']==11 and source_field['phi']==17 and source_field['checks']=='PASS'
    assert target_field['n']==21 and target_field['phi']==44 and target_field['checks']=='PASS'
    args.output.mkdir(parents=True,exist_ok=False)
    result=module.embed(a,b,args.seconds,args.max_nodes)
    result.update(script_sha256=sha(__file__),engine_sha256=ENGINE_SHA,prior_receipt_sha256=PRIOR_SHA,
        preparation_sha256=PREPARATION_SHA,source_sha256=SOURCE_SHA,target_sha256=TARGET_SHA,
        source_matrix=a,target_matrix=b,source_field_receipt=source_field,target_field_receipt=target_field,
        reused_validation=prior['validation'],source_root_node=prior['source_root_node'],
        seconds_limit=args.seconds,node_limit=args.max_nodes,
        classification='One actual warm11 source against the actual retained Phi44 order21 target. An exhaustive negative excludes pure vertex-addition paths to this target up to switching, permutation, and global negation; not all order21 matrices. No old-edge edits or smaller-root fallback.')
    if result['embedding'] is not None:
        w=result['embedding'];assert module.check(a,b,w['permutation'],w['global_sign'])==w['diagonal_signs']
        result['remaining_target_vertices']=[i for i in range(21) if i not in w['permutation']]
        assert len(result['remaining_target_vertices'])==10
    (args.output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','embedding','nodes','seconds')}),flush=True)


if __name__=='__main__':main()
