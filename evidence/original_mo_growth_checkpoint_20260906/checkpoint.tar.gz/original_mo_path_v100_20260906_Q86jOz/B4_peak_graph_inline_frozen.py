#!/usr/bin/env python3
"""Readable transcription of the executed 2026-09-06 07:36 UTC inline probe.

This file was frozen after execution; its file hash is not a pre-run hash.
The executed inline code used these same operations and absolute input/output
paths. It reused the previously verified complete Phi80 band without rescoring.
Any four B-entry flips attaining <=78 must have at most one negative e on
every old F80 peak; hence every selected entry pair must be an edge below.
An edgeless graph therefore rules out all four-entry improvements.
"""
import sys
import json
import hashlib
import pathlib
import numpy as np

sys.path.insert(0, "/tmp/original_mo_path_v100_20260906_RKXdi9")
from exact_three_B_filter import bit_columns

path = pathlib.Path("/tmp/original_mo_path_v100_20260906_RKXdi9/hadamard32_joint_neighborhood.npz")
z = np.load(path)
n = 16
ids = np.arange(1 << 15, dtype=np.uint32)
s = np.ones((len(ids), n), dtype=np.int8)
s[:, 1:] = 1 - 2 * ((ids[:, None] >> np.arange(15)) & 1).astype(np.int8)
f = np.abs(z["delta"].astype(np.int32)) + np.abs(z["cross"].astype(np.int32))
peak = f == 80
x = s[z["x"][peak]]
y = s[z["y"][peak]]
cross = z["cross"][peak]
assert np.all(np.abs(cross) >= 8)
negative = (
    np.sign(cross).astype(np.int8)[:, None, None] * z["B"][None]
    * x[:, :, None] * y[:, None, :]
).reshape(len(x), 256) < 0
bits = bit_columns(negative)
edges = [(i, j) for i in range(256) for j in range(i + 1, 256) if bits[i] & bits[j] == 0]
r = dict(
    source_phi=32,
    baseline_child_phi=80,
    target_child_phi=78,
    complete_old_peak_count=int(peak.sum()),
    minimum_peak_cross=int(np.abs(cross).min()),
    compatible_edges=len(edges),
    classification="EXACT_NO_B4_IMPROVEMENT_BY_PEAK_PAIR_OBSTRUCTION" if not edges else "OPEN_FOUR_CLIQUE_FILTER",
    archive_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
)
output = pathlib.Path("/tmp/original_mo_path_v100_20260906_RKXdi9/hadamard_B3_filter_results/B4_peak_graph.json")
assert not output.exists()
output.write_text(json.dumps(r, indent=2))
print(json.dumps(r))
