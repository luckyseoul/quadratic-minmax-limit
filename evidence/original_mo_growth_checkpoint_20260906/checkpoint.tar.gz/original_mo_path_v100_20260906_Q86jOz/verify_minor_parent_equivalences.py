#!/usr/bin/env python3
"""Find explicit signed-permutation/global-negation witnesses, not a census."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def graph_isomorphism(a,b):
    n=len(a);ca=np.sum(a,axis=1).tolist();cb=np.sum(b,axis=1).tolist()
    for _ in range(n):
        sa=[(ca[i],tuple(sorted(ca[j] for j in range(n) if a[i,j]))) for i in range(n)]
        sb=[(cb[i],tuple(sorted(cb[j] for j in range(n) if b[i,j]))) for i in range(n)]
        labels={v:i for i,v in enumerate(sorted(set(sa+sb)))}
        na=[labels[v] for v in sa];nb=[labels[v] for v in sb]
        if sorted(na)!=sorted(nb):return None
        if na==ca and nb==cb:break
        ca,cb=na,nb
    mapping={};used=set();calls=0
    def visit():
        nonlocal calls
        calls+=1
        if calls>100000:return None
        if len(mapping)==n:return [mapping[i] for i in range(n)]
        options=[]
        for i in range(n):
            if i in mapping:continue
            candidates=[j for j in range(n) if j not in used and ca[i]==cb[j] and
                        all(a[i,k]==b[j,l] for k,l in mapping.items())]
            if not candidates:return None
            options.append((len(candidates),i,candidates))
        _,i,candidates=min(options)
        for j in candidates:
            mapping[i]=j;used.add(j);answer=visit()
            if answer is not None:return answer
            del mapping[i];used.remove(j)
        return None
    return visit()


def witness(reference,target):
    n=len(reference)
    for global_sign in (1,-1):
        a=global_sign*reference;da=np.r_[1,a[0,1:]].astype(np.int8)
        normalized=da[:,None]*a*da[None,:];ga=normalized[1:,1:]>0
        for root in range(n):
            order=[root]+[i for i in range(n) if i!=root]
            b=target[np.ix_(order,order)];db=np.r_[1,b[0,1:]].astype(np.int8)
            gb=(db[:,None]*b*db[None,:])[1:,1:]>0
            match=graph_isomorphism(ga,gb)
            if match is None:continue
            normalized_permutation=[0]+[j+1 for j in match]
            permutation=np.asarray(order)[normalized_permutation]
            d=da*db[normalized_permutation]
            assert np.array_equal(target[np.ix_(permutation,permutation)],global_sign*d[:,None]*reference*d[None,:])
            return dict(global_sign=global_sign,permutation=permutation.tolist(),diagonal_signs=d.tolist())
    return None


def main():
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True)
    p.add_argument('--source-result',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();assert not args.output.exists()
    rows=json.loads(args.input.read_text());a=np.asarray(rows[0]['A'],dtype=np.int8)
    measured=json.loads(args.source_result.read_text())['records'][0]
    assert measured['source_id']==0 and measured['exact_unordered_two_edge_repairs']==5460
    assert hashlib.sha256(Path(measured['archive']).read_bytes()).hexdigest()==measured['archive_sha256']
    archive=np.load(measured['archive']);assert np.array_equal(a,archive['A'])
    assert int(archive['parent_phi'].min())==29
    answers=[]
    for index,row in enumerate(rows):
        w=witness(a,np.asarray(row['A'],dtype=np.int8));assert w is not None,index
        answers.append(dict(index=index,id=row['id'],witness=w,
                            conclusion='every unordered two-edge parent repair has Phi at least29'))
    result=dict(status='PASS',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                source_result_sha256=hashlib.sha256(args.source_result.read_bytes()).hexdigest(),
                input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),witnesses=answers,
                classification='explicit source-matrix norm symmetries; no coupled-B equivalence or new growth claimed')
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status='PASS',parents=len(answers),negation_counts={str(sign):sum(r['witness']['global_sign']==sign for r in answers) for sign in (1,-1)})))


if __name__=='__main__':main()
