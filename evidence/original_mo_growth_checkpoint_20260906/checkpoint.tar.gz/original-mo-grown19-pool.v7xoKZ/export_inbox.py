#!/usr/bin/env python3
"""Export a verified CPU ancestry JSON into the v2 immutable inbox format."""
import hashlib
import json
import math
import pathlib
import re
import sys

source = pathlib.Path(sys.argv[1])
destination = pathlib.Path(sys.argv[2])
raw = source.read_bytes()
selection = sys.argv[3] if len(sys.argv) > 3 else ''
if selection:
    by_id = {}
    for line in raw.decode().splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert row['id'] not in by_id
        by_id[row['id']] = row
    records = []
    rid = selection
    while rid:
        row = by_id[rid]
        records.append(row)
        rid = row['parent_id']
    records.reverse()
else:
    data = json.loads(raw)
    records = [entry['node'] for entry in data]
assert records
safe = re.compile(r'^[A-Za-z0-9_.:/,-]+$')
source_hash = hashlib.sha256(raw).hexdigest()
tag = hashlib.sha256(raw + selection.encode()).hexdigest()
lines = [f'PATH_IMPORT_V1 {tag} {len(records)}']
seen = set()
verified = {}
for row in records:
    n = row['n']
    assert 11 <= n <= 26
    values = [row['id'], row['parent_id'] or '-', row['root_id'],
              str(row['root_n']), str(row['depth']),
              repr(row['path_max_alpha']), repr(row['path_positive_loss']),
              str(n), str(row['phi']), row['move'], row['params'] or '-']
    assert all(safe.fullmatch(v) for v in values)
    assert row['id'] not in seen
    assert not row['parent_id'] or row['parent_id'] in seen
    matrix = [[0] * n for _ in range(n)]
    pairs = [(i,j) for i in range(n) for j in range(i+1,n)]
    assert len(pairs) == len(row['upper'])
    for (i,j), bit in zip(pairs, row['upper']):
        assert bit in '01'
        matrix[i][j] = matrix[j][i] = 1 if bit == '1' else -1
    parent_id = row['parent_id']
    value = row['phi'] / n ** 1.5
    if parent_id:
        parent, old = verified[parent_id]
        m, move, params = parent['n'], row['move'], row['params']
        assert row['root_id'] == parent['root_id'] and row['root_n'] == parent['root_n']
        assert row['depth'] == parent['depth'] + 1
        assert math.isclose(row['path_max_alpha'], max(parent['path_max_alpha'], value), abs_tol=1e-13)
        assert math.isclose(row['path_positive_loss'], parent['path_positive_loss'] + max(
            0, value - parent['phi'] / m ** 1.5), abs_tol=1e-13)
        if move in ('add_vertex', 'maxplus_add_vertex'):
            assert n == m + 1 and len(params) == m
            assert [r[:m] for r in matrix[:m]] == old
            assert all(matrix[i][m] == (1 if params[i] == '1' else -1) for i in range(m))
        elif move == 'delete_vertex':
            drop = int(params)
            assert n == m - 1 and 0 <= drop < m
            assert matrix == [[old[i][j] for j in range(m) if j != drop]
                              for i in range(m) if i != drop]
        elif move == 'doubling_lift':
            assert n == 2*m and [r[:m] for r in matrix[:m]] == old
            assert [r[m:] for r in matrix[m:]] == [[-v for v in r] for r in old]
        else:
            assert n == m
            indices = list(map(int, params.split(',')))
            expected = [r[:] for r in old]
            if move in ('active_edge', 'edge_flip'):
                assert len(indices) == 2
                i,j = indices
                expected[i][j] = expected[j][i] = -expected[i][j]
            else:
                assert move in ('triangle_flip', 'clique4_flip')
                assert len(indices) == (3 if move == 'triangle_flip' else 4)
                assert len(set(indices)) == len(indices)
                for ii,i in enumerate(indices):
                    for j in indices[ii+1:]:
                        expected[i][j] = expected[j][i] = -expected[i][j]
            assert matrix == expected
    else:
        assert row['root_id'] == row['id'] and row['root_n'] == n and row['depth'] == 0
        assert math.isclose(row['path_max_alpha'], value, abs_tol=1e-13)
        assert row['path_positive_loss'] == 0
    seen.add(row['id'])
    verified[row['id']] = (row, matrix)
    lines.append(' '.join(values))
    lines.extend(' '.join(map(str, r)) for r in matrix)
destination.mkdir(parents=True, exist_ok=True)
target = destination / (tag[:16] + '.nodes')
contents = '\n'.join(lines) + '\n'
if target.exists():
    assert target.read_text() == contents
else:
    pending = target.with_suffix('.pending')
    pending.write_text(contents)
    pending.replace(target)
print(json.dumps({'source': str(source), 'source_sha256': source_hash,
                  'selection': selection, 'import_tag': tag,
                  'matrix_transitions_and_path_loss': 'PASS',
                  'records': len(records), 'output': str(target),
                  'output_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
