#!/usr/bin/env python3
"""Select a bounded profile-diverse grown A19 pool from completed journals.

No source is generated here. Signed hashes and fixed-order switching/global
negation canonicalization remove duplicates; this is not an isomorphism census.
Each selected source is independently norm-checked and its full actual path is
checked by the existing matrix-move/root/depth/loss exporter.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unpack(row):
    n = row['n']
    assert len(row['upper']) == n*(n-1)//2 and set(row['upper']) <= {'0', '1'}
    a = [[0]*n for _ in range(n)]
    k = 0
    for i in range(n):
        for j in range(i+1, n):
            a[i][j] = a[j][i] = 1 if row['upper'][k] == '1' else -1
            k += 1
    return a


def read_matrix(path):
    values = list(map(int, path.read_text().split()))
    n = values[0]
    assert n == 19 and len(values) == 1+n*n
    a = [values[1+i*n:1+(i+1)*n] for i in range(n)]
    assert all(a[i][j] == a[j][i] and (a[i][j] == 0 if i == j else abs(a[i][j]) == 1)
               for i in range(n) for j in range(n))
    return a


def canonical(a):
    n = len(a)
    s = ''.join('1' if a[i][j]*a[0][i]*a[0][j] > 0 else '0'
                for i in range(1, n) for j in range(i+1, n))
    return min(s, ''.join('0' if z == '1' else '1' for z in s))


def rank(row):
    return (row['path_max_alpha'], row['path_positive_loss'], row['depth'], row['id'])


def profile(row):
    a = unpack(row)
    n = len(a)
    a2 = [[sum(a[i][k]*a[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
    d3 = [sum(a[i][j]*a2[j][i] for j in range(n)) for i in range(n)]
    d4 = [sum(a2[i][j]**2 for j in range(n)) for i in range(n)]
    vertices = min(sorted(zip(d3, d4)), sorted(zip((-v for v in d3), d4)))
    value = dict(projective_norm_peaks=row['peaks'], vertex_diagonal_A3_A4=vertices)
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest(), value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--journals', nargs='+', type=Path, required=True)
    parser.add_argument('--exclude', nargs='+', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--verifier', type=Path, required=True)
    parser.add_argument('--verifier-source', type=Path, required=True)
    parser.add_argument('--exporter', type=Path, required=True)
    args = parser.parse_args()
    assert not args.out.exists()
    assert sha(args.verifier_source) == '384cc06d03ddcb18579df9b5cff4ba356c85737a23e9cc3dffdaa28a3224539c'
    assert sha(args.exporter) == '2fadcc9430f46e7fff53211432bdb9f31330a7bef27d0cd688ffb3a65b872290'
    excluded = {canonical(read_matrix(path)) for path in args.exclude}
    pools = defaultdict(dict)
    offsets = []
    journal_records = []
    eligible = Counter()
    for source_index, path in enumerate(args.journals):
        lookup = {}
        digest = hashlib.sha256()
        count = 0
        with path.open('rb') as source:
            while True:
                offset = source.tell()
                raw = source.readline()
                if not raw:
                    break
                digest.update(raw)
                row = json.loads(raw)
                rid = row['id']
                assert rid not in lookup
                lookup[rid] = (offset, row['parent_id'])
                count += 1
                if row['n'] != 19 or row['phi'] not in (39, 41, 43) or row['root_n'] > 18 or row['depth'] < 1:
                    continue
                assert row['status'] == 'EXACT_CPU' and row['parent_id']
                eligible[row['phi']] += 1
                signature = canonical(unpack(row))
                if signature in excluded:
                    continue
                # Keep a deterministic hash sample in each norm/root-order stratum.
                # Repeated occurrences retain the best actual path to that signing.
                bucket = pools[(row['phi'], row['root_n'])]
                sample_key = hashlib.sha256(signature.encode()).hexdigest()
                candidate = dict(row=row, source_index=source_index, signature=signature, sample_key=sample_key)
                if signature not in bucket or rank(row) < rank(bucket[signature]['row']):
                    bucket[signature] = candidate
                if len(bucket) > 24:
                    del bucket[max(bucket, key=lambda key: bucket[key]['sample_key'])]
        offsets.append(lookup)
        journal_records.append(dict(path=str(path), sha256=digest.hexdigest(), records=count))
        print(json.dumps(dict(stage='journal_indexed', source=str(path), records=count,
                              eligible=dict(eligible), retained=sum(map(len, pools.values())))), flush=True)
    candidates = {}
    for bucket in pools.values():
        for signature, item in bucket.items():
            if signature not in candidates or rank(item['row']) < rank(candidates[signature]['row']):
                candidates[signature] = item
    for item in candidates.values():
        item['profile_signature'], item['profile'] = profile(item['row'])
    selected = []
    for phi, requested in ((39, 12), (41, 12), (43, 8)):
        available = [item for item in candidates.values() if item['row']['phi'] == phi]
        profile_use = Counter()
        root_use = Counter()
        for index in range(min(requested, len(available))):
            item = min(available, key=lambda item: (profile_use[item['profile_signature']],
                       root_use[item['row']['root_n']], rank(item['row'])))
            available.remove(item)
            profile_use[item['profile_signature']] += 1
            root_use[item['row']['root_n']] += 1
            item['backend_allocation'] = 'opencl' if index % 4 == 3 else 'cuda'
            selected.append(item)
    assert 16 <= len(selected) <= 32
    assert len({item['signature'] for item in selected}) == len(selected)
    args.out.mkdir()
    sources = []
    for item in selected:
        row = item['row']
        rid = row['id']
        a = unpack(row)
        matrix_path = args.out/(rid+'.txt')
        matrix_path.write_text('19\n'+'\n'.join(' '.join(map(str, line)) for line in a)+'\n')
        run = subprocess.run([str(args.verifier), str(matrix_path)], text=True, capture_output=True, check=True)
        certificate = json.loads(run.stdout)
        assert certificate['n'] == 19 and certificate['phi'] == row['phi'] and certificate['checks'] == 'PASS'
        independent_peaks = sum(count for value, count in certificate['histogram'] if abs(value) == row['phi'])
        assert independent_peaks == row['peaks']
        source_index = item['source_index']
        lookup = offsets[source_index]
        chain = []
        seen = set()
        with args.journals[source_index].open('rb') as source:
            current = rid
            while current:
                assert current not in seen
                seen.add(current)
                offset, parent = lookup[current]
                source.seek(offset)
                record = json.loads(source.readline())
                assert record['id'] == current and record['parent_id'] == parent
                chain.append(dict(node=record))
                current = parent
        chain.reverse()
        assert len(chain) == row['depth']+1 and chain[0]['node']['n'] == row['root_n'] <= 18
        assert chain[-1]['node'] == row
        chain[-1]['certificate'] = certificate
        ancestry_path = args.out/(rid+'.ancestry.json')
        ancestry_path.write_text(json.dumps(chain, indent=2)+'\n')
        check = subprocess.run([sys.executable, str(args.exporter), str(ancestry_path), str(args.out/'inbox')],
                               text=True, capture_output=True, check=True)
        receipt = json.loads(check.stdout)
        assert receipt['matrix_transitions_and_path_loss'] == 'PASS' and receipt['records'] == len(chain)
        entry = {key: row[key] for key in ('id', 'n', 'phi', 'parent_id', 'root_id', 'root_n', 'depth',
                                          'path_max_alpha', 'path_positive_loss')}
        entry.update(matrix=matrix_path.name, ancestry=ancestry_path.name,
                     matrix_sha256=sha(matrix_path), ancestry_sha256=sha(ancestry_path),
                     matrix_int8_sha256=hashlib.sha256(bytes(v & 255 for line in a for v in line)).hexdigest(),
                     fixed_order_switch_and_global_negation_signature_sha256=item['sample_key'],
                     profile_signature=item['profile_signature'], profile=item['profile'],
                     backend_allocation=item['backend_allocation'], journal_index=source_index,
                     independent_source_certificate=certificate, ancestry_move_receipt=receipt)
        sources.append(entry)
        print(json.dumps(dict(stage='source_verified', id=rid, phi=row['phi'], root_n=row['root_n'],
                              depth=row['depth'], backend=entry['backend_allocation'])), flush=True)
    assert len({entry['id'] for entry in sources}) == len(sources)
    assert len({entry['matrix_int8_sha256'] for entry in sources}) == len(sources)
    manifest = dict(status='STORED_GROWN_A19_SOURCES_WITH_EXACT_SOURCE_AND_ANCESTRY_CHECKS',
                    target='fixed-source two-vertex endpoint at order21 with Phi<=44',
                    scope='bounded profile-diverse sample, not all signings or isomorphism classes',
                    selection='up to24 deterministic hash samples per Phi/root-order stratum, then profile/root-order diversity',
                    journals=journal_records, eligible_records=dict(eligible), preliminary_candidates=len(candidates),
                    excluded_sources=[dict(path=str(path), sha256=sha(path)) for path in args.exclude],
                    selector_sha256=sha(Path(__file__)), verifier_source_sha256=sha(args.verifier_source),
                    verifier_binary_sha256=sha(args.verifier), exporter_sha256=sha(args.exporter), sources=sources)
    (args.out/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps(dict(stage='complete', count=len(sources), per_phi=dict(Counter(entry['phi'] for entry in sources)),
                          per_backend=dict(Counter(entry['backend_allocation'] for entry in sources)),
                          manifest_sha256=sha(args.out/'manifest.json'))), flush=True)


if __name__ == '__main__':
    main()
