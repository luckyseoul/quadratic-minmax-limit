#!/usr/bin/env python3
"""Explicit fixed-pool core identities; no candidate or isomorphism census.

Vertex lineage fixes 15 or more seed labels. Each remaining row is tested
against just the 36 signed columns of that SAME seed. Explicit finite-field
maps are then verified entry by entry; their validity is not presumed.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def matrix_hash(a):
    return hashlib.sha256(bytes(v & 255 for row in a for v in row)).hexdigest()


def unpack(node):
    n = node['n']
    assert len(node['upper']) == n*(n-1)//2 and set(node['upper']) <= set('01')
    a = [[0]*n for _ in range(n)]
    k = 0
    for i in range(n):
        for j in range(i+1, n):
            a[i][j] = a[j][i] = 1 if node['upper'][k] == '1' else -1
            k += 1
    return a


def submatrix(a, order):
    return [[a[i][j] for j in order] for i in order]


def square(a):
    return [[sum(a[i][k]*a[k][j] for k in range(len(a)))
             for j in range(len(a))] for i in range(len(a))]


def conference(a):
    n = len(a)
    return square(a) == [[n-1 if i == j else 0 for j in range(n)] for i in range(n)]


def chi(t):
    t %= 17
    return 0 if t == 0 else (1 if pow(t, 8, 17) == 1 else -1)


manifest_path, output = map(Path, sys.argv[1:3])
assert not output.exists()
assert sha(manifest_path) == 'd543db5f958b71c5c4e44e630e729c2c4b8e7d6568ee602e0a207afb3f92a018'
manifest = json.loads(manifest_path.read_text())
selected = [row for row in manifest['sources'] if row['phi'] == 39]
assert len(selected) == 12
chains = {}
for row in selected:
    path = manifest_path.parent/row['ancestry']
    assert sha(path) == row['ancestry_sha256']
    chain = [entry['node'] for entry in json.loads(path.read_text())]
    assert chain[-1]['id'] == row['id'] and chain[-1]['phi'] == 39
    assert matrix_hash(unpack(chain[-1])) == row['matrix_int8_sha256']
    chains[row['id']] = chain
seed = unpack(chains['soul_68004'][0])
assert len(seed) == 18 and conference(seed)
assert all(seed[0][j] == 1 for j in range(1, 18))
assert all(seed[i+1][j+1] == chi(i-j) for i in range(17) for j in range(17))
baseline = unpack(chains['soulv2_10191'][-1])
assert submatrix(baseline, range(18)) == seed
assert all(baseline[i][18] == 1 for i in range(18))
roots = {}
reports = []
common_original = set(range(18))
for item in selected:
    chain = chains[item['id']]
    root = chain[0]
    assert root['n'] in (17, 18)
    assert unpack(root) == submatrix(seed, range(root['n']))
    roots.setdefault(matrix_hash(unpack(root)), dict(n=root['n'], phi=root['phi'], ids=set(), sources=0))
    roots[matrix_hash(unpack(root))]['ids'].add(root['id'])
    roots[matrix_hash(unpack(root))]['sources'] += 1
    lineage = list(range(root['n']))
    previous = root
    for node in chain[1:]:
        assert node['parent_id'] == previous['id'] and node['depth'] == previous['depth']+1
        if node['move'] in ('add_vertex', 'maxplus_add_vertex'):
            assert node['n'] == previous['n']+1
            lineage.append(None)
        elif node['move'] == 'delete_vertex':
            assert node['n'] == previous['n']-1
            lineage.pop(int(node['params']))
        else:
            assert node['n'] == previous['n'] and node['move'] in ('active_edge', 'edge_flip', 'triangle_flip', 'clique4_flip')
        assert len(lineage) == node['n']
        previous = node
    a = unpack(chain[-1])
    known = [(i, label) for i, label in enumerate(lineage) if label is not None]
    assert len(known) >= 15
    assert all(a[i][j] == seed[u][v] for i, u in known for j, v in known)
    common_original &= {label for _, label in known}
    labels = list(lineage)
    signs = [1]*19
    for i, label in enumerate(labels):
        if label is not None:
            continue
        candidates = [(v, sign) for v in range(18) for sign in (1, -1)
                      if all(v == u or a[i][j] == sign*seed[v][u] for j, u in known)]
        assert len(candidates) == 1, (item['id'], i, candidates)
        labels[i], signs[i] = candidates[0]
    multiplicities = Counter(labels)
    assert set(multiplicities) == set(range(18)) and sorted(multiplicities.values()) == [1]*17+[2]
    assert all(a[i][j] == signs[i]*signs[j]*seed[labels[i]][labels[j]]
               for i in range(19) for j in range(19) if labels[i] != labels[j])
    duplicate = next(v for v, count in multiplicities.items() if count == 2)
    twins = [i for i, v in enumerate(labels) if v == duplicate]
    delta = a[twins[0]][twins[1]]*signs[twins[0]]*signs[twins[1]]
    assert delta in (1, -1)
    assert conference(submatrix(a, [i for i in range(19) if i != twins[0]]))
    if duplicate == 0:
        permutation = list(range(18))
        switching = [1]*18
    else:
        v = duplicate-1
        permutation = [duplicate, 0]+[1+(v-pow(t, -1, 17)) % 17 for t in range(1, 17)]
        switching = [1, 1]+[chi(t) for t in range(1, 17)]
    assert sorted(permutation) == list(range(18))
    assert all(seed[permutation[i]][permutation[j]] == switching[i]*switching[j]*seed[i][j]
               for i in range(18) for j in range(18))
    order = [labels.index(v) for v in permutation]
    order.append(next(i for i in twins if i != order[0]))
    multipliers = [signs[order[i]]*switching[i] for i in range(18)]+[signs[order[18]]*switching[0]]
    global_sign = 1
    if delta == -1:
        assert chi(3) == -1
        anti = [0]+[1+(3*t) % 17 for t in range(17)]+[18]
        factors = [-1]+[1]*17+[-1]
        order = [order[i] for i in anti]
        multipliers = [factors[i]*multipliers[anti[i]] for i in range(19)]
        global_sign = -1
    assert sorted(order) == list(range(19))
    recovered = [[global_sign*multipliers[i]*multipliers[j]*a[order[i]][order[j]]
                  for j in range(19)] for i in range(19)]
    assert recovered == baseline
    last18 = next(node for node in reversed(chain) if node['n'] == 18)
    reports.append(dict(id=item['id'], root_id=root['id'], root_n=root['n'], depth=chain[-1]['depth'],
                        source_matrix_int8_sha256=matrix_hash(a), retained_literal_seed_vertices=len(known),
                        original_vertex_lineage=lineage, seed_label_per_vertex=labels, seed_switch_per_vertex=signs,
                        duplicate_seed_vertex=duplicate, twin_vertices=twins, normalized_twin_edge=delta,
                        last_order18_id=last18['id'], last_order18_matrix_int8_sha256=matrix_hash(unpack(last18)),
                        last_order18_is_conference=conference(unpack(last18)),
                        leading18_is_conference=conference(submatrix(a, range(18))),
                        baseline_id='soulv2_10191', canonical_permutation=order,
                        canonical_switch=multipliers, canonical_global_sign=global_sign,
                        canonical_identity='baseline[i,j] = global_sign*switch[i]*switch[j]*source[permutation[i],permutation[j]]',
                        canonical_matrix_int8_sha256=matrix_hash(recovered), checks='PASS'))
common_original = sorted(common_original)
common_core = submatrix(seed, common_original)
for report in reports:
    positions = [report['original_vertex_lineage'].index(v) for v in common_original]
    assert submatrix(unpack(chains[report['id']][-1]), positions) == common_core
    report['common_literal_core_positions'] = positions
for root in roots.values():
    root['ids'] = sorted(root['ids'])
result = dict(status='TWELVE_EXPLICIT_SIGNED_PERMUTATION_GLOBAL_NEGATION_IDENTITIES_VERIFIED',
              scope='frozen twelve Phi19=39 inputs only; explicit identities, not an isomorphism census',
              manifest_sha256=sha(manifest_path), script_sha256=sha(Path(__file__)),
              seed_order18_int8_sha256=matrix_hash(seed), seed_square='17 I', root_groups=roots,
              baseline_id='soulv2_10191', baseline_int8_sha256=matrix_hash(baseline),
              common_literal_seed_labels=common_original, common_literal_core_order=len(common_original),
              common_literal_core_int8_sha256=matrix_hash(common_core),
              minimum_retained_literal_seed_vertices=min(row['retained_literal_seed_vertices'] for row in reports),
              last_order18_distinct_signed_matrices=len({row['last_order18_matrix_int8_sha256'] for row in reports}),
              reports=reports)
output.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ('status', 'seed_order18_int8_sha256', 'baseline_int8_sha256',
    'common_literal_seed_labels', 'common_literal_core_order', 'minimum_retained_literal_seed_vertices',
    'last_order18_distinct_signed_matrices')}))
