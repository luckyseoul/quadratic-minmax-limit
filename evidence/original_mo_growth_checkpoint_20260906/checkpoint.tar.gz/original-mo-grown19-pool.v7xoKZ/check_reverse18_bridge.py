#!/usr/bin/env python3
"""Check one reverse leading18 and exact conference26 provenance; no minor scan."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def matrix_hash(a):
    return hashlib.sha256(bytes(v & 255 for row in a for v in row)).hexdigest()


def sub(a, indices):
    return [[a[i][j] for j in indices] for i in indices]


def square(a):
    n = len(a)
    return [[sum(a[i][k]*a[k][j] for k in range(n)) for j in range(n)] for i in range(n)]


preparation_path, verifier, output = map(Path, sys.argv[1:4])
assert not output.exists()
assert sha(preparation_path) == '7daf11e526a41d74dd6f523c92b1b67044c25d0eba89a25cf03327e35dd6d497'
assert sha(verifier) == '7aa4b5506203b5d0d4f220becc5979b032fbebbc83e613f570eaeda1e0cb4825'
preparation = json.loads(preparation_path.read_text())
chi = [-1]*25
chi[0] = 0
for z in range(1, 25):
    x, y = z % 5, z // 5
    chi[(x*x+2*y*y) % 5+5*((2*x*y) % 5)] = 1
c = [[0]*26 for _ in range(26)]
for i in range(1, 26):
    c[0][i] = c[i][0] = 1
for i in range(1, 26):
    for j in range(i+1, 26):
        x = ((j-1) % 5-(i-1) % 5) % 5
        y = ((j-1) // 5-(i-1) // 5) % 5
        c[i][j] = c[j][i] = chi[x+5*y]
assert square(c) == [[25 if i == j else 0 for j in range(26)] for i in range(26)]
# Explicit inclusion supplied by the source construction; the full matrix
# equality below, rather than historical journal metadata, proves provenance.
indices21 = [0, 1, 2, 3, 5, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 25]
assert len(indices21) == len(set(indices21)) == 21 and all(0 <= v < 26 for v in indices21)
assert sub(c, indices21) == preparation['original_matrix'] == preparation['old_champion_record']['A']
indices19 = [indices21[i] for i in preparation['retained_original_vertex_indices']]
assert len(indices19) == 19 and sub(c, indices19) == preparation['restricted_matrix']
indices18 = indices19[:18]
a18 = sub(c, indices18)
gram = square(a18)
offdiagonal = [(i, j, gram[i][j]) for i in range(18) for j in range(i+1, 18) if gram[i][j] != 0]
assert offdiagonal
complement = [v for v in range(26) if v not in indices18]
assert len(complement) == 8
cross_gram = [[sum(c[i][k]*c[j][k] for k in complement) for j in indices18] for i in indices18]
assert all(gram[i][j]+cross_gram[i][j] == (25 if i == j else 0) for i in range(18) for j in range(18))
output.mkdir()
matrix_path = output/'leading18.txt'
matrix_path.write_text('18\n'+'\n'.join(' '.join(map(str, row)) for row in a18)+'\n')
certificate = json.loads(subprocess.check_output([str(verifier), str(matrix_path)], text=True))
assert certificate['n'] == 18 and certificate['checks'] == 'PASS'
result = dict(status='EXACT_CONFERENCE26_PROVENANCE_AND_NO_CONFERENCE18_BRIDGE',
              preparation_sha256=sha(preparation_path), script_sha256=sha(Path(__file__)), verifier_sha256=sha(verifier),
              conference26_int8_sha256=matrix_hash(c), conference26_square='25 I',
              indices21=indices21, indices19=indices19, inspected_indices18=indices18,
              original21_identity='PASS', reverse19_identity='PASS',
              leading18_int8_sha256=matrix_hash(a18), leading18_field_certificate=certificate,
              leading18_square=gram, first_nonzero_gram_offdiagonal=offdiagonal[0],
              cross_gram=cross_gram, block_square_identity='A18^2 + B B^T = 25 I18',
              no18minor_bridge_argument='If any18principal were conference, B B^T=8I18 but B has only8columns: rank contradiction.',
              edge_change_lower_bound=5,
              edge_change_argument='Any18principal has >=5 eigenvalues+5 and >=5 eigenvalues-5. Subtracting any signed/permuted/global-sign conference18 of norm sqrt17 gives inertia >=(5,5), rank>=10. Each changed edge contributes rank<=2, so >=5 changes.',
              inspected_minor_count=1, all_minor_exclusion_scope='algebraic block-rank implication, no minor enumeration')
(output/'result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(dict(status=result['status'], leading18_phi=certificate['phi'],
                      first_nonzero_gram_offdiagonal=offdiagonal[0], result_sha256=sha(output/'result.json'))))
