# Spectral obstruction to retaining a conference core

2026-09-06. This is a structural operation lower bound for specified
source and target families, not a lower bound on normalized path loss,
a no-go for arbitrary growth, or a convergence theorem.

## General rank lemma

Let C be a symmetric conference matrix of order N>=2:

    C^2=(N-1)I, diag(C)=0.

The spectral theorem and trace zero imply that its two eigenvalues
lambda=sqrt(N-1) and -lambda each have multiplicity N/2. In particular N
is even. Let H be any principal block of order r>N/2. In each of the two
N/2-dimensional eigenspaces, imposing zero on the N-r deleted coordinates
leaves a subspace of dimension at least r-N/2. Restricting these vectors
to the retained coordinates shows that H has eigenvalues +lambda and
-lambda each with multiplicity at least r-N/2.

Now let K be any symmetric order-r matrix with ||K||op<lambda, and put
E=H-K. On the +lambda subspace just constructed, every nonzero v satisfies

    v^T E v >= (lambda-||K||op)||v||^2 > 0.

On the -lambda subspace, the quadratic form of E is strictly negative.
Consequently E has at least r-N/2 positive and at least r-N/2 negative
eigenvalues. For completeness, if the positive index were smaller, the
positive subspace would intersect the nonpositive spectral subspace in a
nonzero vector, contradicting strict positivity there; the negative case
is identical. Thus

    rank(H-K) >= 2r-N.                                  (1)

If H and K are complete zero-diagonal signings differing on k unordered
edges, their difference is a sum of k matrices, each supported on one
symmetric off-diagonal pair and of rank at most two. Rank subadditivity
and (1) give

    k >= r-N/2.                                        (2)

These conclusions persist under arbitrary coordinate permutations,
diagonal sign switches, and global sign changes of K, since its operator
norm is unchanged. They do not presume an alignment from numerical
profiles. Equality H=K is impossible for every r>N/2 under the strict cap.

## Application to the actual two construction families

The checked forward seed C18 satisfies C18^2=17I. Every principal block K
of it has operator norm at most sqrt(17). The checked target construction
C26 satisfies C26^2=25I, so lambda=5>sqrt(17). Therefore no principal
blocks of C18 and C26 of a common size r>=14 are equivalent under any
of the operations above. For any such aligned pair,

    changed retained edges >= r-13.                    (3)

In particular, any order-18 block of C26 differs from every equivalent
C18 by at least five edges. Any order-17 block differs from every
equivalent order-17 principal block of C18 by at least four edges.

Suppose a proposed path from the actual C18 seed ends in a principal
block of this C26 construction. Let d be the number of ORIGINAL seed
vertices absent at the endpoint, and k the number of final mismatched
edges among the surviving original vertices, after their actual label
alignment (or any permitted equivalence). Then r=18-d originals survive.
If d<=4, (3) gives k>=5-d. If d>=5 the following statement is immediate:

    d+k >= 5.                                         (4)

Thus a pure delete/add route leaving all surviving-original edges unchanged
must discard at least five originals. A route retaining every original
must change at least five old edges. Repeated deletion of NEW vertices does
not count toward d. Repeated flips that cancel do not reduce the required
number of final mismatches, so actual operations cannot evade this bound.
Equation (4) counts individual vertex deletions and individual changed
edges; it is not a lower bound of five on the number of arbitrary macro
moves if one macro move changes several edges at once.

## Actual provenance and scope

The finite input checks are retained in:

    /tmp/original-mo-grown19-pool.v7xoKZ/phi39_core_identities.json
      SHA256 e717413ef192d68b6bdc6feb0520e6624691debb1135ac097913be33338def14
    /tmp/original-mo-grown19-pool.v7xoKZ/reverse18_bridge/result.json
      SHA256 f565539f0a163b8f2090be021d29c7ab344398db9840c366c6bddf178b2c52e0

The first verifies C18 and explicit full-matrix equivalences of the twelve
forward norm-39 order-19 sources to one signed-duplicate construction.
The second reconstructs C26 over GF(25), checks its square exactly, and
checks every entry of the retained norm-44 order-21 target and its leading
norm-41 order-19 restriction against the specified C26 principal sets.
The algebra above consequently applies to these ACTUAL targets, not
merely to a suggested origin. It requires no census of target minors.

Nothing here excludes other norm-44 targets, quantifies the norm during
the required edits, supplies an actual path, or proves that optimal
signings must come from either conference family.
