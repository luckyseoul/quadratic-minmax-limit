# Exact growth-path optimization inside a fixed target

2026-09-06. This is a finite algorithm, conditional on an explicitly
verified embedding of the actual starting signing. It does not establish
that arbitrary good sources embed in good larger targets, or convergence.

## Embedding gate

Let A be the actual source of order k and C a fixed complete signing of
order N>=k. Suppose an injection f into the target vertices, switches
epsilon_i in {-1,1}, and a global sign sigma in {-1,1} satisfy

    A_ij = sigma epsilon_i epsilon_j C_{f(i),f(j)}

for every source pair. This is a finite full-matrix identity, not a
similarity inferred from matching profiles. Permute the target so the
source images come first, extend the switches arbitrarily to its other
vertices, and apply sigma to the whole target. The resulting target B
has leading block EXACTLY A and preserves Phi on every corresponding
principal submatrix. Thus every ordering of the remaining vertices is an
actual sequence of pure vertex additions from A.

A failed bounded embedding search establishes no non-embedding result
unless its coverage was complete. Restricting a larger matrix to manufacture
a source does not establish the gate for an independently given source.

## Subset state space and costs

Write R for the m=N-k remaining vertices. For each S subset of R let
B_S be the principal signing consisting of the k fixed source vertices
and S, and let

    a(S)=Phi(B_S)/(k+|S|)^(3/2),
    c(S)=a(S)^2=Phi(B_S)^2/(k+|S|)^3.

Compute every Phi(B_S) exactly, preserving matrix and witness provenance.
There are 2^m states. Exhausting projective spin states separately for
each matrix costs exactly

    sum_S 2^(k+|S|-1) = 2^(k-1) 3^m

spin states. A standard field-update enumerator takes at most an additional
O(N) arithmetic work per state. This is not a new signing search: the
state matrices are all prescribed restrictions of ONE target.

Every pure growth order corresponds bijectively to a maximal chain in the
subset lattice, whose edges add one vertex. All m! orders are covered by
this lattice without enumerating them separately.

## Exact minimum path maximum

Define D(empty)=c(empty). For a nonempty S, set

    D(S)=min_{v in S} max(D(S\{v}), c(S)).                 (1)

Induction on |S| proves that D(S) is the minimum squared normalized path
maximum over all addition orders reaching B_S. Every such order ends by
one of the displayed predecessor edges, and conversely each predecessor
path extends to that state. Since all costs are nonnegative, squaring
preserves all comparisons. The complete computation uses O(m 2^m)
rational comparisons, with no floating-point tie decisions. A predecessor
pointer reconstructs an actual minimizing growth order.

## Positive variation is a different objective

For a path S_0,...,S_m define

    V=sum_j max(0, a(S_j)-a(S_{j-1})).

To minimize V without a peak constraint, ordinary shortest-path dynamic
programming on the same directed acyclic graph uses these nonnegative
edge costs. To minimize V AMONG minimum-peak paths, first compute the
global optimum P=D(R) from (1). Then keep all states with c(S)<=P and
run the shortest-path recursion on that induced graph. Every minimum-peak
path is retained, and no retained complete path can improve the already
minimal P. This is the correct two-pass lexicographic optimization.

Keeping only one lexicographically minimal (past peak,past variation)
pair per state in a single pass is not generally valid: a later high-cost
state can equalize the past peaks, making a discarded higher-peak but
lower-variation prefix preferable.

If only (1) is implemented, report V of the recovered path as a measured
quantity; do not claim it is globally minimized. If the recovered path
has V=0, that objective is automatically optimal because V is nonnegative.

## Optional exact radical comparisons

Exact comparison of variations can avoid floating-point assumptions.
Write each positive integer n=d^2 r with r squarefree. Then

    Phi/n^(3/2) = (Phi*d/n^2) sqrt(r).

Represent a path variation as a rational coefficient vector on the
distinct squarefree radicals sqrt(r), including r=1. First compare the
two endpoint costs of an edge by their rational squares, so whether its
positive part vanishes is exact. Add or subtract the corresponding
coefficient vectors for every nonzero increment.

Equal coefficient vectors represent equal values. Distinct squarefree
radicals are linearly independent over the rationals, so a nonzero
difference vector represents a nonzero real number. Its sign can be
certified by increasingly precise rational intervals: integer square
roots of r*2^(2p) give lower and upper bounds for sqrt(r), with width
at most 2^-p. Use coefficient signs when forming interval endpoints.
Unless the vectors are equal, some finite precision separates zero.
Such interval certificates, not a fixed decimal tolerance, support exact
variation comparisons if that optional optimization is implemented.

## Scope

Optimality here is over all addition orders for ONE fixed embedded source
and ONE fixed target, not over all possible future signings or embeddings.
Original source ancestry remains unchanged; new nodes receive actual
incident columns, parent identifiers, norms, witnesses, and path losses.
A finite path reaching a known good target is not an all-orders extension
theorem or a proof that the normalized global optimum converges.
