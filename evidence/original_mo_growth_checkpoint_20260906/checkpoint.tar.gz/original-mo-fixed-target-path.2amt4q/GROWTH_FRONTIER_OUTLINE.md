# Source profiles and the finite growth frontier: milestone outline

2026-09-06. TEMP publication outline only; no repository edits, backup,
commit, or new computation is implied. Original-MO `L OPEN` and the global
growth/convergence implication remain open.

## 1. Main mathematical addition: an exact two-addition optimizer

For a specified signing A, switching the last new vertex fixes its mutual
edge to +1. Splitting b,c by S={i:b_i=c_i} gives the complete-family identity

    min_{b,c,d} Phi(A+b+c) = min_S max(U_+(S), U_-(S^c)),
    U_+/-(S) = min_{supp(v)=S} max_x (|Q_A(x)+/-1| + 2 v.x).

The rectangular Boolean-to-ternary max-plus transform and support reduction
evaluate this in O(3^n) integer work/storage; actual optimal rows are
reconstructed and independently checked. This is an all-finite-order
algorithmic theorem, not an upper bound on the optimum or convergence.
The optional complete endpoint-then-intermediate tie refinement costs
O(|K| 2^n), potentially O(4^n), and is not part of the O(3^n) claim.

Publication proof: `/tmp/original-mo-two-vertex-ternary.XF0Dmh0P/PROOF.md`
SHA256 `2e745619ca7af07cfb5048c7921dad0d41c51c61db8442ec17e2501cf8a39a9b`.

## 2. Finite results: source quality is not its scalar norm

- Fixed actual order-11 source, Phi=17: greedy one-addition optimum 18
  can reach no better than 24 on the second addition; the complete two-add
  optimum is 22, attained along 17 -> 20 -> 22. The older independent row
  oracle exhausted 2,097,152 gauge-reduced row pairs. This is a concrete
  greedy trap for this source, not a universal statement about greedy paths.
- Two actual order-15 sources both have Phi=27 and exact optimal endpoint
  Phi17=34. Among ALL endpoint-optimal extensions, Soul's smallest first
  norm is 34, while Nuka's is 30. Their local normalized path maxima are
  respectively 0.53125 and 34/17^(3/2)=0.485071250072666.
- The Nuka path 27 -> 30 -> 34 has increasing normalized values. Because 34
  is the global fixed-source two-add endpoint minimum, that path also
  globally minimizes its local normalized maximum AND positive variation:
  V=34/17^(3/2)-27/15^(3/2)=0.020313248527776. This stronger conclusion
  uses monotonicity, not the tie optimizer alone. It does not optimize the
  full pre-existing ancestry or all repair/growth paths.
- Preserve actual roots and all earlier repairs: the Nuka Phi=27 node has
  an order-15 Phi=29 root. Never replace that prefix with a fabricated root.

Primary receipts under `/tmp/original-mo-two-vertex-cpu.0eqNgg/`:

| Receipt | SHA256 |
| --- | --- |
| `fixed11.tie.json` | `324be6113dfeea3987de96ddbd2ed250850136144eccb14112daf91586c631bc` |
| `soul15.tie.json` | `28aec3227ceb59c08dda0796bccfb02ba62dbe20edfb5da51539e9a13cd7618c` |
| `nuka15.tie.json` | `541d43c17f32b60d082b40d70e82ff623d5f5568f9566cfa6b9d2579fc87642a` |

Original trap receipt `/tmp/original-mo-pathwalkers.0Suy9n/two_step_fixed11.json`
SHA256 `0012156776898d2f5612088893b30473566a46c1ac61906280a8ed2cad16be77`.

## 3. Order 64: retain the exact matrix certificate separately

The retained order-64 matrix has certified Phi=248 and normalized value
248/64^(3/2)=31/64. This is the exact norm of ONE specified matrix, not
the optimum over all order-64 signings, a growth path from the warm source,
or an amplification/convergence theorem. The proof reduces values above 248
to 256 and 252, then excludes both eigenvalue branches and all eight sparse
residual affine systems: two homogeneous and eight affine phases, each
covering 2^31 free assignments. A direct Boolean witness attains 248.
The certificate is exhaustive integer computation, not a DRAT proof log.
Self-contained bundle: `/tmp/mo-n64-exact248-20260906.FwhaOc/`, with
`manifest.json` SHA256
`d2c7f2147d3cf5c02bff41616c2e2a483c82c9752af22f003f77343b712cdf2d`.
The exact A matrix SHA256 is
`243559f999fd12cccc1947fc4359ac754f7678d471e780fca2d33498c633efc6`.

## 4. Frozen order-19 pool and the successful reverse entrance

- All 32 specified forward sources have exact two-add endpoint minimum 48.
  Backends covered disjoint inputs: V100 16, Orin 8, AMD 4, Intel 4. These are
  complete extension certificates for those 32 matrices, not coverage of
  all possible order-19 sources. Recorded intermediate norms were selected
  by endpoint reconstruction, not a full global tie optimization.
- The 12 Phi=39 sources are explicitly equivalent under signed permutation
  and global sign to ONE duplicated-C18 construction. Their actual DAG
  roots split six at C18, Phi=33, and six at its leading C17, Phi=32; do not claim
  that every source began at the same literal order-18 root. No equivalence
  classification of the remaining 20 sources is asserted.
- In contrast, the leading order-19 restriction of the retained C26-derived
  order-21, Phi=44 target has Phi=41 and exact two-add optimum 44, reconstructed
  as 41 -> 44 -> 44. Its invariant profile differs from all 32 forward
  entries. Restricting a successful endpoint recovers an entrance; it does
  not supply a path from an independently specified forward source.

Pool manifest: `/tmp/original-mo-grown19-pool.v7xoKZ/selected/manifest.json`,
SHA256 `d543db5f958b71c5c4e44e630e729c2c4b8e7d6568ee602e0a207afb3f92a018`.
The four completed endpoint receipts are:

| Receipt | SHA256 |
| --- | --- |
| `/tmp/original_mo_path_v100_20260906_Q86jOz/bounded_grown19_v100/result.json` | `e483ff51fa70c8b11ecd1eb0ec80cfb649aea2353a770174d0260a0d03c495e5` |
| `/tmp/original-mo-grown19-pool.v7xoKZ/orin_batch/result.json` | `d253382d7f396e7f710a46daceacc9dfbd2c12655c01f8b98962d0cebdb0a6bc` |
| `/tmp/mo-nuka-pathwalk-20260906.AvNLid/mo-nuka-grown19-four-20260906/result.json` | `daaef73c6bdf8f5cda696cfc997da57f5904c88c0b9a1c82fe5880b7e0d5747b` |
| `/tmp/mo-nuka-pathwalk-20260906.AvNLid/mo-arc-grown19-four-20260906/result.json` | `92993e0a243bff294fb6d910b61dab5c083e81b72ea8f28ce75aaa3240071fef` |

Class identities: same stage, `phi39_core_identities.json`,
SHA256 `e717413ef192d68b6bdc6feb0520e6624691debb1135ac097913be33338def14`.
Reverse receipt: `/tmp/original_mo_path_v100_20260906_Q86jOz/reverse21_control/result.json`,
SHA256 `7fbff2242c2d7dca6065477870047b8635f54fe91e155ea4d9ec9da19022235a`.

## 5. Actual bridge exclusions, with their exact scope

Generic conference lemma: for C_N^2=(N-1)I, N>=2, a principal H_r with
r>N/2 and any symmetric K_r satisfying ||K_r||op<sqrt(N-1) obey
rank(H_r-K_r)>=2r-N. If both are complete signings, their k differing
unordered edges satisfy k>=r-N/2. This is invariant under switching,
permutation, and global sign.

For C18 versus the verified C26 target family, there is no common principal
core of size 14 or greater. With d ORIGINAL C18 vertices absent and k final
edge mismatches among surviving originals, d+k>=5. It counts individual
deletions/edges, not arbitrary compound moves, and gives no norm-loss bound.
The reverse leading order-18 block has exact Phi=37 and Gram entry (0,3)=2; full C26
inclusion and square identities were verified without a target-minor census.

The exact warm order-11 source also has NO signed principal embedding in
either the chosen reverse order-19 target (38 root/sign cases; 40,616 nodes)
or the actual original order-21 target (42 cases; 82,510 nodes). Both searches completed exhaustively.
Thus pure additions cannot reach either specified target from that source,
even up to switching/permutation/global sign. Other targets and paths
editing/deleting old vertices remain outside these exclusions.

Proof: `CONFERENCE_BRIDGE.md` in this directory,
SHA256 `4693db5459443040f93cca98771f19f5c54952b2323f9abccb04057399819e62`.
Inclusion receipt: `/tmp/original-mo-grown19-pool.v7xoKZ/reverse18_bridge/result.json`,
SHA256 `f565539f0a163b8f2090be021d29c7ab344398db9840c366c6bddf178b2c52e0`.
Embedding receipts under `/tmp/original_mo_path_v100_20260906_Q86jOz/`:

| Receipt | SHA256 |
| --- | --- |
| `warm11_reverse19_embedding_results/result.json` | `f15de2eeb1e81eb2bc533641d12162bf7174b029306dbc9fba51a321c38d4f14` |
| `warm11_original21_embedding_results/result.json` | `d0aabf6310e9929320a725f9e5f3e43fb18729244006f99c05592934788a11f4` |

## 6. What is available next, and what is still missing

For a VERIFIED embedding in one fixed target, the subset-lattice recurrence
D(S)=min_v max(D(S-v),Phi(B_S)^2/|B_S|^3) gives the exact minimum squared
normalized path maximum using rational comparisons. A second shortest-path
pass through states at or below the optimal squared-peak threshold can
minimize positive variation; a one-pass lexicographic prefix label is
insufficient. To include old ancestry, initialize D(empty) with the maximum
of c(empty) and the squared historical peak, and add the fixed past variation.
This is proved in `PROOF.md` here, SHA256
`618342b91af1ce6a7eac18fd6518749c0995381763909612de5e6a116dc59c6a`.
The checked warm order-11 gates FAILED, so no subset DP was run by silently
substituting a smaller manufactured root.

The live missing implication is an actual-source growth/repair mechanism
with controlled accumulated normalized loss, not the existence of an
isolated good target or a low current Phi. A compact publication should
lead with the exact transform and source-dependence examples, retain the
finite order-64 certificate and explicit bridge exclusions, and leave the
global predicate OPEN. Do not repeat the unchanged 32-source assay or treat
its collapsed Phi=39 entries as independent construction diversity.
