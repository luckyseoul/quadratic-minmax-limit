#!/usr/bin/env python3
"""Entrywise verification of one specified finite diagonal Gram certificate.

No search, GPU call, SDP, numerical eigenvalue, or new source. This only
checks root's explicit decomposition for the retained soul_68004 rows.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np

BASE_SHA = 'ab2cc476badc2ab7e612b8af0cbc48cccdfae0863180482911f9bf3df8be99ea'
SOURCE_SHA = '6ad2f09dae47f7e021b0717a0a9398cd649063b0c897e950ffe79fc615259963'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert sha(args.base) == BASE_SHA and sha(args.source) == SOURCE_SHA
    record = json.loads(args.base.read_text())
    assert record['source_name'] == 'soul_68004' and record['n'] == 19 and record['target'] == 44
    tokens = list(map(int,args.source.read_text().split()))
    assert tokens[0] == 19 and len(tokens) == 362
    a = np.asarray(tokens[1:],dtype=np.int64).reshape(19,19)
    assert np.array_equal(a,record['source_matrix'])
    i,j = 6,18
    remaining = [k for k in range(19) if k not in (i,j)]
    assert a[i,j] == -1 and np.array_equal(a[i,remaining],-a[j,remaining])
    levels = {row['q']:row for row in record['selected_levels']}
    assert set(levels) == {39,-37}
    grams = {}
    for q,row in levels.items():
        masks = np.asarray(row['masks'],dtype=np.int64)
        assert len(masks) == row['projective_count'] == 136 and len(set(masks.tolist())) == 136
        assert np.all((masks >= 0) & (masks < (1<<19)) & (masks % 2 == 0))
        x = 1-2*((masks[:,None] >> np.arange(19)) & 1)
        assert np.all(np.sum((x@a)*x,axis=1)//2 == q)
        assert np.all(x[:,i] == -x[:,j])
        grams[q] = x.T@x
        assert np.array_equal(grams[q],row['gram_sum'])
    h = grams[39]+grams[-37]
    assert np.all(np.abs(grams[39][remaining,i]) == 48)
    z = grams[39][remaining,i]//48
    w = np.zeros(19,dtype=np.int64)
    w[remaining] = z
    kernel = np.zeros(19,dtype=np.int64)
    kernel[i] = kernel[j] = 1
    twin_direction = np.zeros(19,dtype=np.int64)
    twin_direction[i] = 1
    twin_direction[j] = -1
    diagonal = np.zeros(19,dtype=np.int64)
    diagonal[remaining] = 252
    psd_remainder = 20*np.outer(w,w)+272*np.outer(twin_direction,twin_direction)
    assert np.array_equal(h-np.diag(diagonal),psd_remainder)
    assert np.array_equal(h@kernel,np.zeros(19,dtype=np.int64))
    assert all(np.array_equal(g@kernel,np.zeros(19,dtype=np.int64)) for g in grams.values())
    bounds = []
    for parity in (0,1):
        bound = 0
        for q,row in levels.items():
            raw_a = (44-abs(q+1))//2
            raw_b = (44-abs(q-1))//2
            cap_a = raw_a-((raw_a-parity)%2)
            cap_b = raw_b-((raw_b-((19-parity)%2))%2)
            assert min(cap_a,cap_b) >= 0
            assert row['parity_caps'][parity]['squared_sum'] == cap_a**2+cap_b**2
            bound += len(row['masks'])*(cap_a**2+cap_b**2)
        bounds.append(bound)
    trace = int(diagonal.sum())
    assert bounds == [5168,2448] and trace == 4284
    assert trace > bounds[1] and trace <= bounds[0]
    output = dict(status='PASS_EXPLICIT_TWIN_DIAGONAL_ODD_SUPPORT_OBSTRUCTION',
        source_name='soul_68004',source_matrix_sha256=SOURCE_SHA,base_receipt_sha256=BASE_SHA,
        script_sha256=sha(__file__),target=44,twins=[i,j],remaining_coordinates=remaining,
        actual_levels=[39,-37],projective_rows_per_level=136,
        all_selected_rows_direct_energy_and_gram_check='PASS',
        source_signed_twin_relation='A[18,k]=-A[6,k] outside the pair; A[6,18]=-1',
        selected_row_relation='x[6]=-x[18]',common_gram_kernel=kernel.tolist(),
        common_diagonal=diagonal.tolist(),trace_common_diagonal=trace,
        gram_sum=h.tolist(),psd_rank_one_decomposition=[dict(weight=20,vector=w.tolist()),
                                                       dict(weight=272,vector=twin_direction.tolist())],
        exact_entrywise_PSD_decomposition_check='PASS',parity_bounds= bounds,
        strict_odd_trace_margin=trace-bounds[1],parity_branches_excluded=[False,True],
        all_two_extensions_at_target_excluded=False,
        classification='odd support branch excluded for this fixed source; even branch remains; no asymptotic conclusion')
    with args.output.open('x') as destination:
        destination.write(json.dumps(output,indent=2)+'\n')
    print(json.dumps({key:output[key] for key in ('status','parity_branches_excluded','trace_common_diagonal',
                                                 'parity_bounds','strict_odd_trace_margin')}),flush=True)


if __name__ == '__main__':
    main()
