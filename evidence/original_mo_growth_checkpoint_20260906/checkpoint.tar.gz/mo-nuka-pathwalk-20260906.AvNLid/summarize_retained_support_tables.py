#!/usr/bin/env python3
"""Aggregate only two immutable existing support archives; no optimizer call."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np

N,TARGET = 19,44
SOURCES = (
    dict(name='soul_68004',directory='bounded_grown19_v100/source_00_soul_68004',
         matrix='source.txt',matrix_sha='6ad2f09dae47f7e021b0717a0a9398cd649063b0c897e950ffe79fc615259963',
         result_sha='6c3e4069ba297d56a84a5d2d848a74aff154661369c9a44ea9f408e4bfefae90',
         archive_sha='1ba8f48e848df3d2514f0f69cd5421514ea032ad7219207aa4e48812440170be',
         optimum=48,twins=(6,18)),
    dict(name='reverse21_restriction19',directory='reverse21_control',
         matrix='restriction19.txt',matrix_sha='40eb02857299421f23b2ef6d67a75fdc00e1afb65aa26fc6091ef54cb43b60ba',
         result_sha='7fbff2242c2d7dca6065477870047b8635f54fe91e155ea4d9ec9da19022235a',
         archive_sha='c729cd79bff8b7970433270fc09a2082b76f198c668379c4478a561848224b65',
         preparation_sha='7daf11e526a41d74dd6f523c92b1b67044c25d0eba89a25cf03327e35dd6d497',
         optimum=44,twins=None),
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    masks=np.arange(1<<N,dtype=np.int64)
    sizes=np.zeros(1<<N,dtype=np.int64)
    for bit in range(N):sizes+=(masks>>bit)&1
    complements=masks^((1<<N)-1)
    assert np.array_equal(sizes[complements],N-sizes)
    sources=[]
    for spec in SOURCES:
        directory=args.root/spec['directory']
        matrix_path=directory/spec['matrix'];result_path=directory/'result.json';archive_path=directory/'support_optima.npz'
        assert sha(matrix_path)==spec['matrix_sha'] and sha(result_path)==spec['result_sha']
        assert sha(archive_path)==spec['archive_sha']
        tokens=list(map(int,matrix_path.read_text().split()))
        assert tokens[0]==N and len(tokens)==1+N*N
        a=np.asarray(tokens[1:],dtype=np.int64).reshape(N,N)
        assert np.array_equal(a,a.T) and np.all(np.diag(a)==0) and np.all(np.abs(a[np.triu_indices(N,1)])==1)
        result=json.loads(result_path.read_text())
        assert result['support_archive_sha256']==spec['archive_sha']
        if spec['twins'] is not None:
            assert result['source_id']==spec['name'] and result['source_input_sha256']==spec['matrix_sha']
            assert np.array_equal(a,result['source_matrix']) and result['endpoint_optimum']==spec['optimum']
            i,j=spec['twins'];rest=[k for k in range(N) if k not in (i,j)]
            assert a[i,j]==-1 and np.array_equal(a[i,rest],-a[j,rest])
        else:
            preparation_path=directory/'preparation.json'
            assert sha(preparation_path)==spec['preparation_sha']==result['preparation_sha256']
            preparation=json.loads(preparation_path.read_text())
            assert preparation['restricted_input_sha256']==spec['matrix_sha']
            assert np.array_equal(a,preparation['restricted_matrix'])
            assert result['exact_two_extension_optimum']==spec['optimum']
        with np.load(archive_path,allow_pickle=False) as archive:
            assert set(archive.files)=={'U_plus','U_minus'}
            tables={key:archive[key].copy() for key in ('U_plus','U_minus')}
        assert all(value.shape==(1<<N,) and value.dtype==np.dtype('int16') for value in tables.values())
        assert all(np.all((value>=0)&(value<=210)&(value%2==0)) for value in tables.values())
        endpoint_cost=np.maximum(tables['U_plus'],tables['U_minus'][complements])
        assert int(endpoint_cost.min())==spec['optimum']
        assert int(endpoint_cost[result['support']])==spec['optimum']
        feasible={key:value<=TARGET for key,value in tables.items()}
        intersection=feasible['U_plus']&feasible['U_minus'][complements]
        cardinalities=[];memberships=[]
        twin_codes=None if spec['twins'] is None else ((masks>>spec['twins'][0])&1)+2*((masks>>spec['twins'][1])&1)
        for size in range(N+1):
            selected=sizes==size
            assert int(selected.sum())==math.comb(N,size)
            row=dict(size=size,support_count=int(selected.sum()),actual_complement_intersection_count=int(intersection[selected].sum()))
            for key,value in tables.items():
                row[key]=dict(min_cost=int(value[selected].min()),feasible_count=int(feasible[key][selected].sum()))
            cardinalities.append(row)
            if twin_codes is not None:
                for code in range(4):
                    selected=(sizes==size)&(twin_codes==code);remainder=size-code.bit_count()
                    expected=math.comb(N-2,remainder) if 0<=remainder<=N-2 else 0
                    assert int(selected.sum())==expected
                    row=dict(size=size,twin_membership_code=code,support_count=expected,
                             actual_complement_intersection_count=int(intersection[selected].sum()))
                    for key,value in tables.items():
                        row[key]=dict(min_cost=int(value[selected].min()) if expected else None,
                                      feasible_count=int(feasible[key][selected].sum()))
                    memberships.append(row)
        maxima={key:int(sizes[value].max()) if value.any() else None for key,value in feasible.items()}
        size_compatibility=[size for size in range(N+1) if cardinalities[size]['U_plus']['feasible_count']
                            and cardinalities[N-size]['U_minus']['feasible_count']]
        member_lookup={(row['size'],row['twin_membership_code']):row for row in memberships}
        twin_compatibility=[]
        for (size,code),row in member_lookup.items():
            other=member_lookup[(N-size,3^code)]
            if row['U_plus']['feasible_count'] and other['U_minus']['feasible_count']:
                twin_compatibility.append(dict(plus_size=size,plus_twin_membership_code=code,
                    plus_feasible_count=row['U_plus']['feasible_count'],minus_complement_class_feasible_count=other['U_minus']['feasible_count']))
        assert sum(row['actual_complement_intersection_count'] for row in cardinalities)==int(intersection.sum())
        if memberships:assert sum(row['actual_complement_intersection_count'] for row in memberships)==int(intersection.sum())
        entry=dict(source=spec['name'],n=N,target=TARGET,source_matrix_sha256=spec['matrix_sha'],
                   endpoint_receipt_sha256=spec['result_sha'],support_archive_sha256=spec['archive_sha'],
                   exact_endpoint_minimum=spec['optimum'],feasible_totals={key:int(value.sum()) for key,value in feasible.items()},
                   maximum_feasible_support_sizes=maxima,max_size_sum=sum(maxima.values()),
                   max_size_sum_strictly_below_n=sum(maxima.values())<N,
                   compatible_plus_cardinalities=size_compatibility,
                   twin_coordinates=spec['twins'],twin_membership_code_definition='bit0 is first twin; bit1 is second twin',
                   compatible_plus_cardinality_and_twin_classes=twin_compatibility,
                   actual_complement_intersection_count=int(intersection.sum()),
                   first_intersecting_support=int(np.flatnonzero(intersection)[0]) if intersection.any() else None,
                   by_cardinality=cardinalities,by_cardinality_and_twin_membership=memberships,
                   classification='exact aggregation of existing complete support tables; no new candidate or oracle run')
        sources.append(entry)
        print(json.dumps({key:entry[key] for key in ('source','maximum_feasible_support_sizes','max_size_sum',
             'compatible_plus_cardinalities','actual_complement_intersection_count')}),flush=True)
    output=dict(status='PASS_IMMUTABLE_TWO_SOURCE_SUPPORT_AGGREGATION',script_sha256=sha(__file__),sources=sources,
                optimizer_calls=0,new_Q_or_F_calls=0,new_candidate_searches=0)
    with args.output.open('x') as destination:destination.write(json.dumps(output,indent=2)+'\n')


if __name__=='__main__':main()
