#!/usr/bin/env python3
"""Complete two-vertex endpoint optimization by the reviewed ternary identity.

CUDA expands each Boolean digit to ternary by max-plus, then contracts
ternary sign choices to support digits by min. Signs +/- run sequentially.
Only n<=19 is allowed here; every old large buffer is explicitly released.
The reconstructed endpoint minimizes the endpoint, NOT the first-step norm
or the path maximum over all endpoint-optimal assignments. We compare the
two vertex orders only for the single reconstructed endpoint.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time
import cupy as cp
import numpy as np

CUDA = r'''
extern "C" __global__ void energy(const signed char* a, short* q, int n, unsigned long long size) {
  unsigned long long k=(unsigned long long)blockDim.x*blockIdx.x+threadIdx.x;
  if(k>=size)return;
  int sum=0;
  for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)
    sum+=(int)a[i*n+j]*(1-2*(int)((k>>i)&1))*(1-2*(int)((k>>j)&1));
  q[k]=(short)sum;
}
extern "C" __global__ void expand(const short* src, short* dst, unsigned long long size, unsigned long long stride) {
  unsigned long long k=(unsigned long long)blockDim.x*blockIdx.x+threadIdx.x;
  if(k>=size)return;
  unsigned long long low=k%stride, digit=(k/stride)%3, high=k/(3*stride), base=high*2*stride+low;
  int a=src[base],b=src[base+stride],v=(int)digit-1;
  dst[k]=(short)max(a+2*v,b-2*v);
}
extern "C" __global__ void contract(const short* src, short* dst, unsigned long long size, unsigned long long stride) {
  unsigned long long k=(unsigned long long)blockDim.x*blockIdx.x+threadIdx.x;
  if(k>=size)return;
  unsigned long long low=k%stride, digit=(k/stride)%2, high=k/(2*stride), base=high*3*stride+low;
  dst[k]=digit ? min(src[base],src[base+2*stride]) : src[base+stride];
}
extern "C" __global__ void restricted(const short* src, short* dst, unsigned long long size, unsigned long long stride, int active) {
  unsigned long long k=(unsigned long long)blockDim.x*blockIdx.x+threadIdx.x;
  if(k>=size)return;
  unsigned long long low=k%stride, high=active?k/(2*stride):k/stride;
  unsigned long long base=high*2*stride+low;
  int a=src[base],b=src[base+stride];
  int v=active?2*(int)((k/stride)%2)-1:0;
  dst[k]=(short)max(a+2*v,b-2*v);
}
'''


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n')


def validate(a):
    n=len(a);assert a.shape==(n,n) and np.array_equal(a,a.T) and np.all(np.diag(a)==0)
    assert np.all(np.abs(a[np.triu_indices(n,1)])==1)


def boolean_states(n):
    masks=np.arange(1<<n,dtype=np.uint32)
    return 1-2*((masks[:,None]>>np.arange(n))&1).astype(np.int64)


class Engine:
    def __init__(self):
        self.kernels={name:cp.RawKernel(CUDA,name) for name in ('energy','expand','contract','restricted')}

    def launch(self,name,args,size):
        self.kernels[name](((int(size)+255)//256,),(256,),args)

    def q(self,a):
        n=len(a);validate(a);assert 2<=n<=21
        out=cp.empty(1<<n,dtype=cp.int16);ag=cp.asarray(a,dtype=cp.int8)
        self.launch('energy',(ag,out,np.int32(n),np.uint64(len(out))),len(out))
        cp.cuda.get_current_stream().synchronize();return out

    def transform(self,initial,n,retain_full=False):
        assert 2<=n<=19
        current=initial.copy();stride=1
        for _ in range(n):
            size=len(current)//2*3;new=cp.empty(size,dtype=cp.int16)
            self.launch('expand',(current,new,np.uint64(size),np.uint64(stride)),size)
            cp.cuda.get_current_stream().synchronize();del current
            cp.get_default_memory_pool().free_all_blocks();current=new;stride*=3
        full=cp.asnumpy(current) if retain_full else None
        stride=1
        for _ in range(n):
            size=len(current)//3*2;new=cp.empty(size,dtype=cp.int16)
            self.launch('contract',(current,new,np.uint64(size),np.uint64(stride)),size)
            cp.cuda.get_current_stream().synchronize();del current
            cp.get_default_memory_pool().free_all_blocks();current=new;stride*=2
        answer=cp.asnumpy(current);del current,new
        cp.get_default_memory_pool().free_all_blocks();return answer,full

    def recover(self,initial,n,support,expected):
        current=initial.copy();stride=1;coordinates=[]
        for i in range(n):
            active=(support>>i)&1;size=len(current) if active else len(current)//2
            new=cp.empty(size,dtype=cp.int16)
            self.launch('restricted',(current,new,np.uint64(size),np.uint64(stride),np.int32(active)),size)
            cp.cuda.get_current_stream().synchronize();del current
            cp.get_default_memory_pool().free_all_blocks();current=new
            if active:coordinates.append(i);stride*=2
        code=int(cp.argmin(current));assert int(current[code])==expected
        v=np.zeros(n,dtype=np.int64)
        for j,i in enumerate(coordinates):v[i]=2*((code>>j)&1)-1
        ternary_code=sum(int(v[i]+1)*3**i for i in range(n))
        return v,ternary_code

    def optimize(self,a,retain_full=False):
        started=time.time();n=len(a);assert 2<=n<=19;q=self.q(a);tables=[];fulls=[];timings=[]
        for sign in (1,-1):
            begun=time.time();initial=cp.abs(q.astype(cp.int32)+sign).astype(cp.int16)
            table,full=self.transform(initial,n,retain_full);tables.append(table);fulls.append(full)
            timings.append(time.time()-begun);del initial
        mask=(1<<n)-1;values=np.maximum(tables[0],tables[1][np.arange(1<<n)^mask])
        support=int(np.argmin(values));optimum=int(values[support])
        vp,ap=self.recover(cp.abs(q.astype(cp.int32)+1).astype(cp.int16),n,support,int(tables[0][support]))
        vm,am=self.recover(cp.abs(q.astype(cp.int32)-1).astype(cp.int16),n,mask^support,int(tables[1][mask^support]))
        b=vp+vm;c=vp-vm;assert np.all(np.abs(b)==1) and np.all(np.abs(c)==1)
        first=np.zeros((n+1,n+1),dtype=np.int64);first[:n,:n]=a;first[:n,n]=b;first[n,:n]=b
        second=np.zeros((n+2,n+2),dtype=np.int64);second[:n+1,:n+1]=first
        second[:n,n+1]=c;second[n+1,:n]=c;second[n,n+1]=second[n+1,n]=1
        assert int(cp.max(cp.abs(self.q(second))))==optimum
        return dict(n=n,minimum=optimum,support=support,arg_plus=ap,arg_minus=am,b=b,c=c,
                    U_plus=tables[0],U_minus=tables[1],full_plus=fulls[0],full_minus=fulls[1],
                    first=first,second=second,source_phi=int(cp.max(cp.abs(q))),
                    sign_seconds=timings,elapsed=time.time()-started)


def write_matrix(path,a):
    path.write_text(str(len(a))+'\n'+'\n'.join(' '.join(map(str,row)) for row in a)+'\n')


def verify(verifier,path,a):
    write_matrix(path,a)
    record=json.loads(subprocess.check_output([str(verifier),str(path)],text=True))
    assert record['n']==len(a) and record['checks']=='PASS';return record


def match_ancestry_nodes(value,a,phi):
    upper=''.join('1' if z>0 else '0' for z in a[np.triu_indices(len(a),1)])
    found=[]
    def visit(item):
        if isinstance(item,dict):
            if item.get('n')==len(a) and item.get('upper')==upper:
                assert item.get('phi')==phi;found.append(item.get('id'))
            for child in item.values():visit(child)
        elif isinstance(item,list):
            for child in item:visit(child)
    visit(value);assert found,'supplied ancestry does not contain the exact source matrix and norm'
    return found


def selftest(engine,verifier,output):
    rng=np.random.default_rng(2026090619);records=[]
    for n in (2,3,4,5):
        a=np.triu(rng.choice([-1,1],(n,n)),1);a+=a.T
        s=boolean_states(n);q=np.sum((s@a)*s,axis=1)//2
        assert np.array_equal(cp.asnumpy(engine.q(a)),q)
        result=engine.optimize(a,retain_full=True)
        for sign,full,table in ((1,result['full_plus'],result['U_plus']),(-1,result['full_minus'],result['U_minus'])):
            expected=np.full(1<<n,32767,dtype=np.int64)
            for code in range(3**n):
                v=np.asarray([(code//3**i)%3-1 for i in range(n)],dtype=np.int64)
                value=int(np.max(np.abs(q+sign)+2*(s@v)))
                assert value==int(full[code])
                support=sum((1<<i) for i in range(n) if v[i])
                expected[support]=min(expected[support],value)
            assert np.array_equal(table,expected)
        final=verify(verifier,output/f'selftest_n{n}_second.txt',result['second'])
        assert final['phi']==result['minimum']
        records.append(dict(n=n,all_signed_ternary_costs_checked=2*3**n,all_support_costs_checked=2*(1<<n),minimum=result['minimum']))
    upper='1101011101110011110111111110101110110101001110010001001';n=11
    a=np.zeros((n,n),dtype=np.int64);a[np.triu_indices(n,1)]=[1 if z=='1' else -1 for z in upper];a+=a.T
    result=engine.optimize(a);assert result['source_phi']==17 and result['minimum']==22
    first=verify(verifier,output/'fixed11_first.txt',result['first'])
    second=verify(verifier,output/'fixed11_second.txt',result['second']);assert second['phi']==22
    records.append(dict(n=11,source_phi=17,minimum=22,first_phi=first['phi'],old_complete_two_step_crosscheck='PASS'))
    return records


def main():
    p=argparse.ArgumentParser();p.add_argument('--matrix',type=Path);p.add_argument('--ancestry',type=Path)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--verifier-source',type=Path,required=True)
    p.add_argument('--reference-supports',type=Path);p.add_argument('--selftest-only',action='store_true');args=p.parse_args()
    assert args.selftest_only or args.matrix is not None
    assert sha(args.verifier_source)=='384cc06d03ddcb18579df9b5cff4ba356c85737a23e9cc3dffdaa28a3224539c'
    args.output.mkdir(parents=True,exist_ok=False);verifier=args.output/'field_verify'
    subprocess.run(['g++','-O3','-std=c++17',str(args.verifier_source),'-o',str(verifier)],check=True)
    engine=Engine();tests=selftest(engine,verifier,args.output)
    dump(args.output/'validation.json',dict(status='PASS',tests=tests,script_sha256=sha(__file__),
        verifier_source_sha256=sha(args.verifier_source),verifier_binary_sha256=sha(verifier)))
    if args.selftest_only:return
    tokens=list(map(int,args.matrix.read_text().split()));n=tokens[0];assert 2<=n<=19 and len(tokens)==1+n*n
    a=np.asarray(tokens[1:],dtype=np.int64).reshape(n,n);validate(a)
    source=verify(verifier,args.output/'source.txt',a);result=engine.optimize(a)
    assert source['phi']==result['source_phi']
    ancestry=json.loads(args.ancestry.read_text()) if args.ancestry else None
    ancestry_source_ids=match_ancestry_nodes(ancestry,a,source['phi']) if ancestry is not None else []
    if args.reference_supports:
        records=[json.loads(line) for line in args.reference_supports.read_text().splitlines() if line]
        assert len(records)==1<<n and {r['support'] for r in records}==set(range(1<<n))
        for record in records:
            s=record['support'];assert record['u_plus']==int(result['U_plus'][s]) and record['u_minus']==int(result['U_minus'][s])
        chosen=next(r for r in records if r['support']==result['support'])
        complement=next(r for r in records if r['support']==((1<<n)-1)^result['support'])
        assert result['arg_plus']==chosen['arg_plus'] and result['arg_minus']==complement['arg_minus']
    np.savez_compressed(args.output/'support_optima.npz',U_plus=result['U_plus'],U_minus=result['U_minus'])
    raw_first=verify(verifier,args.output/'raw_first.txt',result['first'])
    raw_second=verify(verifier,args.output/'raw_second.txt',result['second']);assert raw_second['phi']==result['minimum']
    alt=result['first'].copy();alt[:n,n]=result['c'];alt[n,:n]=result['c']
    alternative=verify(verifier,args.output/'alternative_first.txt',alt)
    swap=alternative['phi']<raw_first['phi']
    first=alt if swap else result['first'];second=result['second']
    if swap:
        order=list(range(n))+[n+1,n];second=second[np.ix_(order,order)]
    final_first_record=alternative if swap else raw_first
    final_endpoint_record=verify(verifier,args.output/'swapped_second.txt',second) if swap else raw_second
    assert final_endpoint_record['phi']==result['minimum']
    assert np.array_equal(first[:n,:n],a) and np.array_equal(second[:n+1,:n+1],first)
    write_matrix(args.output/'first.txt',first);write_matrix(args.output/'second.txt',second)
    phis=[source['phi'],min(raw_first['phi'],alternative['phi']),raw_second['phi']]
    alphas=[value/order**1.5 for order,value in zip((n,n+1,n+2),phis,strict=True)]
    report=dict(status='EXACT_COMPLETE_TWO_VERTEX_ENDPOINT_OPTIMUM',n=n,orders=[n,n+1,n+2],phis=phis,
        alphas=alphas,max_normalized_drift=max(0,max(alphas)-alphas[0]),growth_moves=2,
        matrix_input_sha256=sha(args.matrix),source_matrix=a.tolist(),first_matrix=first.tolist(),second_matrix=second.tolist(),
        source_ancestry=ancestry,exact_matching_ancestry_source_ids=ancestry_source_ids,
        source_ancestry_sha256=sha(args.ancestry) if args.ancestry else None,
        support=result['support'],arg_plus=result['arg_plus'],arg_minus=result['arg_minus'],d=1,
        swapped_new_vertex_order=swap,intermediate_choice_scope='better of two orders for one recovered endpoint only',
        endpoint_optimum=result['minimum'],support_count=1<<n,ternary_costs_per_sign=3**n,
        full_labeled_two_extension_family=1<<(2*n+1),sign_seconds=result['sign_seconds'],GPU_seconds=result['elapsed'],
        integer_field_verifier_records=dict(source=source,first=final_first_record,endpoint=final_endpoint_record,
            raw_first=raw_first,alternative_first=alternative,raw_endpoint=raw_second),
        script_sha256=sha(__file__),verifier_source_sha256=sha(args.verifier_source),verifier_binary_sha256=sha(verifier),
        support_archive_sha256=sha(args.output/'support_optima.npz'),
        reference_supports_sha256=sha(args.reference_supports) if args.reference_supports else None,
        classification='finite complete endpoint optimum and actual two-step growth; not an asymptotic norm bound')
    dump(args.output/'result.json',report)
    print(json.dumps({k:report[k] for k in ('status','orders','phis','max_normalized_drift','support','swapped_new_vertex_order','GPU_seconds')}),flush=True)


if __name__=='__main__':main()
