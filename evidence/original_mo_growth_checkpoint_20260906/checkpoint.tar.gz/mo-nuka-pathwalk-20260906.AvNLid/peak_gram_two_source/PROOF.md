# Weighted Gram certificates for two-vertex extension obstructions

2026-09-06. Finite, source-specific sufficient obstructions. These do not
prove a uniform order comparison or convergence, and failure of a
certificate does not produce an extension.

## Exact starting identity

Let A be a complete symmetric zero-diagonal signing of order n and
Q(x)=x^T A x/2. A complete two-vertex extension has incident columns b,c
and joining sign d. Switching only the last vertex permits d=+1 without
changing A, its first extension, or the final norm. Put

    s=(b+c)/2, t=(b-c)/2.

Thus s,t are signed ternary vectors with disjoint complementary supports:
s_i^2+t_i^2=1 for every i. Conversely every such pair defines b=s+t,c=s-t.
Maximizing over the two added spins and then using Q(-x)=Q(x) gives

    Phi(extension)
      = max_x max( |Q(x)+1|+2|s.x|, |Q(x)-1|+2|t.x| ).       (1)

For a proposed integer bound T, every extension of norm at most T must
therefore satisfy, for every old state x,

    |s.x| <= (T-|Q(x)+1|)/2,
    |t.x| <= (T-|Q(x)-1|)/2.                              (2)

## Parity-specific bounds

Fix r=|supp(s)| modulo 2. Since all nonzero summands are signs,
s.x is an integer congruent to r modulo 2, while t.x is congruent to
n-r modulo 2. Write a_r(q) for the largest nonnegative integer of parity
r below (T-|q+1|)/2, and b_r(q) for the analogous integer of parity
n-r below (T-|q-1|)/2. If either set is empty for an actual state x,
that parity branch is already impossible. Otherwise (2) implies

    (s.x)^2 <= a_r(Q(x))^2,
    (t.x)^2 <= b_r(Q(x))^2.                              (3)

To exclude all extensions one must exclude BOTH parity branches, possibly
using different witnesses and certificates. No unobserved signed energy
level may be inserted. In particular, for odd n all Q(x) have the same
residue modulo 4: a single spin flip changes Q by a multiple of 4.

## A single weighted frame

Select any old states x and nonnegative weights w_x. Define

    W = sum_x w_x x x^T,
    B = sum_x w_x [a_r(Q(x))^2+b_r(Q(x))^2].

Then (3) implies s^T W s+t^T W t <= B. If n W-B I is positive
definite, its positive quadratic forms on s,t give instead

    n(s^T W s+t^T W t) > B(||s||^2+||t||^2)=Bn,

because ||s||^2+||t||^2=n>0. This is a contradiction. Hence strict positive
definiteness excludes this parity branch. Projective representatives are
sufficient: x and -x have the same Q and outer product.

For one fixed positive level Q=M, ignoring the parity improvement gives
a=floor((T-|M+1|)/2), b=floor((T-|M-1|)/2), provided both are nonnegative.
If r_peak selected projective states have integer Gram sum H, the exact
test becomes positive definiteness of

    n H-r_peak(a^2+b^2) I.                               (4)

For n=19,T=44,M=39,41,43 the unrefined squared caps are respectively
13,5,1. The support-parity refinements for positive M are:

    M=39: even support gives 13; odd support gives 5.
    M=41: even support gives 1;  odd support gives 5.
    M=43: even support gives 1;  odd support is impossible.

For negative M exchange the roles of s and t. These are conditional
statements about actual levels, not claims that both signs occur.

## Stronger diagonal dual

The same argument permits different nonnegative weights u_x,v_x for
the two inequalities in (3). Set

    W_s=sum_x u_x x x^T, B_s=sum_x u_x a_r(Q(x))^2,
    W_t=sum_x v_x x x^T, B_t=sum_x v_x b_r(Q(x))^2.

If a real diagonal matrix D satisfies

    W_s-D positive semidefinite,
    W_t-D positive semidefinite,
    tr(D)>B_s+B_t,                                      (5)

then s^T W_s s+t^T W_t t >= s^T D s+t^T D t=tr(D), since
s_i^2+t_i^2=1 coordinatewise. This contradicts (3), so (5) excludes
the branch. There is no requirement that D itself be positive or scalar.
Using a common scalar diagonal recovers the single-frame criterion.
Aggregating states of the same signed energy is allowed by summing their
outer products with an explicitly specified common weight.

## Certification and scope

For rational weights, all matrices and scalar comparisons above can be
checked exactly. Strict positive definiteness of a symmetric rational
matrix is certified by an exact LDL^T factorization with all positive
diagonal pivots (equivalently positive leading principal minors).
Positive semidefiniteness in (5) requires an exact PSD certificate, not
an approximate nonnegative numerical eigenvalue. A numerical search may
suggest weights, but cannot replace the rational certificate.

These tests need not use all states: any explicitly checked subset gives
a valid obstruction. Exhaustive state enumeration is useful for finding
witnesses but is not a hypothesis of the proof. A successful construction
of norm at most T necessarily defeats every valid obstruction above;
it is therefore a useful implementation control. Switching and coordinate
permutation carry every certificate covariantly to the equivalent source.
No source is claimed impossible unless both parity branches are actually
excluded. There is no converse to either sufficient certificate.
