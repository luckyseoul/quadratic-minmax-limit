#!/usr/bin/env python3
"""Two frozen A19 inputs, exact finite Gram obstruction diagnostics only.

Only the reviewed CUDA energy table is called: no ternary optimization,
new signing search, SDP, source expansion, or incoming ancestry invention.
Each selected projective row is also evaluated directly on the CPU, so a
successful rational Gram certificate does not trust table completeness.
"""
import argparse
from fractions import Fraction
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import numpy as np

ENGINE_SHA = '219af9a224ea5e04d035a005470da0de8584ffaeb2967cb2ef12428fed14fcdf'
PROOF_SHA = '88a6507deec5a8313aee7ef0fe31c3d2972d606b4d2bf98194fb4d7b735aac59'
INPUTS = (
    dict(name='soul_68004', matrix='bounded_grown19_v100/source_00_soul_68004/source.txt',
         receipt='bounded_grown19_v100/source_00_soul_68004/result.json',
         matrix_sha='6ad2f09dae47f7e021b0717a0a9398cd649063b0c897e950ffe79fc615259963',
         receipt_sha='6c3e4069ba297d56a84a5d2d848a74aff154661369c9a44ea9f408e4bfefae90',
         expected_phi=39, expected_levels=(-37,39)),
    dict(name='reverse21_restriction19', matrix='reverse21_control/restriction19.txt',
         receipt='reverse21_control/preparation.json',
         matrix_sha='40eb02857299421f23b2ef6d67a75fdc00e1afb65aa26fc6091ef54cb43b60ba',
         receipt_sha='7daf11e526a41d74dd6f523c92b1b67044c25d0eba89a25cf03327e35dd6d497',
         expected_phi=41, expected_levels=(-39,41)),
)
N = 19
TARGET = 44


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def exact_ldl(matrix):
    """Strict PD with reconstruction, or exact nonpositive quadratic witness."""
    n = len(matrix)
    m = [[Fraction(int(z)) for z in row] for row in matrix]
    assert all(m[i][j] == m[j][i] for i in range(n) for j in range(n))
    lower = [[Fraction(i == j) for j in range(n)] for i in range(n)]
    diagonal = []
    for j in range(n):
        pivot = m[j][j] - sum(lower[j][k] ** 2 * diagonal[k] for k in range(j))
        diagonal.append(pivot)
        if pivot <= 0:
            witness = [Fraction(0) for _ in range(n)]
            witness[j] = Fraction(1)
            for i in range(j - 1, -1, -1):
                witness[i] = -sum(lower[k][i] * witness[k] for k in range(i + 1, j + 1))
            quadratic = sum(witness[i] * m[i][k] * witness[k]
                            for i in range(n) for k in range(n))
            assert quadratic == pivot and any(witness)
            return dict(positive_definite=False, first_nonpositive_pivot_index=j,
                        pivots=[str(z) for z in diagonal],
                        nonpositive_witness=[str(z) for z in witness],
                        witness_quadratic_form=str(quadratic), exact_verification='PASS')
        for i in range(j + 1, n):
            lower[i][j] = (m[i][j] - sum(lower[i][k] * diagonal[k] * lower[j][k]
                                       for k in range(j))) / pivot
    assert all(sum(lower[i][k] * diagonal[k] * lower[j][k] for k in range(n)) == m[i][j]
               for i in range(n) for j in range(n))
    return dict(positive_definite=True, pivots=[str(z) for z in diagonal],
                lower_triangular=[[str(z) for z in row] for row in lower],
                exact_verification='PASS')


def caps(q, parity):
    assert parity in (0, 1)
    raw_a = (TARGET - abs(q + 1)) // 2
    raw_b = (TARGET - abs(q - 1)) // 2
    a = raw_a - ((raw_a - parity) % 2)
    b = raw_b - ((raw_b - ((N - parity) % 2)) % 2)
    return dict(a=a, b=b, impossible=a < 0 or b < 0,
                squared_sum=None if a < 0 or b < 0 else a * a + b * b)


def selftest():
    assert exact_ldl([[2,1],[1,2]])['positive_definite']
    for matrix in ([[1,1],[1,1]], [[1,2],[2,1]], [[0,1],[1,0]], [[-1]]):
        assert not exact_ldl(matrix)['positive_definite']
    assert [caps(39,p)['squared_sum'] for p in (0,1)] == [13,5]
    assert [caps(41,p)['squared_sum'] for p in (0,1)] == [1,5]
    assert caps(43,0)['squared_sum'] == 1 and caps(43,1)['impossible']
    for q in range(-43,44,2):
        for parity in (0,1):
            item = caps(q,parity)
            feasible_a = [z for z in range(N+1) if z % 2 == parity
                          and 2*z + abs(q+1) <= TARGET]
            feasible_b = [z for z in range(N+1) if z % 2 == (N-parity) % 2
                          and 2*z + abs(q-1) <= TARGET]
            assert item['impossible'] == (not feasible_a or not feasible_b)
            if not item['impossible']:
                # Bounds may exceed support size but are safely loose.
                assert item['a'] >= max(feasible_a) and item['b'] >= max(feasible_b)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--engine', type=Path, required=True)
    parser.add_argument('--proof', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert sha(args.engine) == ENGINE_SHA and sha(args.proof) == PROOF_SHA
    selftest()
    spec = importlib.util.spec_from_file_location('reviewed_energy', args.engine)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    engine = module.Engine()
    args.output.mkdir(parents=True, exist_ok=False)
    for origin, name in ((Path(__file__),'driver.py'), (args.engine,'engine.py'), (args.proof,'PROOF.md')):
        shutil.copy2(origin, args.output / name)
    records = []
    for source in INPUTS:
        matrix_path = args.root / source['matrix']
        receipt_path = args.root / source['receipt']
        assert sha(matrix_path) == source['matrix_sha'] and sha(receipt_path) == source['receipt_sha']
        tokens = list(map(int, matrix_path.read_text().split()))
        assert tokens[0] == N and len(tokens) == 1+N*N
        a = np.asarray(tokens[1:], dtype=np.int64).reshape(N,N)
        module.validate(a)
        retained = json.loads(receipt_path.read_text())
        if source['name'] == 'soul_68004':
            receipt = retained['integer_field_verifier_records']['source']
            assert retained['source_id'] == source['name'] and retained['endpoint_optimum'] == 48
            assert retained['source_input_sha256'] == source['matrix_sha']
            assert np.array_equal(a, retained['source_matrix'])
        else:
            receipt = retained['restricted_field_receipt']
            assert retained['restriction_is_growth'] is False and retained['incoming_construction_ancestry'] is None
            assert retained['known_two_extension_upper_bound'] == 44
            assert retained['restricted_input_sha256'] == source['matrix_sha']
            assert np.array_equal(a, retained['restricted_matrix'])
        assert receipt['n'] == N and receipt['states'] == 1 << (N-1) and receipt['checks'] == 'PASS'
        assert receipt['phi'] == source['expected_phi']
        assert (receipt['min_q'],receipt['max_q']) == source['expected_levels']
        q_device = engine.q(a)
        q = module.cp.asnumpy(q_device).astype(np.int64)
        del q_device
        module.cp.get_default_memory_pool().free_all_blocks()
        assert q.shape == (1 << N,)
        assert np.array_equal(q, q[::-1])  # Complemented masks are antipodal.
        projective = q[::2]  # x_0=+1, matching independent field verifier.
        histogram = [[int(v),int(c)] for v,c in zip(*np.unique(projective, return_counts=True))]
        assert histogram == receipt['histogram']
        assert int(projective.sum()) == receipt['sum_q'] == 0
        assert int(projective @ projective) == receipt['sum_q2']
        assert int(q[receipt['min_witness_mask']]) == receipt['min_q']
        assert int(q[receipt['max_witness_mask']]) == receipt['max_q']
        assert len(set(int(z) % 4 for z in np.unique(q))) == 1
        levels = [receipt['max_q'],receipt['min_q']]
        peak = max(levels, key=abs)
        assert abs(levels[0]) != abs(levels[1])
        level_records = []
        for level in levels:
            masks = (2*np.flatnonzero(projective == level)).astype(np.int64)
            x = 1-2*((masks[:,None] >> np.arange(N)) & 1)
            direct_q = np.sum((x @ a)*x, axis=1)//2
            assert np.all(direct_q == level)
            h = x.T @ x
            assert np.all(np.diag(h) == len(masks))
            level_records.append(dict(q=level, projective_count=len(masks), masks=masks.tolist(),
                                      gram_sum=h.tolist(), direct_cpu_rows='PASS',
                                      parity_caps=[caps(level,p) for p in (0,1)]))
        cases = []
        for family, selected_levels in (('absolute_peak_only',[peak]),('both_actual_extremes',levels)):
            selected = [row for row in level_records if row['q'] in selected_levels]
            h = np.sum([np.asarray(row['gram_sum'],dtype=np.int64) for row in selected],axis=0)
            count = sum(row['projective_count'] for row in selected)
            for parity in (0,1):
                impossible = any(row['parity_caps'][parity]['impossible'] for row in selected)
                if impossible:
                    cases.append(dict(family=family, levels=selected_levels, support_parity=parity,
                                      branch_excluded=True, reason='actual_state_parity_bound_empty'))
                    continue
                bound = sum(row['projective_count']*row['parity_caps'][parity]['squared_sum'] for row in selected)
                matrix = N*h-bound*np.eye(N,dtype=np.int64)
                certificate = exact_ldl(matrix.tolist())
                cases.append(dict(family=family, levels=selected_levels, support_parity=parity,
                                  frame_weights='one per selected projective state', row_count=count,
                                  bound_B=bound, exact_test_matrix=matrix.tolist(), certificate=certificate,
                                  branch_excluded=certificate['positive_definite'],
                                  approximate_min_eigenvalue_test_matrix=float(np.linalg.eigvalsh(matrix.astype(float))[0]),
                                  approximate_min_eigenvalue_normalized_gram=float(np.linalg.eigvalsh(h.astype(float)/count)[0]),
                                  approximate_eigenvalues_are_not_certificates=True))
        excluded = [any(case['support_parity'] == p and case['branch_excluded'] for case in cases) for p in (0,1)]
        if source['name'] == 'reverse21_restriction19':
            # The retained original two rows are a real endpoint<=44 witness.
            assert not all(excluded), 'false obstruction against constructive positive control'
        record = dict(source_name=source['name'], n=N, target=TARGET, source_phi=receipt['phi'],
                      source_matrix=a.tolist(), source_matrix_sha256=source['matrix_sha'],
                      retained_receipt_sha256=source['receipt_sha'], complete_field_receipt=receipt,
                      energy_table_projective_histogram_match='PASS', selected_levels=level_records,
                      cases=cases, parity_branches_excluded=excluded,
                      all_two_extensions_at_target_excluded=all(excluded),
                      classification='finite sufficient obstruction if both parities excluded; no converse or growth bridge')
        directory = args.output/source['name']
        directory.mkdir()
        shutil.copy2(matrix_path,directory/'source.txt')
        shutil.copy2(receipt_path,directory/'retained_receipt.json')
        dump(directory/'result.json',record)
        records.append(dict(source=source['name'], result_sha256=sha(directory/'result.json'),
                            parity_branches_excluded=excluded,
                            all_two_extensions_at_target_excluded=all(excluded),
                            cases=[{k:case[k] for k in ('family','support_parity','branch_excluded')} for case in cases]))
        print(json.dumps(records[-1]),flush=True)
    dump(args.output/'result.json',dict(status='COMPLETED_BOUNDED_TWO_SOURCE_GRAM_DIAGNOSTIC',
         sources=records, driver_sha256=sha(__file__), reviewed_energy_engine_sha256=ENGINE_SHA,
         proof_sha256=PROOF_SHA, energy_calls=2, endpoint_optimizer_calls=0,
         new_signing_searches=0, SDP_searches=0, no_asymptotic_claim=True))


if __name__ == '__main__':
    main()
