"""Exact two-vertex endpoint optimizer with integer OpenCL transforms.

All Boolean states and ternary assignments are covered. Support contraction
is an exact min elimination, not an atomic sampling scheme. This certifies
one finite fixed-source endpoint optimum, not an asymptotic norm bound.
"""
import argparse, hashlib, json, subprocess, time
from pathlib import Path
import numpy as np
import pyopencl as cl

VERIFIER_SHA='384cc06d03ddcb18579df9b5cff4ba356c85737a23e9cc3dffdaa28a3224539c'
KERNEL=r'''
__kernel void energy(__global const char *a,__global short *out,int n,ulong size) {
  ulong k=get_global_id(0); if(k>=size)return; int value=0;
  for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)
    value+=(int)a[i*n+j]*(1-2*(int)((k>>i)&1ul))*(1-2*(int)((k>>j)&1ul));
  out[k]=(short)value;
}
__kernel void initialize(__global const short *q,__global short *out,ulong size,int sign) {
  ulong k=get_global_id(0); if(k<size)out[k]=(short)abs((int)q[k]+sign);
}
__kernel void expand(__global const short *src,__global short *dst,ulong size,ulong stride) {
  ulong k=get_global_id(0); if(k>=size)return;
  ulong low=k%stride,digit=(k/stride)%3ul,high=k/(3ul*stride),base=high*2ul*stride+low;
  int a=src[base],b=src[base+stride],v=(int)digit-1;
  dst[k]=(short)max(a+2*v,b-2*v);
}
__kernel void contract(__global const short *src,__global short *dst,ulong size,ulong stride) {
  ulong k=get_global_id(0); if(k>=size)return;
  ulong low=k%stride,digit=(k/stride)%2ul,high=k/(2ul*stride),base=high*3ul*stride+low;
  dst[k]=digit?min(src[base],src[base+2ul*stride]):src[base+stride];
}
__kernel void restricted(__global const short *src,__global short *dst,ulong size,ulong stride,int active) {
  ulong k=get_global_id(0); if(k>=size)return;
  ulong low=k%stride,high=active?k/(2ul*stride):k/stride,base=high*2ul*stride+low;
  int v=active?2*(int)((k/stride)%2ul)-1:0;
  dst[k]=(short)max((int)src[base]+2*v,(int)src[base+stride]-2*v);
}
__kernel void gather(__global const short *src,__global const ulong *indices,__global short *out,ulong size) {
  ulong k=get_global_id(0); if(k<size)out[k]=src[indices[k]];
}
'''

def sha(filename): return hashlib.sha256(Path(filename).read_bytes()).hexdigest()
def dump(filename,value): Path(filename).write_text(json.dumps(value,indent=2)+'\n')
def validate(a):
    n=len(a); assert a.shape==(n,n) and np.array_equal(a,a.T) and np.all(np.diag(a)==0)
    assert np.all(np.abs(a[np.triu_indices(n,1)])==1)
def states(n):
    masks=np.arange(1<<n,dtype=np.uint32)
    return 1-2*((masks[:,None]>>np.arange(n))&1).astype(np.int64)
def upper(a): return ''.join('1' if z>0 else '0' for z in a[np.triu_indices(len(a),1)])
def write_matrix(filename,a):
    Path(filename).write_text(str(len(a))+'\n'+'\n'.join(' '.join(map(str,row)) for row in a)+'\n')

class Array:
    def __init__(self,buffer,size): self.buffer=buffer; self.size=int(size)
    def release(self): self.buffer.release()

class Engine:
    def __init__(self,device_filter):
        device=next(d for p in cl.get_platforms() for d in p.get_devices()
                    if d.type&cl.device_type.GPU and device_filter in d.name)
        assert device.address_bits==64 and device.endian_little
        self.device=device; self.ctx=cl.Context([device])
        self.queue=cl.CommandQueue(self.ctx,properties=cl.command_queue_properties.PROFILING_ENABLE)
        program=cl.Program(self.ctx,KERNEL).build()
        self.kernels={name:getattr(program,name) for name in ['energy','initialize','expand','contract','restricted','gather']}
        self.events=[]
    def empty(self,size):
        assert 0<int(size)*2<=self.device.max_mem_alloc_size
        return Array(cl.Buffer(self.ctx,cl.mem_flags.READ_WRITE,int(size)*2),size)
    def launch(self,name,size,*args):
        size=int(size); event=self.kernels[name](self.queue,(((size+255)//256)*256,),(256,),*args)
        event.wait(); self.events.append({'kernel':name,'items':size,'GPU_seconds':(event.profile.end-event.profile.start)*1e-9})
    def download(self,array):
        out=np.empty(array.size,dtype=np.int16); cl.enqueue_copy(self.queue,out,array.buffer).wait(); return out
    def clone(self,array):
        out=self.empty(array.size); cl.enqueue_copy(self.queue,out.buffer,array.buffer,byte_count=array.size*2).wait(); return out
    def q(self,a):
        validate(a); n=len(a); assert 2<=n<=22 and n*(n-1)//2<32767
        ag=cl.Buffer(self.ctx,cl.mem_flags.READ_ONLY|cl.mem_flags.COPY_HOST_PTR,hostbuf=np.asarray(a,dtype=np.int8))
        out=self.empty(1<<n); self.launch('energy',out.size,ag,out.buffer,np.int32(n),np.uint64(out.size)); ag.release(); return out
    def initial(self,q,sign):
        assert sign in [-1,1]; out=self.empty(q.size)
        self.launch('initialize',out.size,q.buffer,out.buffer,np.uint64(out.size),np.int32(sign)); return out
    def sample(self,array,indices):
        indices=np.asarray(indices,dtype=np.uint64); assert np.all(indices<array.size)
        ib=cl.Buffer(self.ctx,cl.mem_flags.READ_ONLY|cl.mem_flags.COPY_HOST_PTR,hostbuf=indices)
        out=self.empty(len(indices)); self.launch('gather',out.size,array.buffer,ib,out.buffer,np.uint64(out.size))
        answer=self.download(out); out.release(); ib.release(); return answer
    def transform(self,initial,n,retain_full=False,sample_indices=None):
        assert 2<=n<=20 and initial.size==1<<n and (not retain_full or n<=8)
        assert (n+2)*(n+1)//2<=32767 and 2*3**n<=self.device.max_mem_alloc_size
        peak_bytes=2*(3**n+2*3**(n-1))+16*(1<<n)
        assert peak_bytes<int(self.device.global_mem_size*.85),('memory budget',peak_bytes,self.device.global_mem_size)
        current=self.clone(initial); stride=1
        for _ in range(n):
            size=current.size//2*3; nxt=self.empty(size)
            self.launch('expand',size,current.buffer,nxt.buffer,np.uint64(size),np.uint64(stride))
            current.release(); current=nxt; stride*=3
        full=self.download(current) if retain_full else None
        samples=self.sample(current,sample_indices).tolist() if sample_indices is not None else None
        stride=1
        for _ in range(n):
            size=current.size//3*2; nxt=self.empty(size)
            self.launch('contract',size,current.buffer,nxt.buffer,np.uint64(size),np.uint64(stride))
            current.release(); current=nxt; stride*=2
        table=self.download(current); current.release(); return table,full,samples
    def recover(self,initial,n,support,expected):
        assert 0<=support<1<<n; current=self.clone(initial); stride=1; active_coordinates=[]
        for i in range(n):
            active=(support>>i)&1; size=current.size if active else current.size//2; nxt=self.empty(size)
            self.launch('restricted',size,current.buffer,nxt.buffer,np.uint64(size),np.uint64(stride),np.int32(active))
            current.release(); current=nxt
            if active: active_coordinates.append(i); stride*=2
        values=self.download(current); current.release(); code=int(values.argmin()); assert int(values[code])==expected
        v=np.zeros(n,dtype=np.int64)
        for j,i in enumerate(active_coordinates): v[i]=2*((code>>j)&1)-1
        return v,sum(int(v[i]+1)*3**i for i in range(n))
    def optimize(self,a,retain_full=False):
        begun=time.perf_counter(); n=len(a); assert 2<=n<=20; first_event=len(self.events)
        q=self.q(a); q_cpu=self.download(q); tables=[]; fulls=[]; timings=[]
        for sign in [1,-1]:
            tick=time.perf_counter(); initial=self.initial(q,sign)
            table,full,_=self.transform(initial,n,retain_full); tables.append(table); fulls.append(full); initial.release()
            timings.append(time.perf_counter()-tick)
        mask=(1<<n)-1; objectives=np.maximum(tables[0],tables[1][np.arange(1<<n)^mask])
        support=int(objectives.argmin()); optimum=int(objectives[support]); vectors=[]; codes=[]
        for sign,selected,table in [(1,support,tables[0]),(-1,mask^support,tables[1])]:
            initial=self.initial(q,sign); v,code=self.recover(initial,n,selected,int(table[selected])); initial.release()
            vectors.append(v); codes.append(code)
        q.release(); b=vectors[0]+vectors[1]; c=vectors[0]-vectors[1]
        assert np.all(abs(b)==1) and np.all(abs(c)==1)
        first=np.zeros((n+1,n+1),dtype=np.int64); first[:n,:n]=a; first[:n,n]=first[n,:n]=b
        second=np.zeros((n+2,n+2),dtype=np.int64); second[:n+1,:n+1]=first
        second[:n,n+1]=second[n+1,:n]=c; second[n,n+1]=second[n+1,n]=1
        endpoint_q=self.q(second); assert int(np.max(abs(self.download(endpoint_q))))==optimum; endpoint_q.release()
        return {'n':n,'optimum':optimum,'support':support,'optimal_support_count':int(np.sum(objectives==optimum)),
                'arg_plus':codes[0],'arg_minus':codes[1],'b':b,'c':c,'first':first,'second':second,
                'U_plus':tables[0],'U_minus':tables[1],'full_plus':fulls[0],'full_minus':fulls[1],
                'source_phi':int(np.max(abs(q_cpu))),'sign_seconds':timings,'wall_seconds':time.perf_counter()-begun,
                'GPU_kernel_seconds':sum(e['GPU_seconds'] for e in self.events[first_event:])}

def verify(verifier,filename,a):
    write_matrix(filename,a); record=json.loads(subprocess.check_output([str(verifier),str(filename)],text=True))
    assert record['n']==len(a) and record['checks']=='PASS'; return record

def ancestry_ids(value,a,phi):
    found=[]; encoded=upper(a)
    def visit(item):
        if isinstance(item,dict):
            if item.get('n')==len(a) and item.get('upper')==encoded:
                assert item.get('phi')==phi; found.append(item.get('id'))
            for child in item.values(): visit(child)
        elif isinstance(item,list):
            for child in item: visit(child)
    visit(value); assert found,'exact source matrix and Phi absent from ancestry'; return sorted(set(found))

def selftest(engine,verifier,output):
    rng=np.random.default_rng(2026090620); records=[]
    for n in [2,3,4,5]:
        a=np.triu(rng.choice([-1,1],(n,n)),1); a+=a.T; x=states(n); q=np.sum((x@a)*x,axis=1)//2
        gpu_q=engine.q(a); assert np.array_equal(engine.download(gpu_q),q); gpu_q.release()
        result=engine.optimize(a,retain_full=True)
        for sign,full,table in [(1,result['full_plus'],result['U_plus']),(-1,result['full_minus'],result['U_minus'])]:
            expected=np.full(1<<n,32767,dtype=np.int64)
            for code in range(3**n):
                v=np.asarray([(code//3**i)%3-1 for i in range(n)],dtype=np.int64)
                value=int(np.max(np.abs(q+sign)+2*(x@v))); assert value==int(full[code])
                support=sum(1<<i for i in range(n) if v[i]); expected[support]=min(expected[support],value)
            assert np.array_equal(table,expected)
        if n<=3:
            optimum=32767
            for b in x:
                for c in x:
                    p=x@b; r=x@c
                    for d in [-1,1]:
                        value=max(int(np.max(abs(q+u*p+v*r+d*u*v))) for u in [-1,1] for v in [-1,1])
                        optimum=min(optimum,value)
            assert optimum==result['optimum']
        checked=verify(verifier,output/f'selftest_n{n}.txt',result['second']); assert checked['phi']==result['optimum']
        records.append({'n':n,'all_ternary_and_support_costs':'PASS','endpoint':result['optimum']})
    a=np.ones((16,16),dtype=np.int64); np.fill_diagonal(a,0); q=engine.q(a); initial=engine.initial(q,1)
    table,_,samples=engine.transform(initial,16,sample_indices=[0,3**16-1,(3**16-1)//2]); initial.release(); q.release()
    assert samples==[153,153,121] and int(table[0])==121
    records.append({'n':16,'actual_int16_transform_adversary':'PASS','sample_costs':samples})
    text='1101011101110011110111111110101110110101001110010001001'; a=np.zeros((11,11),dtype=np.int64)
    a[np.triu_indices(11,1)]=[1 if z=='1' else -1 for z in text]; a+=a.T; result=engine.optimize(a)
    assert result['source_phi']==17 and result['optimum']==22
    checked=verify(verifier,output/'selftest_fixed11.txt',result['second']); assert checked['phi']==22
    records.append({'n':11,'known_complete_two_extension_optimum':22,'checks':'PASS'}); return records

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--matrix',type=Path); ap.add_argument('--ancestry',type=Path)
    ap.add_argument('--output',type=Path,required=True); ap.add_argument('--verifier-source',type=Path,required=True)
    ap.add_argument('--device-filter',default='gfx1201'); ap.add_argument('--selftest-only',action='store_true')
    ap.add_argument('--reference-supports',type=Path); ap.add_argument('--reference-npz',type=Path); ap.add_argument('--reference-result',type=Path)
    args=ap.parse_args(); assert args.selftest_only or (args.matrix and args.ancestry)
    assert not (args.reference_supports or args.reference_npz) or args.reference_result
    assert sha(args.verifier_source)==VERIFIER_SHA; args.output.mkdir(parents=True,exist_ok=False)
    verifier=args.output/'field_verify'; subprocess.run(['g++','-O3','-std=c++17',str(args.verifier_source),'-o',str(verifier)],check=True)
    engine=Engine(args.device_filter); tests=selftest(engine,verifier,args.output)
    device={'name':engine.device.name,'global_mem_size':engine.device.global_mem_size,
            'max_mem_alloc_size':engine.device.max_mem_alloc_size,'address_bits':engine.device.address_bits}
    dump(args.output/'validation.json',{'status':'PASS','tests':tests,'source_sha256':sha(__file__),'device':device,
                                      'verifier_source_sha256':sha(args.verifier_source),'verifier_binary_sha256':sha(verifier)})
    if args.selftest_only:
        dump(args.output/'kernel_events.json',engine.events); print(json.dumps({'selftests':'PASS','device':device}),flush=True); return
    tokens=list(map(int,args.matrix.read_text().split())); n=tokens[0]; assert 2<=n<=20 and len(tokens)==1+n*n
    a=np.asarray(tokens[1:],dtype=np.int64).reshape(n,n); validate(a)
    source=verify(verifier,args.output/'source.txt',a); ancestry=json.loads(args.ancestry.read_text())
    matched=ancestry_ids(ancestry,a,source['phi']); result=engine.optimize(a); assert result['source_phi']==source['phi']
    if args.reference_result:
        reference=json.loads(args.reference_result.read_text()); assert reference['n']==n
        if 'source_upper' in reference: assert reference['source_upper']==upper(a)
        else: assert np.array_equal(np.asarray(reference['source_matrix']),a)
    if args.reference_supports:
        rows=[json.loads(line) for line in args.reference_supports.read_text().splitlines() if line]
        assert len(rows)==1<<n and {row['support'] for row in rows}==set(range(1<<n))
        for row in rows:
            s=row['support']; assert row['u_plus']==int(result['U_plus'][s]) and row['u_minus']==int(result['U_minus'][s])
            if s==result['support']: assert row['arg_plus']==result['arg_plus']
            if s==((1<<n)-1)^result['support']: assert row['arg_minus']==result['arg_minus']
    if args.reference_npz:
        with np.load(args.reference_npz) as ref:
            assert np.array_equal(ref['U_plus'],result['U_plus']) and np.array_equal(ref['U_minus'],result['U_minus'])
    np.savez_compressed(args.output/'support_optima.npz',U_plus=result['U_plus'],U_minus=result['U_minus'])
    raw_first=verify(verifier,args.output/'raw_first.txt',result['first'])
    raw_second=verify(verifier,args.output/'raw_second.txt',result['second']); assert raw_second['phi']==result['optimum']
    alternative=result['first'].copy(); alternative[:n,n]=alternative[n,:n]=result['c']
    alt_record=verify(verifier,args.output/'alternative_first.txt',alternative); swap=alt_record['phi']<raw_first['phi']
    first=alternative if swap else result['first']; second=result['second']
    if swap:
        order=list(range(n))+[n+1,n]; second=second[np.ix_(order,order)]
    assert np.array_equal(first[:n,:n],a) and np.array_equal(second[:n+1,:n+1],first)
    final_first=verify(verifier,args.output/'first.txt',first); final_second=verify(verifier,args.output/'second.txt',second)
    assert final_second['phi']==result['optimum']
    phis=[source['phi'],final_first['phi'],final_second['phi']]; alphas=[p/order**1.5 for p,order in zip(phis,[n,n+1,n+2])]
    report={'status':'EXACT_COMPLETE_TWO_VERTEX_ENDPOINT_OPTIMUM','n':n,'orders':[n,n+1,n+2],'phis':phis,'alphas':alphas,
            'local_path_max_alpha':max(alphas),'local_positive_loss':sum(max(0,b-a) for a,b in zip(alphas,alphas[1:])),
            'source_matrix':a.tolist(),'first_matrix':first.tolist(),'second_matrix':second.tolist(),
            'source_ancestry':ancestry,'exact_matching_ancestry_source_ids':matched,'source_ancestry_sha256':sha(args.ancestry),
            'matrix_input_sha256':sha(args.matrix),'source_sha256':sha(__file__),'device':device,
            'support':result['support'],'arg_plus':result['arg_plus'],'arg_minus':result['arg_minus'],'d':1,
            'optimal_support_count':result['optimal_support_count'],'endpoint_optimum':result['optimum'],'growth_moves':2,
            'swapped_new_vertex_order':swap,'intermediate_choice_scope':'better of two orders for one recovered endpoint only',
            'support_count':1<<n,'ternary_costs_per_sign':3**n,'full_labeled_two_extension_family':1<<(2*n+1),
            'sign_seconds':result['sign_seconds'],'wall_seconds':result['wall_seconds'],'GPU_kernel_seconds':result['GPU_kernel_seconds'],
            'integer_field_verifier_records':{'source':source,'raw_first':raw_first,'raw_endpoint':raw_second,
                                             'alternative_first':alt_record,'final_first':final_first,'final_endpoint':final_second},
            'verifier_source_sha256':sha(args.verifier_source),'verifier_binary_sha256':sha(verifier),
            'support_archive_sha256':sha(args.output/'support_optima.npz'),
            'reference_supports_sha256':sha(args.reference_supports) if args.reference_supports else None,
            'reference_npz_sha256':sha(args.reference_npz) if args.reference_npz else None,
            'reference_result_sha256':sha(args.reference_result) if args.reference_result else None,
            'classification':'finite complete endpoint optimum and actual two-step growth; no asymptotic norm claim'}
    dump(args.output/'result.json',report); dump(args.output/'kernel_events.json',engine.events)
    print(json.dumps({key:report[key] for key in ['status','orders','phis','support','wall_seconds','GPU_kernel_seconds']}),flush=True)

if __name__=='__main__': main()
