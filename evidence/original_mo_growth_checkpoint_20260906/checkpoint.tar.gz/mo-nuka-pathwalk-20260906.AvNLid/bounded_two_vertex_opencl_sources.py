"""Explicitly partitioned complete two-addition tests on verified grown A19.

The engine is hash-pinned. Incoming ancestry is retained, not reclassified as
newly proved here. Each new source/first/endpoint norm has an independent
integer verifier receipt. Different parent norms remain separate strata.
"""
import argparse, hashlib, importlib.util, json, shutil, socket, subprocess, time
from pathlib import Path
import numpy as np

ENGINE_SHA='47bc840df817ffac3b72766c3b3d25070ef84f7d34781d7abf3a28d71f3d2ccc'
VERIFIER_SHA='384cc06d03ddcb18579df9b5cff4ba356c85737a23e9cc3dffdaa28a3224539c'
EXPORTER_SHA='2fadcc9430f46e7fff53211432bdb9f31330a7bef27d0cd688ffb3a65b872290'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,value):
    temporary=path.with_suffix('.tmp'); temporary.write_text(json.dumps(value,indent=2)+'\n'); temporary.replace(path)
def upper(a): return ''.join('1' if z>0 else '0' for z in a[np.triu_indices(len(a),1)])
def parent(node): return node.get('parent_id') or None
def graph_nodes(value):
    nodes={}
    def visit(item):
        if isinstance(item,dict):
            if all(key in item for key in ['id','n','upper','phi']):
                key=item['id']; identity=(item['n'],item['upper'],item['phi'],parent(item))
                if key in nodes:
                    old=nodes[key]; assert identity==(old['n'],old['upper'],old['phi'],parent(old))
                else: nodes[key]=item
            for child in item.values(): visit(child)
        elif isinstance(item,list):
            for child in item: visit(child)
    visit(value); return nodes
def root_chain(nodes,identifier):
    result=[]; seen=set()
    while identifier is not None:
        assert identifier not in seen and identifier in nodes,('cyclic or missing ancestry',identifier)
        seen.add(identifier); node=nodes[identifier]; n=int(node['n'])
        assert len(node['upper'])==n*(n-1)//2 and set(node['upper'])<=set('01')
        result.append(node); identifier=parent(node)
    result.reverse(); assert result; return result

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--manifest',type=Path,required=True)
    ap.add_argument('--source-ids',required=True); ap.add_argument('--engine',type=Path,required=True)
    ap.add_argument('--verifier-source',type=Path,required=True); ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--target',type=int,default=44); ap.add_argument('--max-sources',type=int,default=32)
    ap.add_argument('--device-filter',default='gfx1201'); ap.add_argument('--node-prefix',default='nuka_twoadd')
    ap.add_argument('--stop-on-target',action='store_true'); args=ap.parse_args()
    assert sha(args.engine)==ENGINE_SHA and sha(args.verifier_source)==VERIFIER_SHA
    requested=args.source_ids.split(','); assert 0<len(requested)<=args.max_sources<=32 and len(requested)==len(set(requested))
    supplied=json.loads(args.manifest.read_text())
    assert isinstance(supplied,dict) and supplied['exporter_sha256']==EXPORTER_SHA
    rows=supplied['sources']
    indexed={row['id']:row for row in rows}; assert len(indexed)==len(rows) and all(key in indexed for key in requested)
    selected=[indexed[key] for key in requested]; assert all(row['n']==19 and row['phi'] in [39,41,43] for row in selected)
    assert all(row['backend_allocation']=='opencl' for row in selected)
    args.output.mkdir(parents=True,exist_ok=False); started=time.perf_counter()
    spec=importlib.util.spec_from_file_location('reviewed_opencl_engine',args.engine)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    engine=module.Engine(args.device_filter); verifier=args.output/'field_verify'
    subprocess.run(['g++','-O3','-std=c++17',str(args.verifier_source),'-o',str(verifier)],check=True)
    tests=module.selftest(engine,verifier,args.output)
    for source,name in [(args.engine,'engine.py'),(args.verifier_source,'field_verify.cpp'),(Path(__file__),'driver.py'),
                        (args.manifest,'input_manifest.json')]: shutil.copy2(source,args.output/name)
    provenance={'driver_sha256':sha(__file__),'engine_sha256':sha(args.engine),'manifest_sha256':sha(args.manifest),
                'verifier_source_sha256':sha(args.verifier_source),'verifier_binary_sha256':sha(verifier),
                'hostname':socket.gethostname(),'device':engine.device.name,'explicit_source_ids':requested,
                'target':args.target,'selftests':tests,'classification':'bounded complete two-growth source-diversity test'}
    dump(args.output/'manifest.json',provenance); cached={}; raw_signings=set(); prepared=[]
    for row in selected:
        matrix=(args.manifest.parent/row['matrix']).resolve(); ancestry=(args.manifest.parent/row['ancestry']).resolve()
        tokens=list(map(int,matrix.read_text().split())); n=tokens[0]; assert n==19 and len(tokens)==1+n*n
        a=np.asarray(tokens[1:],dtype=np.int64).reshape(n,n); module.validate(a); encoded=upper(a)
        assert sha(matrix)==row['matrix_sha256'] and hashlib.sha256(a.astype(np.int8).tobytes()).hexdigest()==row['matrix_int8_sha256']
        assert sha(ancestry)==row['ancestry_sha256'] and encoded not in raw_signings; raw_signings.add(encoded)
        if str(ancestry) not in cached:
            data=json.loads(ancestry.read_text()); nodes=graph_nodes(data); digest=sha(ancestry)
            retained=args.output/f'ancestry_{digest}.json'
            if not retained.exists(): shutil.copy2(ancestry,retained)
            cached[str(ancestry)]=(nodes,digest,retained)
        nodes,digest,retained=cached[str(ancestry)]; node=nodes[row['id']]
        assert node['n']==n and node['upper']==encoded and node['phi']==row['phi']
        chain=root_chain(nodes,row['id']); assert len(chain)>1 and chain[0]['n']<19
        assert all(node['depth']==depth for depth,node in enumerate(chain))
        move_receipt=row['ancestry_move_receipt']
        assert move_receipt['matrix_transitions_and_path_loss']=='PASS'
        assert move_receipt['source_sha256']==digest and move_receipt['records']==len(chain)
        assert any(v['n']>u['n'] for u,v in zip(chain,chain[1:])), 'source has no actual growth from a smaller root'
        prepared.append((row,matrix,a,chain,digest,retained))
    results=[]
    for index,(row,matrix,a,chain,dag_sha,retained) in enumerate(prepared):
        item=args.output/f'source_{index:02d}_{row["id"]}'; item.mkdir(exist_ok=False); begun=time.perf_counter()
        source=module.verify(verifier,item/'source.txt',a); assert source['phi']==row['phi']
        result=engine.optimize(a); assert result['source_phi']==source['phi']
        raw_first=module.verify(verifier,item/'raw_first.txt',result['first'])
        alternative=result['first'].copy(); alternative[:19,19]=alternative[19,:19]=result['c']
        alternate_receipt=module.verify(verifier,item/'alternative_first.txt',alternative)
        swap=alternate_receipt['phi']<raw_first['phi']; first=alternative if swap else result['first']; second=result['second']
        if swap:
            order=list(range(19))+[20,19]; second=second[np.ix_(order,order)]
        assert np.array_equal(first[:19,:19],a) and np.array_equal(second[:20,:20],first)
        first_receipt=module.verify(verifier,item/'first.txt',first)
        endpoint=module.verify(verifier,item/'second.txt',second); assert endpoint['phi']==result['optimum']
        np.savez_compressed(item/'support_optima.npz',U_plus=result['U_plus'],U_minus=result['U_minus'])
        incoming=[node['phi']/node['n']**1.5 for node in chain]
        alphas=incoming+[first_receipt['phi']/20**1.5,endpoint['phi']/21**1.5]
        old_positive=sum(max(0,v-u) for u,v in zip(incoming,incoming[1:]))
        positive=sum(max(0,v-u) for u,v in zip(alphas,alphas[1:])); added=[]; parent_id=row['id']
        for step,(child,receipt) in enumerate([(first,first_receipt),(second,endpoint)],1):
            identifier=f'{args.node_prefix}_{row["id"]}_add{step}'
            node_alphas=alphas[:len(chain)+step]; witness_is_max=receipt['max_q']>=-receipt['min_q']
            node={'id':identifier,'parent_id':parent_id,'root_id':chain[0]['id'],'n':len(child),'phi':receipt['phi'],
                  'upper':upper(child),'move':'add_vertex','extension_row':child[-1,:-1].tolist(),
                  'root_n':chain[0]['n'],'depth':len(chain)-1+step,'alpha':node_alphas[-1],
                  'path_max_alpha':max(node_alphas),
                  'path_positive_loss':sum(max(0,v-u) for u,v in zip(node_alphas,node_alphas[1:])),
                  'params':''.join('1' if z>0 else '0' for z in child[-1,:-1]),
                  'witness_mask':receipt['max_witness_mask'] if witness_is_max else receipt['min_witness_mask'],
                  'witness_q':receipt['max_q'] if witness_is_max else receipt['min_q'],
                  'peaks':sum(count for q,count in receipt['histogram'] if abs(q)==receipt['phi']),
                  'status':'EXACT_INTEGER_FIELD_VERIFIED','certificate':receipt,'construction_growth':True,'source_DAG_sha256':dag_sha}
            added.append(node); parent_id=identifier
        report={'source_id':row['id'],'root_id':chain[0]['id'],'root_n':chain[0]['n'],'root_phi':chain[0]['phi'],
                'orders':[19,20,21],'phis':[source['phi'],first_receipt['phi'],endpoint['phi']],
                'endpoint_optimum':result['optimum'],'target':args.target,'target_reached':endpoint['phi']<=args.target,
                'source_input_sha256':sha(matrix),'source_DAG_sha256':dag_sha,'retained_source_DAG':str(retained),
                'incoming_parent_chain_ids':[node['id'] for node in chain],'incoming_path_max_alpha':max(incoming),
                'incoming_path_positive_loss':old_positive,'new_path_max_alpha':max(alphas),'new_path_positive_loss':positive,
                'rooted_max_normalized_drift':max(alphas)-incoming[0],
                'source_matrix':a.tolist(),'first_matrix':first.tolist(),'second_matrix':second.tolist(),'new_growth_nodes':added,
                'actual_new_growth_moves':2,'selection_rounds_are_growth':False,'support':result['support'],
                'optimal_support_count':result['optimal_support_count'],'arg_plus':result['arg_plus'],'arg_minus':result['arg_minus'],
                'swapped_new_vertex_order':swap,'intermediate_choice_scope':'better of two orders for one endpoint; not globally tie-optimized',
                'integer_field_verifier_records':{'source':source,'first':first_receipt,'endpoint':endpoint},
                'support_archive_sha256':sha(item/'support_optima.npz'),'wall_seconds':result['wall_seconds'],
                'GPU_kernel_seconds':result['GPU_kernel_seconds'],'elapsed_seconds':time.perf_counter()-begun,
                'classification':'finite complete endpoint optimum from this exact source; no asymptotic norm claim'}
        dump(item/'result.json',report); results.append(report)
        with (args.output/'new_growth_nodes.jsonl').open('a') as log:
            for node in added: log.write(json.dumps(node)+'\n')
        scores=[{'source_id':r['source_id'],'parent_phi':r['phis'][0],'first_phi':r['phis'][1],'endpoint_phi':r['phis'][2],
                 'rooted_path_max':r['new_path_max_alpha'],'rooted_positive_loss':r['new_path_positive_loss']} for r in results]
        summary={'status':'running','provenance':provenance,'completed_source_ids':[r['source_id'] for r in results],
                 'source_scores':scores,'target_sources':[r['source_id'] for r in results if r['target_reached']],
                 'best_endpoint':min(r['phis'][2] for r in results),'elapsed_seconds':time.perf_counter()-started}
        dump(args.output/'result.json',summary)
        print(json.dumps({'source_id':row['id'],'phis':report['phis'],'target_reached':report['target_reached'],
                          'new_path_max_alpha':report['new_path_max_alpha'],'GPU_kernel_seconds':report['GPU_kernel_seconds']}),flush=True)
        if args.stop_on_target and report['target_reached']: break
    summary['status']='completed'; dump(args.output/'result.json',summary); dump(args.output/'kernel_events.json',engine.events)

if __name__=='__main__': main()
