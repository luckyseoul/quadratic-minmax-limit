# Two fixed order-19 entrance controls

2026-09-06. Temporary interpretation and provenance; no repository status
change, asymptotic conclusion, or further search is implied.

## What is established

For a two-vertex extension, switch only the last new vertex to set the
joining sign to +1 and write s=(b+c)/2, t=(b-c)/2. Their signed supports
partition the 19 old coordinates. The exact endpoint identity is

    Phi = max_x max(|Q(x)+1|+2|s.x|, |Q(x)-1|+2|t.x|).

The retained complete support tables U_plus and U_minus therefore test
whether a support S and its complement can both attain a proposed bound.
At target 44 the two fixed controls differ as follows:

| Fixed source | Exact two-addition optimum | Largest feasible U_plus support | Largest feasible U_minus support | Actual feasible complementary pairs |
|---|---:|---:|---:|---:|
| Actual-grown soul_68004, Phi19=39 | 48 | 6 | 5 | 0 |
| Fixed restriction of the retained Phi21=44 matrix, Phi19=41 | 44 | 9 | 10 | 7 |

For soul_68004, 6+5<19 already prevents complementary feasible supports.
For the successful control the only feasible complementary cardinalities
are (9,10); the seven feasible supports in each maximal class pair exactly
by complement. These size bounds and counts are **exact aggregations of
previous complete U tables**, not newly proved analytic capacity bounds.
The aggregation made no Q/F call, candidate search, or optimizer call.

The successful source was prepared by deleting the fixed last two vertices
of an existing order-21 matrix. That restriction is not a growth move and
does not establish a bridge from any grown forward source.

## What the Gram checks do and do not show

The weighted-frame proof gives sufficient, not necessary, obstructions.
For a fixed support parity, if the selected-row Gram W and squared bound B
satisfy 19W-BI positive definite, that parity branch is impossible. The
more general common-diagonal version permits W_s-D and W_t-D positive
semidefinite and tr(D)>B_s+B_t. Failure of either test is not feasibility.

The initial peak-only and two-extreme equal-weight scalar tests failed for
both controls, with exact nonpositive quadratic witnesses retained. For
soul_68004 the actual levels are +39 and -37, each with 136 projective rows;
they share kernel e6+e18. No unobserved opposite-sign peak was inserted.

A separate explicit finite certificate excludes the **odd-support branch
only** for soul_68004. Let R omit twins 6 and 18, let w_R=H39[R,6]/48 and
w6=w18=0, and let v=e6-e18. Directly checked row Grams satisfy

    H39 + Hminus37 = D + 20 w w^T + 272 v v^T,
    D_R = 252 I, D_6 = D_18 = 0.

Thus the remainder is exactly PSD and tr(D)=4284 exceeds the odd-branch
bound 2448 by 1836. The even-branch bound is 5168, so this certificate alone
does not close that branch. All 272 selected row energies and the displayed
matrix identity were independently checked in integer arithmetic.

No additional Gram, ternary-subset, or constraint-programming certificate
search is needed for this already computed finite failure. The useful
contrast is the retained support capacity, not a new global theorem.

## Frozen provenance

- General sufficient-frame proof:
  `/tmp/original-mo-extension-gram.3FK01t/PROOF.md`, SHA256
  `88a6507deec5a8313aee7ef0fe31c3d2972d606b4d2bf98194fb4d7b735aac59`.
- Explicit odd-branch certificate:
  `peak_gram_two_source/twin_diagonal_odd.json`, SHA256
  `9524a45a9a850948cff3813a5c8636c306a548b8f11e4eb823f9e8e4298a451e`.
  Checker `verify_soul68004_twin_diagonal.py`, SHA256
  `4ea3906b3c06835a1bdc1a40756d0bd3cb52326d6d3f713aae8dac613b5c02dd`.
- Exact retained-table aggregation:
  `peak_gram_two_source/support_tables_two_source_summary.json`, SHA256
  `e6fedb043fce16493c87ac245f00c2088cca3af9b74b1b0937c0c364771920e9`.
  Checker `summarize_retained_support_tables.py`, SHA256
  `aa55edfebe3290ca50d33ddd2e308a4ad9aadb6bb2e3a348c56ad7581bee80f8`.
- Source-bound input U archives, under
  `/tmp/original_mo_path_v100_20260906_Q86jOz/`:
  `bounded_grown19_v100/source_00_soul_68004/support_optima.npz`, SHA256
  `1ba8f48e848df3d2514f0f69cd5421514ea032ad7219207aa4e48812440170be`;
  `reverse21_control/support_optima.npz`, SHA256
  `c729cd79bff8b7970433270fc09a2082b76f198c668379c4478a561848224b65`.

Relative paths above are relative to this note's directory. The two
checker receipts bind the corresponding actual source matrices and the
earlier complete endpoint receipts by SHA256, and preserve all cardinality
and twin-membership counts. Nothing here upgrades finite results to a
uniform order comparison, convergence, or an actual forward growth bridge.
