# Exact two-vertex extension by a ternary max-plus transform

Draft for independent review, 2026-09-06. This is an all-finite-order
algorithmic identity, not a convergence theorem or a bound on its optimum.

## Objective and gauge

Let A be any symmetric zero-diagonal complete signing of order n, and write
Q(x)=x^T A x/2 for x in {+1,-1}^n. A two-vertex extension has matrix

    C = [[A, b, c], [b^T, 0, d], [c^T, d, 0]],

where b,c are sign vectors and d is a sign. Switching only the last vertex
changes (c,d) to (-c,-d), preserves the original A, and preserves Phi(C).
Consequently minimization over the complete extension family may set d=+1.

For fixed old x, put p=b.x and q=c.x. Separating the cases uv=+1 and uv=-1
for the two new spins gives the exact identity

    max_{u,v=+/-1} |Q(x)+u*p+v*q+u*v|
      = max( |Q(x)+1|+|p+q|, |Q(x)-1|+|p-q| ).                 (1)

## Separation by support

Set S={i:b_i=c_i}. Let s_i=b_i on S and zero off S, and let t_i=b_i
off S and zero on S. Then b=s+t, c=s-t, p+q=2s.x, and p-q=2t.x.
Conversely every partition S,S^c and every independent pair of sign
assignments on its two parts gives valid b,c this way.

For a signed ternary vector v define

    F_+(v)=max_x ( |Q(x)+1| + 2 v.x ),
    F_-(v)=max_x ( |Q(x)-1| + 2 v.x ).

Since Q(-x)=Q(x), replacing 2v.x by 2|v.x| leaves each maximum unchanged.
For S subset of {0,...,n-1}, define

    U_+(S)=min_{supp(v)=S, v_i in {-1,0,1}} F_+(v),
    U_-(S)=min_{supp(v)=S, v_i in {-1,0,1}} F_-(v).

Empty support is included, with the unique zero vector. Equation (1)
and the independence of s and t prove

    min_{b,c,d} Phi(C) = min_S max( U_+(S), U_-(S^c) ).         (2)

Indeed for fixed S the objective is max(F_+(s),F_-(t)); minimizing two
independent finite choices gives max(min_s F_+(s),min_t F_-(t)). Minimizing
over S then covers every b,c at d=+1 and the gauge covers d=-1 as well.
This is a complete-family equality, not a relaxation. Storing one minimizing
ternary vector for each U recovers an actual optimal extension.

## Rectangular max-plus evaluation

For either sign start from the full Boolean table f(x)=|Q(x)+/-1| of size
2^n. Process one Boolean coordinate at a time. If a,b are the current
values at x_i=+1 and x_i=-1, replace this two-entry fibre by the three
entries indexed by v_i=-1,0,+1:

    max(a-2,b+2),  max(a,b),  max(a+2,b-2).                    (3)

After k coordinates the table is indexed by k ternary output coordinates
and n-k remaining Boolean input coordinates. Its value is the maximum
over the k eliminated Boolean inputs of f(x) plus their 2v_i*x_i terms.
This invariant is true initially, and (3) is exactly its next elimination.
After n stages it is therefore F_+ or F_- on the whole ternary cube.

The k-th output table contains 3^k * 2^(n-k) entries. Thus the total number
of elementary fibre operations is O(sum_{k=1}^n 3^k*2^(n-k))=O(3^n).
Two ordinary consecutive buffers need O(3^n) integer storage. Apply the two
signs successively; retain only each sign's support minima and witnesses.
The full signed Q input, not |Q| alone, is needed to initialize these tables.

Grouping each final ternary index by its nonzero-coordinate support takes
O(n*3^n) with naive digit decoding, or O(3^n) total using a recursive/streaming
base-3 traversal whose support mask changes in constant amortized work.
One minimizing index is retained per support. The final complement lookup
in (2) takes O(2^n). These costs include every support and signed assignment;
there is no independence assumption about the original Q values.

There is also a fully device-resident support reduction. At each ternary
coordinate, replace the fibre (a,z,b) indexed by v_i=-1,0,+1 with the two
entries (z,min(a,b)) indexed by absence/presence in the support. After all
coordinates this is exactly U_+ or U_-: the successive minima enumerate all
signs at present coordinates and force zero at absent ones. Its total work
and two-buffer storage are again O(3^n). This reduction need not store all
minimizing ternary indices. For one selected support, recompute the max-plus
elimination with a 2-to-1 fibre max(a,b) at absent coordinates and a 2-to-2
fibre (max(a-2,b+2),max(a+2,b-2)) at present coordinates. The final table has
2^|S| entries, giving one minimizing sign assignment. No intermediate table
in this restricted recovery exceeds 2^n entries. Least-index tie selection
agrees with least ternary index when coordinates are ordered consistently.

If fixed-width indices/costs are used, the implementation must check their
ranges: |Q(x)+/-1|+2v.x has magnitude at most n(n-1)/2+1+2n, and the
ternary table has 3^n entries. In particular signed int16 costs suffice
for the proposed small-order prototype, but n must be explicitly bounded.

## Scope and checks required before use

The optimizer in (2) minimizes the endpoint norm only. It need not minimize
the first intermediate norm, path maximum, or cumulative positive loss.
Compute those quantities from the reconstructed actual matrices; do not
assign them from an endpoint-only certificate. This does not assert that
all endpoint-optimal extensions have been retained when one minimizer per
support is saved.

An optional exact lexicographic refinement minimizes the first intermediate
norm among ALL endpoint-optimal extensions. Let T be the optimum in (2),
retain both full ternary F tables, and set

    K={S: max(U_+(S),U_-(S^c))=T}.

Compute all one-vertex extension norms

    C(b)=max_x (|Q(x)|+b.x)

by the ordinary binary max-plus transform, in O(n*2^n) time. For every S in
K and every complete sign vector b, form s=b on S and zero elsewhere and
t=b off S and zero on S. Retain exactly the pairs with

    max(F_+(s),F_-(t))=T.

Minimizing C(b) over these pairs is the exact requested secondary optimum:
every d=+1 extension has exactly this representation, every endpoint-optimal
extension has its support in K, and switching the last vertex from d=-1 to
d=+1 leaves its first intermediate matrix unchanged. One may enumerate b
in Gray order and update each of its two ternary indices in constant time.
The refinement therefore costs O(|K|*2^n), which can be O(4^n); it must not
be included in an unqualified O(3^n) complexity claim. With both endpoint
norms fixed, minimizing the intermediate norm minimizes the normalized
three-node path maximum, but does not necessarily minimize its positive
variation. The latter is measured separately.

Check every final ternary cost directly at small n, and compare the optimum
and reconstructed matrices against exhaustive b,c,d enumeration at small n.
The fixed order-11 source

    1101011101110011110111111110101110110101001110010001001

has a previously exhaustive two-extension optimum 22; it is a stored
cross-check, not the theorem's proof. Any larger-order experiment should
use the actual stored signing, preserve its hash, independently evaluate
the two reconstructed complete matrices, and retain the original ancestry.
