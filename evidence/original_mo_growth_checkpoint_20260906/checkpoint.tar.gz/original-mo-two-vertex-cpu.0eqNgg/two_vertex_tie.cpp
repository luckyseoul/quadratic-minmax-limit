// Exact endpoint-then-intermediate refinement. The endpoint transform costs
// O(3^n); this separate tie refinement costs O(k*2^n), worst-case O(4^n).
#define main reviewed_endpoint_reference_main
#include "two_vertex.cpp"
#undef main

std::vector<int16_t> one_step_costs(const std::vector<int16_t>& q, int n) {
    std::vector<int16_t> f(q.size());
    for(uint64_t x=0;x<q.size();x++) f[x]=int16_t(std::abs(int(q[x])));
    for(int i=0;i<n;i++) {
        uint64_t stride=uint64_t(1)<<i;
        for(uint64_t base=0;base<f.size();base+=2*stride) for(uint64_t j=0;j<stride;j++) {
            int a=f[base+j],b=f[base+stride+j];
            f[base+j]=int16_t(std::max(a+1,b-1));
            f[base+stride+j]=int16_t(std::max(a-1,b+1));
        }
    }
    return f;
}

struct Tie {
    int endpoint=32767, first_phi=32767;
    uint64_t support=0,bits=0,optimal_supports=0,examined=0,feasible=0;
    std::vector<int> b,c; Mat first,second;
};

Tie optimize_tie(const Mat& a,const Supports& plus,const Supports& minus,
                 const std::vector<int16_t>& first_cost) {
    int n=int(a.size()); uint64_t full=(uint64_t(1)<<n)-1;
    require(first_cost.size()==full+1 && !plus.full.empty() && plus.full.size()==minus.full.size(),"tie table shape");
    std::vector<uint64_t> powers(n,1); uint64_t zero_code=0;
    for(int i=0;i<n;i++) { if(i) powers[i]=3*powers[i-1]; zero_code+=powers[i]; }
    Tie out;
    for(uint64_t s=0;s<=full;s++) out.endpoint=std::min(out.endpoint,int(std::max(plus.u[s],minus.u[full^s])));
    for(uint64_t s=0;s<=full;s++) {
        if(std::max(plus.u[s],minus.u[full^s])!=out.endpoint) continue;
        out.optimal_supports++; uint64_t code_s=zero_code,code_t=zero_code,bits=0;
        for(int i=0;i<n;i++) ((s>>i&1)?code_s:code_t)+=powers[i];
        for(uint64_t k=0;k<=full;k++) {
            int endpoint=std::max(plus.full[code_s],minus.full[code_t]); out.examined++;
            if(endpoint==out.endpoint) {
                out.feasible++; int first=first_cost[bits];
                if(first<out.first_phi || (first==out.first_phi && (s<out.support || (s==out.support && bits<out.bits)))) {
                    out.first_phi=first; out.support=s; out.bits=bits;
                }
            }
            if(k==full) break;
            int i=__builtin_ctzll(k+1); uint64_t& code=(s>>i&1)?code_s:code_t;
            if(bits>>i&1) code+=2*powers[i]; else code-=2*powers[i];
            bits^=uint64_t(1)<<i;
        }
    }
    require(out.feasible>0 && out.examined==out.optimal_supports*(full+1),"tie coverage");
    for(int i=0;i<n;i++) { out.b.push_back(spin(out.bits,i)); out.c.push_back((out.support>>i&1)?out.b.back():-out.b.back()); }
    out.first=extend(a,out.b); auto c=out.c; c.push_back(1); out.second=extend(out.first,c);
    return out;
}

void tie_selftest() {
    std::mt19937 rng(20260906); int cases=0; uint64_t first_rows=0,extensions=0,states=0;
    for(int n=2;n<=6;n++) for(int trial=0;trial<4;trial++) {
        Mat a(n,std::vector<int>(n));
        for(int i=0;i<n;i++) for(int j=i+1;j<n;j++) a[i][j]=a[j][i]=trial==0?1:trial==1?-1:(rng()&1?1:-1);
        auto q=signed_cube(a); auto plus=transform(q,n,1,true),minus=transform(q,n,-1,true);
        auto costs=one_step_costs(q,n); auto result=optimize_tie(a,plus,minus,costs);
        int best_endpoint=32767,best_first=32767;
        for(uint64_t b=0;b<q.size();b++) {
            std::vector<int> row(n); for(int i=0;i<n;i++) row[i]=spin(b,i);
            Mat first=extend(a,row); int first_phi=0;
            for(uint64_t x=0;x<(uint64_t(1)<<(n+1));x++) first_phi=std::max(first_phi,std::abs(direct_energy(first,x)));
            require(first_phi==costs[b],"one-step row cost mismatch"); first_rows++;
            for(uint64_t c=0;c<q.size();c++) for(int d:{1,-1}) {
                int endpoint=0;
                for(uint64_t x=0;x<q.size();x++) {
                    int pb=0,pc=0; for(int i=0;i<n;i++) { pb+=spin(b,i)*spin(x,i); pc+=spin(c,i)*spin(x,i); }
                    for(int u:{1,-1}) for(int v:{1,-1}) { endpoint=std::max(endpoint,std::abs(q[x]+u*pb+v*pc+d*u*v)); states++; }
                }
                if(endpoint<best_endpoint || (endpoint==best_endpoint && first_phi<best_first)) { best_endpoint=endpoint; best_first=first_phi; }
                extensions++;
            }
        }
        require(result.endpoint==best_endpoint && result.first_phi==best_first,"lexicographic exhaustive mismatch");
        require(field_gray_norm(result.first).phi==best_first && field_gray_norm(result.second).phi==best_endpoint,"tie reconstruction mismatch"); cases++;
    }
    std::cout<<"{\"checks\":\"PASS\",\"cases\":"<<cases<<",\"direct_first_rows\":"<<first_rows<<",\"direct_extensions_both_d\":"<<extensions<<",\"direct_extension_states\":"<<states<<"}\n";
}

int main(int argc,char** argv) { try {
    if(argc==2 && std::string(argv[1])=="--selftest") { tie_selftest(); return 0; }
    require(argc==3,"usage: two_vertex_tie matrix.txt output_prefix OR --selftest");
    auto start=std::chrono::steady_clock::now(); Mat a=read_matrix(argv[1]); int n=int(a.size());
    auto q=signed_cube(a); auto plus=transform(q,n,1,true),minus=transform(q,n,-1,true);
    auto first_cost=one_step_costs(q,n); auto tie_start=std::chrono::steady_clock::now();
    auto result=optimize_tie(a,plus,minus,first_cost);
    double tie_seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-tie_start).count();
    Norm source=field_gray_norm(a),first=field_gray_norm(result.first),second=field_gray_norm(result.second);
    require(first.phi==result.first_phi && second.phi==result.endpoint,"independent tie norms");
    std::string prefix=argv[2]; write_matrix(prefix+".tie.first.txt",result.first); write_matrix(prefix+".tie.second.txt",result.second);
    double a0=source.phi/std::pow(n,1.5),a1=first.phi/std::pow(n+1,1.5),a2=second.phi/std::pow(n+2,1.5);
    std::ofstream out(prefix+".tie.json"); require(bool(out),"tie output open"); out.precision(17);
    out<<"{\"status\":\"EXACT_FIXED_SOURCE_ENDPOINT_THEN_FIRST_NORM_OPTIMUM\",\"n\":"<<n<<",\"source_upper\":\""<<upper(a)<<"\",\"d\":1,\"endpoint_optimum\":"<<result.endpoint<<",\"minimum_first_at_optimal_endpoint\":"<<result.first_phi<<",\"optimal_supports\":"<<result.optimal_supports<<",\"support_b_pairs_examined\":"<<result.examined<<",\"feasible_endpoint_optimal_d_plus_extensions\":"<<result.feasible<<",\"support\":"<<result.support<<",\"first_row_bits\":"<<result.bits<<",\"b\":";
    vector_json(out,result.b); out<<",\"c\":"; vector_json(out,result.c);
    out<<",\"source\":"; norm_json(out,source); out<<",\"first\":"; norm_json(out,first); out<<",\"second\":"; norm_json(out,second);
    out<<",\"alpha_source\":"<<a0<<",\"alpha_first\":"<<a1<<",\"alpha_second\":"<<a2<<",\"local_path_max_alpha\":"<<std::max({a0,a1,a2})<<",\"local_positive_loss\":"<<std::max(0.0,a1-a0)+std::max(0.0,a2-a1)<<",\"positive_loss_scope\":\"measured, not separately optimized\",\"tie_seconds\":"<<tie_seconds<<",\"total_seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<",\"checks\":\"PASS\"}\n";
    require(bool(out),"tie output write");
    std::cout<<"{\"n\":"<<n<<",\"endpoint_optimum\":"<<result.endpoint<<",\"minimum_first_at_optimal_endpoint\":"<<result.first_phi<<",\"support_b_pairs_examined\":"<<result.examined<<",\"checks\":\"PASS\"}\n"; return 0;
} catch(const std::exception& e) { std::cerr<<e.what()<<'\n'; return 2; } }
