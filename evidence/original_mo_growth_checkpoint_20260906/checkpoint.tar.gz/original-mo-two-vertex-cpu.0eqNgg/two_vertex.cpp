#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
using Mat = std::vector<std::vector<int>>;
void require(bool ok, const std::string& why) { if (!ok) throw std::runtime_error(why); }
int spin(uint64_t bits, int i) { return (bits >> i & 1) ? -1 : 1; }
Mat read_matrix(const std::string& path) {
    std::ifstream in(path); int n = 0; in >> n;
    require(in.good() && n >= 2 && n <= 16, "input order must be 2..16");
    Mat a(n, std::vector<int>(n));
    for (auto& row : a) for (int& x : row) require(bool(in >> x), "short matrix");
    for (int i=0;i<n;i++) for (int j=0;j<n;j++)
        require(a[i][j] == a[j][i] && (i==j ? a[i][j]==0 : std::abs(a[i][j])==1), "invalid signing");
    std::string extra; require(!(in >> extra), "extra matrix input"); return a;
}
int direct_energy(const Mat& a, uint64_t bits) {
    int q=0, n=int(a.size());
    for (int i=0;i<n;i++) for (int j=i+1;j<n;j++) q += a[i][j]*spin(bits,i)*spin(bits,j);
    return q;
}
std::vector<int16_t> signed_cube(const Mat& a) {
    std::vector<int16_t> q(uint64_t(1)<<a.size());
    for (uint64_t x=0;x<q.size();x++) q[x]=int16_t(direct_energy(a,x));
    return q;
}
struct Norm { int phi=0, witness_q=0; uint64_t witness=0, states=0; };
Norm field_gray_norm(const Mat& a) {
    int n=int(a.size()), m=n*(n-1)/2, q=direct_energy(a,0);
    std::vector<int> x(n,1), h(n,0);
    for (int i=0;i<n;i++) for (int j=0;j<n;j++) h[i]+=a[i][j];
    Norm r; r.states=uint64_t(1)<<(n-1); int64_t sum=0, squares=0;
    uint64_t bits=0;
    for (uint64_t k=0;k<r.states;k++) {
        require((q-m)%2==0, "energy parity"); sum+=q; squares+=int64_t(q)*q;
        if (std::abs(q)>r.phi) { r.phi=std::abs(q); r.witness_q=q; r.witness=bits; }
        if (k+1==r.states) break;
        int j=__builtin_ctzll(k+1)+1, old=x[j]; q-=2*old*h[j];
        for (int i=0;i<n;i++) if (i!=j) h[i]-=2*a[i][j]*old;
        x[j]=-old; bits^=uint64_t(1)<<j;
    }
    require(sum==0 && squares==int64_t(r.states)*m, "energy moments");
    require(direct_energy(a,r.witness)==r.witness_q && std::abs(r.witness_q)==r.phi, "norm witness");
    return r;
}
struct Supports { std::vector<int16_t> u, full; std::vector<uint64_t> arg; };
Supports transform(const std::vector<int16_t>& q, int n, int sign, bool keep_full=false) {
    require(n>=2 && n<=16 && q.size()==(uint64_t(1)<<n), "transform bounds");
    require(n*(n-1)/2+1+2*n <= std::numeric_limits<int16_t>::max(), "cost overflow");
    std::vector<int16_t> f(q.size());
    for (uint64_t i=0;i<q.size();i++) f[i]=int16_t(std::abs(int(q[i])+sign));
    uint64_t stride=1;
    for (int k=0;k<n;k++) {
        uint64_t groups=uint64_t(1)<<(n-k-1);
        std::vector<int16_t> g(groups*3*stride);
        for (uint64_t group=0;group<groups;group++) for (uint64_t j=0;j<stride;j++) {
            int a=f[group*2*stride+j], b=f[group*2*stride+stride+j];
            g[group*3*stride+j]=int16_t(std::max(a-2,b+2));
            g[group*3*stride+stride+j]=int16_t(std::max(a,b));
            g[group*3*stride+2*stride+j]=int16_t(std::max(a+2,b-2));
        }
        f.swap(g); stride*=3;
    }
    Supports out; out.u.assign(uint64_t(1)<<n,32767); out.arg.resize(out.u.size());
    std::vector<int> digits(n,0); uint64_t support=(uint64_t(1)<<n)-1;
    for (uint64_t code=0;code<f.size();code++) {
        if (f[code]<out.u[support]) { out.u[support]=f[code]; out.arg[support]=code; }
        if (code+1==f.size()) break;
        int j=0; while (digits[j]==2) { digits[j]=0; j++; }
        if (digits[j]==0) support &= ~(uint64_t(1)<<j); else support |= uint64_t(1)<<j;
        digits[j]++;
    }
    if (keep_full) out.full=std::move(f); return out;
}
std::vector<int> decode(uint64_t code, int n) {
    std::vector<int> v(n); for (int& z:v) { z=int(code%3)-1; code/=3; }
    require(code==0,"ternary overflow"); return v;
}
uint64_t encode(const std::vector<int>& v) {
    uint64_t code=0, place=1; for (int z:v) { require(z>=-1 && z<=1,"bad ternary digit"); code+=(z+1)*place; place*=3; } return code;
}
int direct_f(const std::vector<int16_t>& q, const std::vector<int>& v, int sign) {
    int best=-32767;
    for (uint64_t x=0;x<q.size();x++) {
        int value=std::abs(int(q[x])+sign); for (int i=0;i<int(v.size());i++) value+=2*v[i]*spin(x,i);
        best=std::max(best,value);
    } return best;
}
Mat extend(const Mat& a, const std::vector<int>& row) {
    int n=int(a.size()); require(row.size()==a.size(),"extension row length"); Mat b(n+1,std::vector<int>(n+1));
    for (int i=0;i<n;i++) { require(std::abs(row[i])==1,"extension row sign"); for (int j=0;j<n;j++) b[i][j]=a[i][j]; b[i][n]=b[n][i]=row[i]; }
    return b;
}
struct Pair { int optimum=32767; uint64_t support=0, optimal_supports=0; std::vector<int> b,c; Mat first,second; };
Pair recover(const Mat& a, const Supports& plus, const Supports& minus) {
    Pair out; uint64_t full=plus.u.size()-1;
    for (uint64_t s=0;s<=full;s++) {
        int value=std::max(plus.u[s],minus.u[full^s]);
        if (value<out.optimum) { out.optimum=value; out.support=s; out.optimal_supports=1; }
        else if (value==out.optimum) out.optimal_supports++;
    }
    auto s=decode(plus.arg[out.support],int(a.size())), t=decode(minus.arg[full^out.support],int(a.size()));
    for (int i=0;i<int(a.size());i++) { require((s[i]!=0)==bool(out.support>>i&1) && (t[i]!=0)!=bool(out.support>>i&1),"support witness"); out.b.push_back(s[i]+t[i]); out.c.push_back(s[i]-t[i]); }
    out.first=extend(a,out.b); auto last=out.c; last.push_back(1); out.second=extend(out.first,last); return out;
}
void write_matrix(const std::string& path, const Mat& a) {
    std::ofstream out(path); require(bool(out),"matrix output open"); out<<a.size()<<'\n';
    for (const auto& row:a) { for (int x:row) out<<x<<' '; out<<'\n'; } require(bool(out),"matrix output write");
}
std::string upper(const Mat& a) {
    std::string s; for (int i=0;i<int(a.size());i++) for (int j=i+1;j<int(a.size());j++) s+=a[i][j]>0?'1':'0'; return s;
}
void vector_json(std::ostream& out, const std::vector<int>& v) {
    out<<'['; for (size_t i=0;i<v.size();i++) { if(i) out<<','; out<<v[i]; } out<<']';
}
void norm_json(std::ostream& out, const Norm& r) {
    out<<"{\"phi\":"<<r.phi<<",\"states\":"<<r.states<<",\"witness_bits\":"<<r.witness<<",\"witness_q\":"<<r.witness_q<<",\"checks\":\"PASS\"}";
}
void selftest() {
    std::mt19937 rng(20260906); uint64_t costs=0, extensions=0, states=0; int cases=0;
    for (int n=2;n<=6;n++) for (int trial=0;trial<4;trial++) {
        Mat a(n,std::vector<int>(n));
        for (int i=0;i<n;i++) for (int j=i+1;j<n;j++) a[i][j]=a[j][i]=trial==0?1:trial==1?-1:(rng()&1?1:-1);
        auto q=signed_cube(a); auto p=transform(q,n,1,true), m=transform(q,n,-1,true);
        for (int sign:{1,-1}) { const auto& f=sign==1?p.full:m.full; for(uint64_t code=0;code<f.size();code++) { require(f[code]==direct_f(q,decode(code,n),sign),"full ternary direct mismatch"); costs++; } }
        auto result=recover(a,p,m); int exhaustive=32767;
        for (uint64_t b=0;b<q.size();b++) for (uint64_t c=0;c<q.size();c++) for (int d:{1,-1}) {
            int actual=0; std::vector<int> s(n),t(n);
            for (int i=0;i<n;i++) { int bi=spin(b,i),ci=d*spin(c,i); s[i]=(bi+ci)/2; t[i]=(bi-ci)/2; }
            int predicted=std::max(p.full[encode(s)],m.full[encode(t)]);
            for (uint64_t x=0;x<q.size();x++) { int pb=0,pc=0; for(int i=0;i<n;i++) { pb+=spin(b,i)*spin(x,i); pc+=spin(c,i)*spin(x,i); }
                for(int u:{1,-1}) for(int v:{1,-1}) { actual=std::max(actual,std::abs(q[x]+u*pb+v*pc+d*u*v)); states++; }
            }
            require(actual==predicted,"fixed b,c,d mismatch"); exhaustive=std::min(exhaustive,actual); extensions++;
        }
        require(exhaustive==result.optimum && field_gray_norm(result.second).phi==result.optimum,"global extension optimum mismatch");
        int direct_phi=0; for(int value:q) direct_phi=std::max(direct_phi,std::abs(value)); require(field_gray_norm(a).phi==direct_phi,"Gray source mismatch");
        cases++;
    }
    Mat a2={{0,1},{1,0}}; require(direct_f(signed_cube(a2),{1,-1},1)==4,"signed initializer adversary");
    Mat a16(16,std::vector<int>(16,1)); for(int i=0;i<16;i++) a16[i][i]=0;
    require(direct_f(signed_cube(a16),std::vector<int>(16,1),1)==153,"int16 range adversary");
    auto range_test=transform(signed_cube(a16),16,1,true);
    require(range_test.full.front()==153 && range_test.full.back()==153 && range_test.u[0]==121,"int16 transformed range adversary");
    std::cout<<"{\"checks\":\"PASS\",\"cases\":"<<cases<<",\"full_ternary_costs\":"<<costs<<",\"fixed_extensions_both_d\":"<<extensions<<",\"direct_extension_states\":"<<states<<",\"adversaries\":2}\n";
}
int main(int argc,char** argv) { try {
    if(argc==2 && std::string(argv[1])=="--selftest") { selftest(); return 0; }
    require(argc==3,"usage: two_vertex matrix.txt output_prefix OR --selftest");
    auto start=std::chrono::steady_clock::now(); Mat a=read_matrix(argv[1]); int n=int(a.size());
    auto q=signed_cube(a); auto plus=transform(q,n,1), minus=transform(q,n,-1); auto result=recover(a,plus,minus);
    Norm source=field_gray_norm(a), first=field_gray_norm(result.first), second=field_gray_norm(result.second);
    require(second.phi==result.optimum,"reconstructed endpoint mismatch");
    std::string prefix=argv[2]; write_matrix(prefix+".first.txt",result.first); write_matrix(prefix+".second.txt",result.second);
    std::ofstream table(prefix+".supports.jsonl"); require(bool(table),"support output open");
    for(uint64_t s=0;s<plus.u.size();s++) table<<"{\"support\":"<<s<<",\"u_plus\":"<<plus.u[s]<<",\"arg_plus\":"<<plus.arg[s]<<",\"u_minus\":"<<minus.u[s]<<",\"arg_minus\":"<<minus.arg[s]<<"}\n";
    require(bool(table),"support output write");
    double alpha0=source.phi/std::pow(n,1.5), alpha1=first.phi/std::pow(n+1,1.5), alpha2=second.phi/std::pow(n+2,1.5);
    std::ofstream out(prefix+".json"); require(bool(out),"summary output open"); out.precision(17);
    out<<"{\"status\":\"EXACT_FIXED_SOURCE_TWO_EXTENSION_OPTIMUM\",\"n\":"<<n<<",\"source_upper\":\""<<upper(a)<<"\",\"d\":1,\"optimum\":"<<result.optimum<<",\"support\":"<<result.support<<",\"optimal_supports\":"<<result.optimal_supports<<",\"b\":"; vector_json(out,result.b); out<<",\"c\":"; vector_json(out,result.c);
    out<<",\"source\":"; norm_json(out,source); out<<",\"first\":"; norm_json(out,first); out<<",\"second\":"; norm_json(out,second);
    out<<",\"alpha_source\":"<<alpha0<<",\"alpha_first\":"<<alpha1<<",\"alpha_second\":"<<alpha2<<",\"local_path_max_alpha\":"<<std::max({alpha0,alpha1,alpha2})<<",\"local_positive_loss\":"<<std::max(0.0,alpha1-alpha0)+std::max(0.0,alpha2-alpha1)<<",\"seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<",\"checks\":\"PASS\"}\n";
    require(bool(out),"summary output write"); std::cout<<"{\"n\":"<<n<<",\"optimum\":"<<result.optimum<<",\"first_phi\":"<<first.phi<<",\"second_phi\":"<<second.phi<<",\"checks\":\"PASS\"}\n";
    return 0;
} catch(const std::exception& e) { std::cerr<<e.what()<<'\n'; return 2; } }
