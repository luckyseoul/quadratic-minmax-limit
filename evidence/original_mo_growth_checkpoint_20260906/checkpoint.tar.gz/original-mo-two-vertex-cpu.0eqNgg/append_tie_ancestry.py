#!/usr/bin/env python3
"""Attach two independently norm-checked macro children to a retained path."""
import hashlib
import json
from pathlib import Path
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def matrix(path):
    values = list(map(int, path.read_text().split()))
    n = values[0]
    assert len(values) == 1 + n*n
    a = [values[1+i*n:1+(i+1)*n] for i in range(n)]
    assert all(a[i][j] == a[j][i] and (a[i][j] == 0 if i == j else abs(a[i][j]) == 1)
               for i in range(n) for j in range(n))
    return a


def upper(a):
    return ''.join('1' if a[i][j] == 1 else '0' for i in range(len(a)) for j in range(i+1, len(a)))


ancestry, source_id, prefix, output = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]), Path(sys.argv[4])
assert not output.exists()
records = json.loads(ancestry.read_text())
indices = [i for i, entry in enumerate(records) if entry['node']['id'] == source_id]
assert len(indices) == 1
records = records[:indices[0]+1]
report_path = Path(str(prefix)+'.tie.json')
report = json.loads(report_path.read_text())
parent = records[-1]['node']
assert parent['n'] == report['n'] and parent['phi'] == report['source']['phi']
assert parent['upper'] == report['source_upper'] and report['checks'] == 'PASS'
first = matrix(Path(str(prefix)+'.tie.first.txt'))
second = matrix(Path(str(prefix)+'.tie.second.txt'))
n = parent['n']
assert len(first) == n+1 and len(second) == n+2
assert upper([row[:n] for row in first[:n]]) == parent['upper']
assert [row[:n+1] for row in second[:n+1]] == first
assert [first[i][n] for i in range(n)] == report['b']
assert [second[i][n+1] for i in range(n)] == report['c'] and second[n][n+1] == report['d'] == 1
for a, label in ((first, 'first'), (second, 'second')):
    certificate = report[label]
    assert certificate['checks'] == 'PASS'
    order = len(a)
    phi = certificate['phi']
    value = phi/order**1.5
    signed_hash = hashlib.sha256(bytes(x & 255 for row in a for x in row)).hexdigest()
    rid = f'ternary_{source_id}_{order}_{signed_hash[:8]}'
    node = dict(id=rid, parent_id=parent['id'], root_id=parent['root_id'], root_n=parent['root_n'],
                depth=parent['depth']+1, n=order, phi=phi, alpha=value, upper=upper(a),
                status='EXACT_TERNARY_ENDPOINT_THEN_FIRST_NORM_MACRO', move='add_vertex',
                params=''.join('1' if a[i][-1] == 1 else '0' for i in range(order-1)),
                path_max_alpha=max(parent['path_max_alpha'], value),
                path_positive_loss=parent['path_positive_loss']+max(0, value-parent['phi']/parent['n']**1.5),
                witness_mask=certificate['witness_bits'], witness_q=certificate['witness_q'])
    records.append(dict(node=node, certificate=certificate, matrix_int8_sha256=signed_hash,
                        macro_report_sha256=digest(report_path), incoming_ancestry_sha256=digest(ancestry)))
    parent = node
output.write_text(json.dumps(records, indent=2)+'\n')
print(json.dumps(dict(records=len(records), output=str(output), sha256=digest(output),
                      new_ids=[entry['node']['id'] for entry in records[-2:]],
                      principal_prefixes_and_report_rows='PASS')))
