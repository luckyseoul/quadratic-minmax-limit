"""Exhaust all sparse eight-support eigenvectors and parameterize their fibers.

For the supplied H64, |Q|=252 forces r=Hx-sigma8x to be four times
an eight-supported sign eigenvector with eigenvalue -sigma8. Such a support
is exactly a signed rank-one principal 8-clique. Both residual orientations
are retained while fixing the first free Boolean coordinate to +1.
"""
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import sympy as sp

def sparse_vectors(h,sign):
    n=len(h); vectors=[]; nodes=0
    for pivot in range(n):
        if h[pivot,pivot]!=sign: continue
        vertices=[j for j in range(pivot+1,n) if h[j,j]==sign]
        labels=[int(sign*h[pivot,j]) for j in vertices]
        adjacency=[sum(1<<k for k,v in enumerate(vertices) if k!=i and h[u,v]==sign*labels[i]*labels[k]) for i,u in enumerate(vertices)]
        def search(chosen,candidates):
            nonlocal nodes
            nodes+=1
            if len(chosen)==7:
                v=np.zeros(n,dtype=np.int64); v[pivot]=1
                for at in chosen: v[vertices[at]]=labels[at]
                assert np.array_equal(h@v,8*sign*v); vectors.append(v.tolist()); return
            if candidates.bit_count()<7-len(chosen): return
            while candidates:
                bit=candidates&-candidates; candidates-=bit; at=bit.bit_length()-1
                search(chosen+[at],candidates&adjacency[at])
        search([], (1<<len(vertices))-1)
    return vectors,nodes

ap=argparse.ArgumentParser(); ap.add_argument('target'); ap.add_argument('previous_cases'); ap.add_argument('--out',required=True); args=ap.parse_args()
source=Path(args.target); h=np.asarray(json.loads(source.read_text())['H'],dtype=np.int64)
assert h.shape==(64,64) and np.array_equal(h,h.T) and np.trace(h)==0 and np.all(abs(h)==1)
assert np.array_equal(h@h,64*np.eye(64,dtype=np.int64))
cases=[r for r in json.loads(Path(args.previous_cases).read_text())['cases'] if r['n']<=16]
# Nonzero-offset SAT controls independently checked against the entire Boolean
# cube, with the actual first free coordinate fixed positive (not x_0).
for original in list(cases):
    control=dict(original); control['name']='affine_'+original['name']
    n=original['n']; hh=np.asarray(original['H'],dtype=np.int64)
    c=np.asarray(original['C'],dtype=np.int64); d=np.asarray(original['D'],dtype=np.int64)
    control['E']=(d-c.sum(axis=1)).tolist()
    rhs=(hh-original['eigenvalue']*np.eye(n,dtype=np.int64))@np.ones(n,dtype=np.int64)
    control['rhs']=rhs.tolist()
    ids=np.arange(1<<n,dtype=np.uint64)
    x=1-2*((ids[:,None]>>np.arange(n,dtype=np.uint64))&1).astype(np.int64)
    good=np.all(x@hh-original['eigenvalue']*x==rhs,axis=1)&(x[:,original['free'][0]]==1)
    control['cpu_exhaustive_count']=int(good.sum()); assert control['cpu_exhaustive_count']>0
    cases.append(control)
source_hash=hashlib.sha256(source.read_bytes()).hexdigest(); census=[]
for eigen_sign in [1,-1]:
    vectors,nodes=sparse_vectors(h,eigen_sign); census.append({'eigenvalue':8*eigen_sign,'vectors_up_to_global_sign':vectors,'search_nodes':nodes})
    sigma=-eigen_sign; m=sp.Matrix(h)-sigma*8*sp.eye(64)
    for number,v in enumerate(vectors):
        for orientation in [1,-1]:
            rhs=sp.Matrix([4*orientation*x for x in v]); reduced,piv=m.row_join(rhs).rref()
            assert len(piv)==32 and 64 not in piv
            free=[j for j in range(64) if j not in piv]; c=[]; d=[]; e=[]; basis=sp.zeros(64,32); offset=sp.zeros(64,1)
            for j,col in enumerate(free): basis[col,j]=1
            for i,pivot in enumerate(piv):
                den=int(sp.ilcm(*([reduced[i,j].q for j in free]+[reduced[i,64].q])))
                coeff=[int(-reduced[i,j]*den) for j in free]; const=int(reduced[i,64]*den)
                assert sum(abs(x) for x in coeff)+abs(const)<2**28 and 0<den<2**28
                c.append(coeff);d.append(den);e.append(const);offset[pivot,0]=sp.Rational(const,den)
                for j,value in enumerate(coeff): basis[pivot,j]=sp.Rational(value,den)
            assert m*basis==sp.zeros(64,32) and m*offset==rhs
            order=sorted(range(32),key=lambda i:sp.Rational(sum(x*x for x in c[i]),d[i]**2),reverse=True)
            cases.append({'name':f'phi252_sigma{sigma}_support{number}_orientation{orientation}',
                          'n':64,'sigma':sigma,'eigenvalue':sigma*8,'H':h.tolist(),'pivots':list(piv),'free':free,
                          'C':c,'D':d,'E':e,'rhs':list(map(int,rhs)),'test_order':order,'source_sha256':source_hash,
                          'residual_orientation':orientation,'sparse_residual_vector':v,'expected_abs_Q':252,
                          'enumerated_free_assignments':1<<31,'exact_kernel_identity':'PASS',
                          'coverage':'Both residual orientations are enumerated with first free sign+1'})
result={'cases':cases,'complete_support8_census':census,'source_sha256':source_hash,
        'preparer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'claim_scope':'Complete decision of Phi=252 for this H64; not a decision of Phi=250 or248'}
out=Path(args.out);out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'out':str(out),'affine_cases':len(cases)-8,'supports_by_eigensign':[len(r['vectors_up_to_global_sign']) for r in census],
                  'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}),flush=True)
