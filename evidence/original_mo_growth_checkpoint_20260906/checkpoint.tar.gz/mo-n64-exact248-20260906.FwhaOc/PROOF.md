# Exact finite norm 248 at order 64

This is a finite exhaustive certificate for the supplied matrix, not a
global asymptotic bound or a proof of the repository's open amplification
claim. Put A=H-diag(H) and Q(x)=sum_{i<j} A_ij x_i x_j.
The matrix source is path nuka-v2-000013502, A SHA256
243559f999fd12cccc1947fc4359ac754f7678d471e780fca2d33498c633efc6.
Integer checks give H=H^T, H_ij in {+1,-1}, trace(H)=0 and H^2=64I.
Consequently Q(x)=x^T Hx/2 and |Q(x)|<=256.

## The two possible values above 248

For y=Hx, orthogonality says any two rows differ in 32 coordinates.
Thus y_i-y_j is twice a sum of 32 signs and all y_i have the same
residue 0 or 2 modulo four. For sigma=sign(Q), put r=y-sigma*8x.
Then Hr=-sigma*8r and ||r||^2=8192-32|Q|.
If the common residue is 2, every r_i has magnitude at least 2,
so ||r||^2>=256 and |Q|<=248.

In the common-residue-zero case Q is divisible by four. To see this,
switch H by D_0=1, D_j=H_00 H_0j. Its first row becomes constant c=H_00,
and orthogonality gives H'1=(64c,0,...,0); hence Q'(1)=32c=0 mod4.
Each sign flip changes Q' by 2 mod4, since the off-diagonal row has
63 odd entries. After k flips, Q'=2k mod4 and H'x=2k mod4 in every
coordinate. Switching preserves Q and preserves these residue classes.
Thus common residue zero implies Q=0 mod4. In particular 254 and 250
are impossible above 248: the only remaining values are 256 and 252.

## Excluding 256

Equality 256 is equivalent to Hx=+8x or Hx=-8x. Each eigenspace has
dimension 32 (H is symmetric, H^2=64I and trace H=0). Exact rational
RREF supplies a basis with a 32-coordinate identity free block; the
executor independently verifies the complete integer-cleared basis
identity. Fixing the first free sign to +1 is complete up to x -> -x.
The Intel Arc A380 exhausted all 2^31 free assignments for each sign
and found zero solutions. Four full-cube small tests and a known-SAT
order-64 control passed; the control has 24 positive-eigenvalue
antipodal pairs, with an independently checked integer witness.

## Excluding 252

At |Q|=252, r is a nonzero eigenvector with squared norm 128 and all
coordinates divisible by four. An eigenvector of a sign matrix with
eigenvalue magnitude 8 has support at least eight: 8||r||_infinity
<=||r||_1<=support(r)||r||_infinity. Therefore r has exactly eight
nonzero coordinates, all equal to +4 or -4.

For v=r/4, Hv=-sigma*8v. On its eight-coordinate support the triangle
inequality is saturated, so H_SS=-sigma*v_S*v_S^T. The complete signed
principal-clique search finds exactly two such vectors per eigenvalue,
up to global sign. All four vectors and both residual orientations are
included in the affine data. Each of the eight systems
(H-sigma*8I)x=4v is parametrized exactly with 32 free coordinates.
Both orientations while fixing the first free sign positive cover the
entire Boolean search; no inhomogeneous sign symmetry is assumed.

The AMD RX9070XT exhausted all 2^31 assignments in each of the eight
affine phases and found zero solutions. Four homogeneous and four
nonzero-offset small full-cube controls passed. Every GPU workgroup
output is checked: zero-count groups return their exact starting SID,
counts are at most 256, and witness SIDs lie in the proper group/range.
Count and witness-grid hashes are retained. This is an exhaustive
integer computation, not a DRAT proof log. Earlier CP-SAT UNSAT results
agree; timed-out CaDiCaL attempts are not used as certificates.

## Lower witness and conclusion

lower_witness.json contains a full Boolean vector checked directly in
integer arithmetic with |Q|=248. The upper exclusions above therefore
give Phi(A)=248 and Phi(A)/64^(3/2)=31/64=0.484375 exactly.

## Replay and output storage

Use Python with NumPy and PyOpenCL on an OpenCL GPU. Run:

    python exhaust_eigen_rref_coverage.py eigen_rref_cases.json --out NEW_EIGEN_OUTPUT
    python exhaust_affine_rref.py affine_support8_cases.json --out NEW_AFFINE_OUTPUT

The preparers additionally require SymPy. All source and input hashes
are in manifest.json. Identical zero-result output arrays are stored
once; output_aliases.json maps every phase to its decoded arrays.
All original phase JSON receipts are retained. This deduplicates arrays,
not the original ZIP timestamp bytes; untouched original artifacts remain
in their originating temporary stages.
