"""Exact rational eigenbasis export; validates the full kernel identity."""
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import sympy as sp

def prepare(h,sigma,name,source_sha):
    n=len(h); r=math.isqrt(n); h=sp.Matrix(h); m=h-sigma*r*sp.eye(n)
    reduced,pivots=m.rref(); free=[j for j in range(n) if j not in pivots]
    assert len(pivots)==len(free)==n//2
    coefficients=[]; denominators=[]
    basis=sp.zeros(n,len(free))
    for j,col in enumerate(free): basis[col,j]=1
    for i,pivot in enumerate(pivots):
        den=int(sp.ilcm(*[reduced[i,j].q for j in free])); row=[int(-reduced[i,j]*den) for j in free]
        assert sum(abs(x) for x in row)<2**28
        coefficients.append(row); denominators.append(den)
        for j,c in enumerate(row): basis[pivot,j]=sp.Rational(c,den)
    assert m*basis==sp.zeros(n,len(free))
    # Rejecting higher relative-variance rows first changes speed, not coverage.
    order=sorted(range(len(pivots)),key=lambda i:sp.Rational(sum(c*c for c in coefficients[i]),denominators[i]**2),reverse=True)
    row={'name':name,'n':n,'sigma':sigma,'eigenvalue':sigma*r,'H':np.asarray(h,dtype=np.int64).tolist(),
         'pivots':list(pivots),'free':free,'C':coefficients,'D':denominators,'test_order':order,
         'source_sha256':source_sha,'parameterization':'x_p=C_p*x_free/D_p; first free sign fixed+1',
         'exact_kernel_identity':'PASS','enumerated_free_assignments':1<<(len(free)-1)}
    if n<=16:
        hh=np.asarray(h,dtype=np.int64); ids=np.arange(1<<(n-1),dtype=np.uint64)<<1
        x=(1-2*((ids[:,None]>>np.arange(n,dtype=np.uint64))&1).astype(np.int64))
        row['cpu_exhaustive_count']=int(np.sum(np.all(x@hh==sigma*r*x,axis=1)))
    return row

ap=argparse.ArgumentParser(); ap.add_argument('target'); ap.add_argument('sat_control'); ap.add_argument('--out',required=True); args=ap.parse_args()
cases=[]
for n in [4,16]:
    h=[[1 if (i&j).bit_count()%2==0 else -1 for j in range(n)] for i in range(n)]
    for sign in [1,-1]: cases.append(prepare(h,sign,f'selftest{n}_sigma{sign}',None))
for source,signs,name in [(args.sat_control,[1],'knownSAT64'),(args.target,[1,-1],'target13502')]:
    p=Path(source); h=json.loads(p.read_text())['H']; digest=hashlib.sha256(p.read_bytes()).hexdigest()
    for sign in signs: cases.append(prepare(h,sign,f'{name}_sigma{sign}',digest))
out=Path(args.out); out.write_text(json.dumps({'cases':cases,'preparer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({'out':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
                 'cases':[{k:r[k] for k in ['name','n','enumerated_free_assignments']} for r in cases]}),flush=True)
