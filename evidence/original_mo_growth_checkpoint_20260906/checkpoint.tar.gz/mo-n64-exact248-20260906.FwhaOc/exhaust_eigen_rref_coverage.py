"""Exhaust exactly all free signs for exported exact rational eigenbases.

This independent exhaustive computation is not a DRAT proof replacement.
Weighted subset sums use signed coefficient bitplanes and integer popcounts.
"""
import argparse, hashlib, json, time
from pathlib import Path
import numpy as np
import pyopencl as cl

KERNEL=r'''
__kernel void exhaust(__global const uint *positive,__global const uint *negative,
                      __global const int *total,__global const int *den,
                      int rows,int bits,uint states,
                      __global uint *out,__global uint *witness) {
  uint sid=get_global_id(0), lane=get_local_id(0), mask=sid<<1;
  int ok=(sid<states);
  for(int row=0;row<rows && ok;row++) {
    int sum=0;
    for(int bit=0;bit<bits;bit++) {
      int plus=(int)popcount(mask&positive[row*bits+bit]);
      int minus=(int)popcount(mask&negative[row*bits+bit]);
      sum+=(plus-minus)*(1<<bit);
    }
    int value=total[row]-2*sum;
    if((int)abs(value)!=den[row]) ok=0;
  }
  __local uint counts[256], ids[256];
  counts[lane]=ok?1u:0u; ids[lane]=sid;
  barrier(CLK_LOCAL_MEM_FENCE);
  for(uint d=128;d;d>>=1) {
    if(lane<d) { if(counts[lane]==0 && counts[lane+d]>0) ids[lane]=ids[lane+d]; counts[lane]+=counts[lane+d]; }
    barrier(CLK_LOCAL_MEM_FENCE);
  }
  if(lane==0) { out[get_group_id(0)]=counts[0]; witness[get_group_id(0)]=ids[0]; }
}
'''

def validate(case):
    h=np.asarray(case['H'],dtype=np.int64); n=len(h); r=int(abs(case['eigenvalue']))
    assert n==case['n'] and r*r==n and np.array_equal(h,h.T) and np.trace(h)==0
    assert np.all(abs(h)==1) and np.array_equal(h@h,n*np.eye(n,dtype=np.int64))
    piv=case['pivots']; free=case['free']; c=np.asarray(case['C'],dtype=np.int64); d=np.asarray(case['D'],dtype=np.int64)
    assert sorted(piv+free)==list(range(n)) and len(piv)==len(free)==n//2 and len(set(piv+free))==n
    assert c.shape==(len(piv),len(free)) and len(d)==len(piv) and np.all(d>0)
    # Recheck the rational identity independently, using arbitrary-size integers
    # after clearing all denominators (no floating-point rank decisions).
    import math
    common=math.lcm(*map(int,d)); basis=np.zeros((n,len(free)),dtype=object)
    for j,col in enumerate(free): basis[col,j]=common
    for i,pivot in enumerate(piv):
        for j in range(len(free)): basis[pivot,j]=int(c[i,j])*(common//int(d[i]))
    m=h.astype(object)-case['eigenvalue']*np.eye(n,dtype=object)
    assert np.all(m@basis==0)
    # The free-coordinate identity gives n/2 independent basis vectors; trace
    # zero and H^2=nI give exact eigen-dimension n/2, proving completeness.
    return h,c,d

ap=argparse.ArgumentParser(); ap.add_argument('input'); ap.add_argument('--out',required=True); args=ap.parse_args()
source=Path(args.input); data=json.loads(source.read_text()); output=Path(args.out); output.mkdir(parents=True,exist_ok=True)
devices=[d for p in cl.get_platforms() for d in p.get_devices() if d.type&cl.device_type.GPU]
ctx=cl.Context([devices[0]]); queue=cl.CommandQueue(ctx); program=cl.Program(ctx,KERNEL).build(); kernel=program.exhaust
mf=cl.mem_flags; results=[]
for case in data['cases']:
    started=time.time(); h,c,d=validate(case); order=case['test_order']; assert sorted(order)==list(range(len(d)))
    c=c[order]; d=d[order]; bits=max(abs(int(v)).bit_length() for v in c.flat)
    assert bits<27 and max(sum(abs(int(x)) for x in row) for row in c)<2**28 and np.all(d<2**28)
    positive=np.zeros((len(d),bits),np.uint32); negative=np.zeros_like(positive)
    for i,row in enumerate(c):
        for j,value in enumerate(row):
            for bit in range(bits):
                if (abs(int(value))>>bit)&1:
                    if value>0: positive[i,bit]|=np.uint32(1<<j)
                    else: negative[i,bit]|=np.uint32(1<<j)
    total=c.sum(axis=1,dtype=np.int64).astype(np.int32); den=d.astype(np.int32)
    states=1<<(len(case['free'])-1); assert states==case['enumerated_free_assignments'] and len(case['free'])<=32
    groups=(states+255)//256; counts=np.empty(groups,np.uint32); witness=np.empty(groups,np.uint32)
    pb=cl.Buffer(ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=positive); nb=cl.Buffer(ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=negative)
    tb=cl.Buffer(ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=total); db=cl.Buffer(ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=den)
    cb=cl.Buffer(ctx,mf.WRITE_ONLY,counts.nbytes); wb=cl.Buffer(ctx,mf.WRITE_ONLY,witness.nbytes)
    kernel(queue,(groups*256,),(256,),pb,nb,tb,db,np.int32(len(d)),np.int32(bits),np.uint32(states),cb,wb)
    cl.enqueue_copy(queue,counts,cb); cl.enqueue_copy(queue,witness,wb).wait(); count=int(counts.sum(dtype=np.uint64))
    bases=np.arange(groups,dtype=np.uint32)*np.uint32(256)
    # All zero-count groups must return the unchanged lane-zero SID. This pins
    # every workgroup output, not just a zero reduction from unwritten memory.
    assert np.array_equal(witness[counts==0],bases[counts==0])
    assert np.all(witness>=bases) and np.all(witness<=bases+255)

    row={'name':case['name'],'n':case['n'],'sigma':case['sigma'],'free_assignments_exhausted':states,
         'antipodal_eigenvector_pairs':count,'coefficient_bits':bits,'device':devices[0].name,
         'source_matrix_file_sha256':case['source_sha256'],'basis_identity_and_completeness':'PASS','every_workgroup_output_coverage':'PASS',
         'group_counts_sha256':hashlib.sha256(counts.tobytes()).hexdigest(),'elapsed_seconds':time.time()-started}
    if 'cpu_exhaustive_count' in case: assert count==case['cpu_exhaustive_count']; row['CPU_full_cube_selftest']='PASS'
    if case['name'].startswith('knownSAT'): assert count>0
    if count:
        sid=int(witness[int(np.flatnonzero(counts)[0])]); mask=sid<<1
        free_x=np.asarray([-1 if (mask>>i)&1 else 1 for i in range(len(case['free']))],dtype=np.int64)
        original_c=np.asarray(case['C'],dtype=np.int64); original_d=np.asarray(case['D'],dtype=np.int64)
        nums=original_c@free_x; assert np.all(nums%original_d==0)
        x=np.zeros(case['n'],dtype=np.int64); x[case['free']]=free_x; x[case['pivots']]=nums//original_d
        assert np.all(abs(x)==1) and np.array_equal(h@x,case['eigenvalue']*x)
        row.update(witness_x=x.tolist(),integer_eigen_witness='PASS')
    np.save(output/(case['name']+'.group_counts.npy'),counts)
    results.append(row); (output/(case['name']+'.json')).write_text(json.dumps(row,indent=2)+'\n'); print(json.dumps(row),flush=True)
(output/'manifest.json').write_text(json.dumps({'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'scorer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':results,
    'classification':'INDEPENDENT_EXHAUSTIVE_COMPUTATION_NOT_DRAT_PROOF'},indent=2)+'\n')

